int sazetak( char *ulaz );
void dodajZnak( char *ulaz, int broj );
char *napraviRijec( char *ulaz, char *izlaz );