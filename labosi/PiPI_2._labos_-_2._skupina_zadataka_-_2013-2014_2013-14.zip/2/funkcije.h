void setSeed ( unsigned int seed );
unsigned int getRand ( void );
