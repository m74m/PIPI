void minMax( int *polje, int r, int s, int maxs, int *min, int *max );
int dobreDimenzije( int p, int s, int maxp, int maxs );