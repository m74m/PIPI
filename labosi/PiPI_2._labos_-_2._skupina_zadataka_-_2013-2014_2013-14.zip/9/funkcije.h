void genPodniz ( char *nizUlaz, char *podNiz, int pocPozicija, int duljPodniza );
int nizoviJednaki ( char *niz1, char *niz2 );