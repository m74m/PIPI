2 skupina zadataka, 2. labos, PPI 2013/2014

ako nađete greške, pm me:
	- fejs: Filip Hrenić
	- fer2: redThunder

nisam previše testirao, čak se ni ne sjećam dal sve radi :D tak da ak ne radi, pm.

poz