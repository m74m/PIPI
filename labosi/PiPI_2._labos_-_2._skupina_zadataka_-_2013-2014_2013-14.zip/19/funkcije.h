void rastavi ( char *niz, int brRijeci, int maxRijeci, int duljinaRijeci, char *polje );
int brojRijeci ( char *polje, int brRijeci );