void brLijevihiDesnihGranicnika ( char *znNiz, char lijevi, char desni, int *brLijevih, int *brDesnih );
int izrazJeIspravan( char *niz, char lijevi, char desni );