int search( int *niz, int n, int elem );
void sort( int *niz, int n );
void unija( int n1, int *s1, int n2, int *s2, int nrez, int *rez );
int je_podskup( int npodskup, int *podskup, int nskup, int *skup );
int ucitaj( int *skup );