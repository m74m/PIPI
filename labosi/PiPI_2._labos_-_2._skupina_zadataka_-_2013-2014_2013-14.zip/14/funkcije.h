int nizUInt ( char *niz );
int matemOp ( int a, int b, char op, int *rez );