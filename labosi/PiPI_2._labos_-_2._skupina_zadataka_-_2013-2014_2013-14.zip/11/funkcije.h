char *nadjiPodniz ( char *str, char *find );
int izbaci(char *ulaz, char *uzorak);