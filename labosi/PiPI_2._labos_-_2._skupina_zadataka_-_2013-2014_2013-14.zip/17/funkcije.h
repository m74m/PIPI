void kvadrat( int *polje, int r, int s, int maxs );
void minStupac( int *polje, int r, int s, int maxs, int *niz );