void brojac(char *niz, char lijevi, char desni, int *brlijevih, int *brdesnih);
int ispravan(char *niz, char lijevi, char desni);