void setSeed(unsigned seed);
unsigned getRand();