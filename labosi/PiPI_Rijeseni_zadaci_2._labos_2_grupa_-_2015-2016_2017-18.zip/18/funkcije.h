int udaljenost(char niz1[], char niz2[], int n);
void slucajni(int n, char s[]);