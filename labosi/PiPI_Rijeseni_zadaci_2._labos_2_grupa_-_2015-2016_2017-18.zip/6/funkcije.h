int brRijeci(char *tekst);
int izbaciBrojeve(char *tekst);