void rasporedi(int *one_d, int *two_d, int max_stup, int n, int r, int s);
void generiraj(int *polje, int n, int dg, int gg);