void minMax(int m, int n, int stup, int *polje, int *min, int *max);
int dobreDimenzije(int m, int n, int def_m, int def_n);