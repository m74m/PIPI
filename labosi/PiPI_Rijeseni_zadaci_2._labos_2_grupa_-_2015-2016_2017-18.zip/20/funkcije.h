char generirajZnak(int vrsta);
void generirajLozinku(int ns, int nb, int ni, char izl[]);