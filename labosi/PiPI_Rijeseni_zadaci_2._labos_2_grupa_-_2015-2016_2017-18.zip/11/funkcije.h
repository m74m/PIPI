char* nadjipodniz(char *ulaz, char *uzorak);
int izbaci(char *ulaz, char *uzorak);