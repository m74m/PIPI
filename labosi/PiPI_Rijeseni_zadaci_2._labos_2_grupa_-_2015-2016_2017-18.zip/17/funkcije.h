typedef struct {
	int bodovi;
	int ispao;
	int krug_ispadanja;
} player;

void simulirajIgru(player igrac[], int broj, int krugovi);