int brojNeSlova (char *niz);
void caesarEncrypt (char *nizUlaz, char *nizIzlaz, int kljucKriptiranja);