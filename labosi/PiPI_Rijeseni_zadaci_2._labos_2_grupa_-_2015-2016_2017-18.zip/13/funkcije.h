int convert(int broj, char *niz);
char *append(char *prvi, char *drugi);
void s_time(int sekunde, int *h, int *m, int *s);