double stupnjeviURadijane(double kut);

double izracunajUdaljenost(double lat1, double long1, double lat2, double long2);

typedef struct {
	int post;
	double latitude;
	double longitude;
} city;