int string_to_int (char ulaz[]);
float division(int m, int n);