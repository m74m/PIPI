void generirajNiz(char *znakovi, int duljinaNiza, char *genNiz);
int dobarNiz(char niz[]);