int broj(char niz[], char znak);
void kodiraj(char src[], char dest[]);