char *prviZnak(char *niz1, char *niz2);
int brojRecenica(char *niz);