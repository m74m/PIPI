void gen(char *niz, char *podniz, int pozicija, int duljina);
int sadrzi(char *niz, char *podniz);