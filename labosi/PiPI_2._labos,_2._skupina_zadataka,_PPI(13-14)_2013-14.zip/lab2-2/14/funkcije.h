int nizUInt(char *niz);
int matemOp(char op, int a, int b, int *rez);