void minMax(int *polje, int r, int s, int *min, int *max, int MAX);
int dobreDimenzije(int r, int s, int mr, int ms);