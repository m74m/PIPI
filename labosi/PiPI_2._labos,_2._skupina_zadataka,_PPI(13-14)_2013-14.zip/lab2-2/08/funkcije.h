void brLijevihiDesnihGranicnika(char *znNiz, char lijevi, char desni, int *brLijevih, int *brDesnih);
int izrazJeIspravan(int brLijevih, int brDesnih);