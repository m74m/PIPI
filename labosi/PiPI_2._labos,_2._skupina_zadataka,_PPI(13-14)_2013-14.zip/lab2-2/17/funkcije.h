void kvadrat(int *p, int r, int s, int max);
void minStupac(int *p, int r, int s, int max, int *pm);