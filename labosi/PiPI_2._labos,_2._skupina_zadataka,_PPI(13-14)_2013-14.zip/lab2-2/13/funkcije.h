int intUNiz(int broj, char *niz);
char *dodajNiz(char *prvi, char *drugi);
void hms(int sekunde, int *h, int *m, int *s);