void setSeed(unsigned int x0);
unsigned int getRand(void);