int HammingovaUdaljenost(char *s, char *t);
void odrediSlucajniNiz(int n, char *s);