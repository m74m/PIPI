#include<stdio.h>

int main(void){
    
			int x, y, z;
			scanf("%d", &x);
			y=x/10;
			z=y%10;
			printf("\r\n Srednja znamenka broja %d je %d", x, z);
			return 0;
}
