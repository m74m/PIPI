void odrediZadatke(int *prvi, int *drugi, int *polje, int *polje2, int m, int n){
	*prvi=polje[rand()%m];
	*drugi=polje2[rand()%n];
}