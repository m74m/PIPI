
#include <stdio.h>
#include <conio.h>

int main(void) {
    float a,b;
    char operacija;
    printf("Upisati prvi broj: ");
    scanf(" %f",&a);
    printf("Upisati drugi broj: ");
    scanf(" %f",&b);
    printf("Upisati operaciju: zbrajanje(z), oduzimanje(o),\n");
    printf(" mnozenje(m),dijeljenje(d) :");
    scanf(" %c",&operacija);
    switch(operacija){
                      case 'z':
                      printf("\n%f\n",a+b);
                      break;
                      case 'o':
                      printf("\n%f\n",a-b);
                      break;
                      case 'm':
                      printf("\n%f\n",a*b);
                      break;
                      case 'd':
                      printf("\n%f\n",a/b);
                      break;
                      default:
                      printf("Nedopustena operacija!\n");
    }
    getch();
    return 0;
}