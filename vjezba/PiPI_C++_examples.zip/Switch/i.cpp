
#include <stdio.h>
#include <conio.h>

int main(void) {
    int i;
    printf("i=");
    scanf("%d",&i);
    switch(i) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5: printf("i < 6\n");
              break;
              case 6: printf("i = 6\n");
              break;
              default: printf("i > 6\n");
              }
    getch();
    return 0;
}