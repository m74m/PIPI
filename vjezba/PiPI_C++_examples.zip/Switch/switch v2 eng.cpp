#include <stdio.h>
#include <conio.h>
main () {
    int x;
    printf("Write one number: ");
    scanf("%d", &x);
    switch(x){
        case 0: printf("\n Monday");
        break;
        case 1: printf("\n Tuesday");
        break;
        case 2: printf("\n Wednesday");
        break;
        case 3: printf("\n Thursday");
        break;
        case 4: printf("\n Friday");
        break;
        case 5: printf("\n Saturday");
        break;
        case 6: printf("\n Sunday");
        break;
        default: printf("\n Wrong input");
        break;
    }
    getch ();
}
