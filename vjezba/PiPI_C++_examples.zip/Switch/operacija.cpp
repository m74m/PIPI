#include<stdio.h>
#include<conio.h>

int main () {
        
    float a, b, r;
    char c;
    
    printf("a="); scanf("%f", &a);
    printf("b="); scanf("%f", &b);
    scanf("%c", &c); // U�itavanje kraja retka!
    printf("Unesite znak operacije (+, -, *, /):"); scanf("%c", &c);
    
    switch(c) {
        case'+': r=a+b;
        break;
        case'-': r=a-b;
        break;
        case'*': r=a*b;
        break;
        case'/': r=a/b;
        break;
        default: printf("Pogresan znak!\n"); getch(); return 0;
        break;
    }
    
    
    printf("a%cb=%f\n" ,c  ,r);
    
    getch();
    
    return 0;
    
}
