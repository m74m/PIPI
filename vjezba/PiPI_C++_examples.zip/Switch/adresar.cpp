#include <stdio.h>
#include <conio.h>
main () {
    int x;
    printf("Ovo je adresar vlasnika ormarica:\n");
    printf("Upisite broj ormarica: ");
    scanf("%d", &x);
    switch(x){
        case 219: printf("\n Martin Antolic");
        break;
        case 225: printf("\n Igor Dragicevic");        
        break;
        case 253: printf("\n Dino Mudric");
        break;
        case 276: printf("\n Alen Zizak");
        break;
        case 304: printf("\n Tomislav Budor");
        break;
        case 365: printf("\n Ivan Tonkovic");
        break;
        case 390: printf("\n Matej Varda");
        break;
        case 394: printf("\n Tin Fundurulja");
        break;                        
        case 585: printf("\n Mateja Remenar");
        break;        
        case 639: printf("\n Mate Mamich");
        break;
        case 641: printf("\n Marta Sever");
        break; 
        case 642: printf("\n Ivan Buzov");
        break;
        case 669: printf("\n Vladimir Tonkovic");
        break;               
        default: printf("\n Nepoznat");
        break;       
    }
    getch ();
}        
