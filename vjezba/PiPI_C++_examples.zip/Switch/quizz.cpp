#include <stdio.h>
#include <conio.h>
main () {
    int x;
    printf("Ovo je kviz u C++:\n");
    printf("Koji ocean nema pristup sjevernom polu:\n");
    printf("1. Atlanski\n2. Indijski\n3. Tihi\n"); 
    printf("Upisite broj tocnog odgovora: ");
    scanf("%d", &x);
    switch(x){
        case 2: printf("Tocan odgovor!!");
        break;
        default: printf("Pogresan odgovor!");
    }
    getch();
}        
        
