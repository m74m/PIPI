#include <stdio.h>
#include <conio.h>
main () {
    int x;
    printf("Upisite jedan broj: ");
    scanf("%d", &x);
    switch(x){
        case 0: printf("\n ponedjeljak");
        break;
        case 1: printf("\n utorak");
        break;
        case 2: printf("\n srijeda");
        break;
        case 3: printf("\n cetvrtak");
        break;
        case 4: printf("\n petak");
        break;
        case 5: printf("\n subota");
        break;
        case 6: printf("\n nedjelja");
        break;
        default: printf("\n Pogresan unos");
        break;       
    }
    getch ();
}        
