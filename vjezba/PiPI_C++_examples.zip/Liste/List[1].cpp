
/* A program to find the smallest k (chosen) values from a list of */
/* size n using a partial insertion sort and a partial selection   */
/* sort.  The number of comparisons made in each case is reported. */


#define max_size 2000
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <stddef.h>

int list_a[max_size];
int list_b[max_size];

/* select_sort--presumes an array of integers */
/* Counts the number of operations            */

void select_sort(int size, int chosen)
{
 int count = 0;
 int pass, i, j, smallest;

 for (pass = 0; pass < chosen; pass++)
  {
   j = pass;
   smallest = list_b[j];
   for (i = pass+1; i < size; i++)
    {
     count++;
     if (list_b[i] < list_b[j])        /* Search for smallest */
      j = i;                           /* remaining entry     */
    }
   list_b[j] = list_b[pass];           /* Complete the switch */
   list_b[pass] = smallest;
  }
 printf("Selection Sort\n");
 printf("  Number of comparisons: %d\n", count);
}


/* Partial Insertion Sort */

void insertion_sort(int size, int chosen)
{
 int n, k;
 bool location_found;
 int temp;
 int count = 0;

 for (n = 1; n < size; n++)
  {
   temp = list_a[n];                 /* Set item aside */
   location_found = false;
   if (n < chosen)
      k = n - 1;
   else
      k = chosen - 1;                /* Only Partial Sort */
   while (location_found == false)
    {
     count++;
     if (temp < list_a[k])
      {
       list_a[k+1] = list_a[k];
       k--;
       if (k < 0)
	location_found = true;
      }
     else
      location_found = true;
     }
   list_a[k + 1] = temp;              /* Replace Item in List */
  }
 printf("Insertion Sort\n");
 printf("  Number of comparisons: %d\n", count);
}


main()
{
 int i, size, chosen;
 for (i = 0; i < max_size; i++)
  {
   list_a[i] = rand();
   list_b[i] = list_a[i];
  }
 do
  {
   printf("\nEnter the size of the list to be used ");
   printf("(no larger than %d): ", max_size);
   scanf("%d", &size);
  } while ((size > max_size) || (size < 0));
 do
  {
   printf("\nEnter the number of entries to be chosen \n");
   printf("(no larger than the size you entered above): ");
   scanf("%d", &chosen);
  } while ((chosen > size) || (chosen < 0));
 printf("\n");
 select_sort(size, chosen);
 insertion_sort(size, chosen);
 getch();
}



