
/* This program counts the steps made when sorting a list     */
/* of randomly generated integers.  Quick Sort and Insertion  */
/* Sort are compared.                                */

#include <limits.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#define max_size 4000

int list_a[max_size];
int list_b[max_size];
long count = 0;

/* Insertion Sort */

void insertion_sort(int size)
{
 int n, k;
 bool location_found;
 int temp;
 long count = 0;

 for (n = 1; n < size; n++)
  {
   temp = list_a[n];                 /* Set item aside */
   location_found = false;
   k = n - 1;
   while (location_found == false)
    {
     if (count == LONG_MAX)
      {
       printf("Insertion Sort\n");
       printf("***Overflow error occurred***\n");
       printf("   Number of comparisons exceeded %u\n", LONG_MAX);
       return;
      }count++;
     if (temp < list_a[k])
      {
       list_a[k+1] = list_a[k];
       k--;
       if (k < 0)
	location_found = true;
      }
     else
      location_found = true;
     }
   list_a[k + 1] = temp;              /* Replace Item in List */
  }
 printf("Insertion Sort\n");
 printf("  Number of comparisons: %ld\n", count);
}


void quick_sort(int l, int r)
{
 int i, j;
 int pivot;
 int temp;
 if (l < r)
  {
   i = l;
   j = r;
   pivot = list_b[l];                          /* Entry to be positioned */
   do
    {
     while ((list_b[j] > pivot) && (j > i))
      {
       j--;
       count++;
      }
     while ((list_b[i] <= pivot) && (i < j))
      {
       i++;
       count++;
      }
     if (i != j)
      {
       temp = list_b[j];
       list_b[j] = list_b[i];
       list_b[i] = temp;
      }
    } while (i != j);
   list_b[l] = list_b[i];
   list_b[i] = pivot;
   quick_sort(l,j-1);   /* The lower subarray */
   quick_sort(i+1,r);   /* The upper subarray */
  }
}


main()
{
 int i, size;
 for (i = 0; i < max_size; i++)
  {
   list_a[i] = rand();
   list_b[i] = list_a[i];
  }
 do
  {
   printf("\nEnter the size of the list to be used ");
   printf("(no larger than %d): ", max_size);
   scanf("%d", &size);
  } while ((size > max_size) || ( size < 0));
 printf("\n");
 quick_sort(0, size-1);
 printf("Quick Sort\n");
 printf("  Number of comparisons: %ld\n", count);
 insertion_sort(size);
 getch();
}



