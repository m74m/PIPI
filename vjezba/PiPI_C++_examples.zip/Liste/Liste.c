#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* oznaka kraja liste */
#define KRAJ (struct ime *) 0

/* deklaracija samoreferentne strukture */
struct ime {
char *p_ime;
struct ime *next;
};

/* pokazivac na prvi element liste (globalna varijabla) */
struct ime *start=KRAJ;

/* dodavanje novog elementa na kraj liste */
void unos(void) {
     struct ime *zadnji, *novi;
     char line[128];
     printf("Dodavanje novog elementa na kraj liste.\n");
     novi = (struct ime *) malloc(sizeof(struct ime));
     if(novi == NULL) {
             printf("Nema dovoljno memorije ... ");
             exit(-1);
     }
     novi->next=KRAJ;
     printf("Unesite ime > ");
     scanf(" %[^\n]",line);
     novi->p_ime=(char *) malloc(strlen(line)+1);
     if(novi->p_ime == NULL) {
                    printf("Nema dovoljno memorije ...");
                    exit(-1);
     }
     strcpy(novi->p_ime,line);
     if(start==KRAJ) /* prazna lista */
     start=novi;
     else { /* pronadji kraj liste */
          for(zadnji=start; zadnji->next != KRAJ; zadnji=zadnji->next); // ne radi nista
          /* neka zadnji pokazuje na novi element */
          zadnji->next=novi;
     }
}

void ispis(void) { /* Ispis liste */
     struct ime *element;
     int i=1;
     if(start == KRAJ ) {
              printf("Lista je prazna.\n");
              return;
     }
     printf("Ispis liste \n");
     for(element=start; element != KRAJ; element=element->next) {
                        printf("%d. %s\n",i,element->p_ime); i++;
     }
     return;
}

void trazi(void) { /* Pretrazivanje liste */
     struct ime *test;
     char line[128];
     int i;
     printf("Nalazenje imena u listi.\n");
     printf("Unesite ime ");
     scanf(" %[^\n]",line);
     i=1;
     for(test=start; test != KRAJ; test=test->next) {
                     if( !strcmp(test->p_ime,line) ) {
                                                   printf("Podatak je %d. u listi\n",i);
                                                   return;
                     }
                     i++;
     }
     printf("Podatak nije u listi.\n");
}

void brisi(void) /* Brisanje elementa iz liste */ {
     struct ime *test, *tmp;
     char line[128];
     int i;
     printf("Brisanje imena iz liste.\n");
     if(start == KRAJ){
              printf("Lista je prazna.\n");
                   return;
     }
     printf("Unesite ime ");
     scanf(" %[^\n]",line);
     /* ako je prvi element onaj koji trazimo */
     if( !strcmp(start->p_ime,line) ) {
         printf("Podatak je 1. u listi\n");
         tmp=start;
         start=start->next;
         free(tmp->p_ime);
         free(tmp);
         return;
     }
     i=1;
     for(test=start; test != KRAJ; test=test->next) {
                     i++;
                     if(!(tmp=test->next)) break; // elm. nije nadjen
                     if( !strcmp(tmp->p_ime,line) ) {
                         printf("Brisemo podatak br. %d u listi\n",i);
                         test->next=test->next->next;
                         free(tmp->p_ime);
                         free(tmp);
                         return;
                     }
     }
     printf("Podatak nije u listi.\n");
     return;
}

int menu(void) {
    int izbor;
    printf("\n\n\n");
    printf("\n OPERACIJE : ");
    printf("\n =========");
    printf("\n 1. Unos novog elemeta ");
    printf("\n 2. Ispis liste ");
    printf("\n 3. Pretrazivanje liste ");
    printf("\n 4. Brisanje iz liste ");
    printf("\n 5. Izlaz ");
    printf("\n izbor = ");
    scanf("%d",&izbor);
    return izbor;
}

//i dajemo glavni program:
int main(void) {
    int izbor;
    do {
       switch(izbor=menu()) {
                            case 1:
                            unos();
                            break;
                            case 2:
                            ispis();
                            break;
                            case 3:
                            trazi();
                            break;
                            case 4:
                            brisi();
                            break;
                            case 5:
                            break;
                            default:
                            printf("\n Pogresan izbor.");
       }
    } while(izbor != 5);
    return 0;
}
