
/* A program for comparing the insertion and selection sort */
/* algorithms.                                  */

#include <limits.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#define max_size 2000

int list_a[max_size];
int list_b[max_size];

/* select_sort--presumes an array of integers */
/* Counts the number of comparisons made.     */

void selection_sort(int size)
{
 long count = 0;
 int pass, i, j, smallest;

 for (pass = 0; pass < size; pass++)
  {
   j = pass;
   smallest = list_b[j];
   for (i = pass + 1; i < size; i++)
    {
     if (count == LONG_MAX)
      {
       printf("Selection Sort\n");
       printf("***Overflow error occurred***\n");
       printf("   Number of comparisons exceeded %u\n", LONG_MAX);
       return;
      }
     count++;
     if (list_b[i] < list_b[j])        /* Search for smallest */
      j = i;                           /* remaining entry     */
    }
   list_b[j] = list_b[pass];           /* Complete the switch */
   list_b[pass] = smallest;
  }
 printf("Selection Sort\n");
 printf("  Number of comparisons: %ld\n", count);
}


/* Insertion Sort */

void insertion_sort(int size)
{
 int n, k;
 bool location_found;
 int temp;
 long count = 0;

 for (n = 1; n < size; n++)
  {
   temp = list_a[n];                 /* Set item aside */
   location_found = false;
   k = n - 1;
   while (location_found == false)
    {
     if (count == LONG_MAX)
      {
       printf("Insertion Sort\n");
       printf("***Overflow error occurred***\n");
       printf("   Number of comparisons exceeded %u\n", LONG_MAX);
       return;
      }count++;
     if (temp < list_a[k])
      {
       list_a[k+1] = list_a[k];
       k--;
       if (k < 0)
	location_found = true;
      }
     else
      location_found = true;
     }
   list_a[k + 1] = temp;              /* Replace Item in List */
  }
 printf("Insertion Sort\n");
 printf("  Number of comparisons: %ld\n", count);
}


main()
{
 int i, size;
 for (i = 0; i < max_size; i++)
  {
   list_a[i] = rand();
   list_b[i] = list_a[i];
  }
 do
  {
   printf("\nEnter the size of the list to be used ");
   printf("(no larger than %d): ", max_size);
   scanf("%d", &size);
  } while ((size > max_size) || ( size < 0));
 printf("\n");
 selection_sort(size);
 insertion_sort(size);
 printf("\nApplying the algorithms to the sorted list produces:\n");
 selection_sort(size);
 insertion_sort(size);
 getch();
}



