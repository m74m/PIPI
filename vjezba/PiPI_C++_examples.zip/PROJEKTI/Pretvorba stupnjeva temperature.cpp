#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define _WIN32_WINNT 0x0500
//it is important that the above line be typed
//  BEFORE <windows.h> is included
#include <windows.h>
#define K 273.15 // Ledi�te vode u �K;
#define FR 459.67 //Konstanta konverzije Fahrenheit-Rankine;
#define R -218.520004 //Najni�a temperatura u �R;




bool provjera(int c, float t) {
     bool i=0;
     if((c>=1)&&(c<=4)){if(t<0) i=1;}
     if((c>=5)&&(c<=8)){if(t<-K) i=1;}
     if((c>=9)&&(c<=12)){if(t<-FR) i=1;}
     if((c>=13)&&(c<=16)){if(t<R) i=1;}
     if((c>=17)&&(c<=20)){if(t<0) i=1;}
     return i;
}

void upozorenje(int c) {
      if((c>=1)&&(c<=4)){system("cls"); system("color 4f"); printf("\aTemperatura u �K ne moze biti <0 (manja od nule)!\nNajniza temperatura u �K (apsolutna nula) iznosi 0�K !\n"); }
      if((c>=5)&&(c<=8)){system("cls"); system("color 4f"); printf("\aTemperatura u �C ne moze biti <%.2f (manja od temperature %.2f �C)!\nNajniza temperatura u �C (apsolutna nula) iznosi %.2f �C !\n",-K,-K,-K); }
      if((c>=9)&&(c<=12)){system("cls"); system("color 4f"); printf("\aTemperatura u �F ne moze biti <%.2f (manja od temperature %.2f �F)!\nNajniza temperatura u �F (apsolutna nula) iznosi %.2f �F !\n",-FR,-FR,-FR); }
      if((c>=13)&&(c<=16)){system("cls"); system("color 4f"); printf("\aTemperatura u �R ne moze biti <%.2f (manja od temperature %.2f �R)!\nNajniza temperatura u �R (apsolutna nula) iznosi %.2f �R !\n",R,R,R); }
      if((c>=17)&&(c<=20)){system("cls"); system("color 4f"); printf("\aTemperatura u �Ra ne moze biti <0 (manja od nule)!\nNajniza temperatura u �Ra (apsolutna nula) iznosi 0�Ra !\n"); }
}

void izbornik() {
     
     int c;
     float T_K/*Kelvin*/, T_C/*Celzijus*/, T_F/*Fahrenheit*/, T_R/*Reaumur*/, T_Ra/*Rankine*/;
     start:
     system("cls");
     system("color 1f");
     printf("\nPretvorba stupnjeva temperature:\n\n");
     printf(" K-Kelvin \n C-Celzijus \n F-Fahrenheit \n R-Reaumur \n Ra-Rankine \n\n");
     printf(" K->C:   1 \n K->F:   2 \n K->R:   3 \n K->Ra:  4 \n C->K:   5 \n C->F:   6 \n C->R:   7 \n C->Ra:  8 \n F->K:   9 \n F->C:  10 \n F->R:  11 \n F->Ra: 12 \n R->K:  13 \n R->C:  14  \n R->F:  15 \n R->Ra: 16 \n Ra->K: 17 \n Ra->C: 18 \n Ra->F: 19 \n Ra->R: 20 \n\n EXIT:   0 \n\n>");
     if(scanf("%d", &c)!=1) {getchar(); /*Empty buffer*/ system("cls"); system("color 4f"); printf("\a\n Pogresan unos!"); getch(); goto start;} ;
     system("cls");
     switch(c){

               
               case 0:
               exit(0);
               break;

               case 1:
               printf("Unesite temperaturu u �K: ");
               scanf("%f", &T_K);
               if(provjera(c, T_K)) { upozorenje(c); break;}
               T_C=T_K-K;
               printf("Temperaturua u �C iznosi: %f �C\n",T_C);
               break;

               case 2:
               printf("Unesite temperaturu u �K: ");
               scanf("%f", &T_K);
               if(provjera(c, T_K)) { upozorenje(c); break;}
               T_F=T_K*1.8-FR;
               printf("Temperaturua u �F iznosi: %f �F\n",T_F);
               break;

               case 3:
               printf("Unesite temperaturu u �K: ");
               scanf("%f", &T_K);
               if(provjera(c, T_K)) { upozorenje(c); break;}
               T_R=(T_K-K)*0.8;
               printf("Temperaturua u �R iznosi: %f �R\n",T_R);
               break;

               case 4:
               printf("Unesite temperaturu u �K: ");
               scanf("%f", &T_K);
               if(provjera(c, T_K)) { upozorenje(c); break;}
               T_Ra=T_K*1.8;
               printf("Temperaturua u �Ra iznosi: %f �Ra\n",T_Ra);
               break;

               case 5:
               printf("Unesite temperaturu u �C: ");
               scanf("%f", &T_C);
               if(provjera(c, T_C)) { upozorenje(c); break;}
               T_K=T_C+K;
               printf("Temperaturua u �K iznosi: %f �K\n",T_K);
               break;

               case 6:
               printf("Unesite temperaturu u �C: ");
               scanf("%f", &T_C);
               if(provjera(c, T_C)) { upozorenje(c); break;}
               T_F=T_C*1.8+32;
               printf("Temperaturua u �F iznosi: %f �F\n",T_F);
               break;

               case 7:
               printf("Unesite temperaturu u �C: ");
               scanf("%f", &T_C);
               if(provjera(c, T_C)) { upozorenje(c); break;}
               T_R=T_C*0.8;
               printf("Temperaturua u �R iznosi: %f �R\n",T_R);
               break;

               case 8:
               printf("Unesite temperaturu u �C: ");
               scanf("%f", &T_C);
               if(provjera(c, T_C)) { upozorenje(c); break;}
               T_Ra=T_C*1.8+32+FR;
               printf("Temperaturua u �Ra iznosi: %f �Ra\n",T_Ra);
               break;

               case 9:
               printf("Unesite temperaturu u �F: ");
               scanf("%f", &T_F);
               if(provjera(c, T_F)) { upozorenje(c); break;}
               T_K=(T_F+FR)/1.8;
               printf("Temperaturua u �K iznosi: %f �K\n",T_K);
               break;

               case 10:
               printf("Unesite temperaturu u �F: ");
               scanf("%f", &T_F);
               if(provjera(c, T_F)) { upozorenje(c); break;}
               T_C=(T_F-32)/1.8;
               printf("Temperaturua u �C iznosi: %f �C\n",T_C);
               break;

               case 11:
               printf("Unesite temperaturu u �F: ");
               scanf("%f", &T_F);
               if(provjera(c, T_F)) { upozorenje(c); break;}
               T_R=(T_F-32)/2.25;
               printf("Temperaturua u �R iznosi: %f �R\n",T_R);
               break;

               case 12:
               printf("Unesite temperaturu u �F: ");
               scanf("%f", &T_F);
               if(provjera(c, T_F)) { upozorenje(c); break;}
               T_Ra=T_F+FR;
               printf("Temperaturua u �Ra iznosi: %f �Ra\n",T_Ra);
               break;

               case 13:
               printf("Unesite temperaturu u �R: ");
               scanf("%f", &T_R);
               if(provjera(c, T_R)) { upozorenje(c); break;}
               T_K=T_R*1.25+K;
               printf("Temperaturua u �K iznosi: %f �K\n",T_K);
               break;

               case 14:
               printf("Unesite temperaturu u �R: ");
               scanf("%f", &T_R);
               if(provjera(c, T_R)) { upozorenje(c); break;}
               T_C=T_R*1.25;
               printf("Temperaturua u �C iznosi: %f �C\n",T_C);
               break;

               case 15:
               printf("Unesite temperaturu u �R: ");
               scanf("%f", &T_R);
               if(provjera(c, T_R)) { upozorenje(c); break;}
               T_F=T_R*2.25+32;
               printf("Temperaturua u �F iznosi: %f �F\n",T_F);
               break;

               case 16:
               printf("Unesite temperaturu u �R: ");
               scanf("%f", &T_R);
               if(provjera(c, T_R)) { upozorenje(c); break;}
               T_Ra=T_R*2.25+32+FR;
               printf("Temperaturua u �Ra iznosi: %f �Ra\n",T_Ra);
               break;

               case 17:
               printf("Unesite temperaturu u �Ra: ");
               scanf("%f", &T_Ra);
               if(provjera(c, T_Ra)) { upozorenje(c); break;}
               T_K=T_Ra/1.8;
               printf("Temperaturua u �K iznosi: %f �K\n",T_K);
               break;

               case 18:
               printf("Unesite temperaturu u �Ra: ");
               scanf("%f", &T_Ra);
               if(provjera(c, T_Ra)) { upozorenje(c); break;}
               T_C=(T_Ra-32-FR)/1.8;
               printf("Temperaturua u �C iznosi: %f �C\n",T_C);
               break;

               case 19:
               printf("Unesite temperaturu u �Ra: ");
               scanf("%f", &T_Ra);
               if(provjera(c, T_Ra)) { upozorenje(c); break;}
               T_F=T_Ra-FR;
               printf("Temperaturua u �F iznosi: %f �F\n",T_F);
               break;

               case 20:
               printf("Unesite temperaturu u �Ra: ");
               scanf("%f", &T_Ra);
               if(provjera(c, T_Ra)) { upozorenje(c); break;}
               T_R=(T_Ra-FR-32)/2.25;
               printf("Temperaturua u �R iznosi: %f �R\n",T_R);
               break;

               default: system("color 4f"); printf("\a\n Pogresan unos!");
               break;
               }
     getch();
     system("cls");
     system("color 1f");
}


main () {
     
     HWND console = GetConsoleWindow();
     RECT r;
     GetWindowRect(console, &r); //stores the console's current dimensions
     system("color 1f");
     system("title Pretvorba stupnjeva temperature");
     MoveWindow(console, r.left, r.top, 800, 500, TRUE);
     for( ; ; ) izbornik();
}
