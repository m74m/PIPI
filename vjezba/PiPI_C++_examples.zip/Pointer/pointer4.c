#include <stdio.h>

int main () {
    
    float z[10]={};
    float *pa;


    pa=&z[4];
    printf("adresa %p \n", pa);
    *pa=-5;
    getch();
    return 0;
}
