#include<stdio.h>

int main() {
    
    int polje[5]={1,2,15,200,0};
    int *ip;

    ip=&polje[0];
    int i;
    for(i=0; i<5; i++) {
             
             printf("vrijednost pointera %p \n", ip);
             printf("Sadrzaj adrese %d \n", *ip);
             ip++;
    }
    getch();
    return 0;
}
