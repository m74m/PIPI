#include <stdio.h>
#include <stdlib.h>

int main ()
{
         int i,s=0, niz[]={1,12,32,14,5};
         int *pok;
         pok=&niz[0];
         for(i=0;i<5;i++)
         s+=*pok++;
         printf("Trazeni zbroj je %d",s);
         getchar();
         return 0;
}  
