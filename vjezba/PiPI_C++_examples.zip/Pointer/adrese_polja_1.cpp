#include <stdio.h>
#include <conio.h>
#define FIELD 3  

main () {
    
    int c, i[FIELD], *p;
    
    for(c=0; c<FIELD; c++) { printf("i[%d]= ",c); scanf("%d", &i[c]); }
    
    printf("\n");
    
    for(c=0; c<FIELD; c++) { p=&i[c]; printf("i[%d]=%d,  &i[%d]=%p\n",c,i[c],c,p); }
    
    getch();
}    
