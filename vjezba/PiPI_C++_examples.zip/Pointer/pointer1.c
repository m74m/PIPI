#include<stdio.h>

int main() {
    int a;
    int*pa;
    pa=&a;
    *pa=5;
    a=13;
    printf("sadrzaj pointera %p \n", pa);
    printf("sadrzaj varijable na koju  pointer pokazuje %d \n", *pa);

    getch();

    return 0;
}

