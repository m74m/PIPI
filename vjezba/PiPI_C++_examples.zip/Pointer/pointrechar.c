#include<stdio.h>

int main() {
    char polje[5]={'a','c','g','t','n'};
    char *ip;

    ip=&polje[0];
    int i;
    for(i=0; i<5; i++) {
             printf("vrijednost pointera %p \n", ip);
             printf("Sadrzaj adrese %c \n", *ip);
             ip++;
    }
    getch();
    return 0;
}
