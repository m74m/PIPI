#include<stdio.h>

int main() {
    
    float polje[5]={1.3,2.55,15.54,200.77,0.1};
    float *ip;

    ip=&polje[0];
    float i;
    for(i=0; i<5; i++) {
             printf("vrijednost pointera %p \n", ip);
             printf("Sadrzaj adrese %f \n", *ip);
             ip++;
    }
    getch();
    return 0;
}
