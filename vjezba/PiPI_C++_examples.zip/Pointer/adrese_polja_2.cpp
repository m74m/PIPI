#include <stdio.h>
#include <conio.h>
#define FIELD 5

main () {
    
    int c, i[FIELD], *p;
    
    for(c=0; c<FIELD; c++) { printf("i[%d]= ",c); scanf("%d", &i[c]); }
    
    p=&i[0];
    
    printf("\n");
    
    for(c=0; c<FIELD; c++) { printf("i[%d]= %d  ",c,*p); printf("&i[%d]= %p\n",c,p); p++; }
    
    getch();
}    
