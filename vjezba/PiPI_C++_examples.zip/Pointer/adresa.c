#include <stdio.h>

int main () {

    float a, *n;
    printf("a="); scanf("%f", &a);
    n=&a;
    printf("a=%f, a se nalazi na adresi: %p\n",a,n);
    getch();
}
