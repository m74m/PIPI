#include <stdio.h>
#include <stdlib.h>

void Sort(int *x, int *y, int *z) {

  int a, b, c;
  a=*x; b=*y; c=*z; //Temporary

  if((a!=b)&&(a!=c)&&(b!=c)) {

   if((a<b)&&(a<c)) {*x=a; if(b<c) {*y=b; *z=c;} else{*y=c; *z=b;}}
   if((b<a)&&(b<c)) {*x=b; if(a<c) {*y=a; *z=c;} else{*y=c; *z=a;}}
   if((c<a)&&(c<b)) {*x=c; if(a<b) {*y=a; *z=b;} else{*y=b; *z=a;}}

   return;

  }else {printf("Dvaju ili vise unesenih brojeva su jednaki!\a\n"); getch(); exit(1);}
}

int main () {

 int a, b, c;

 printf("a="); scanf("%d",&a);
 printf("b="); scanf("%d",&b);
 printf("c="); scanf("%d",&c);

 Sort(&a,&b,&c);

 printf("Sortirani brojevi su: %d, %d, %d!\n",a,b,c);
 getch();
}
