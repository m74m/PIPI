#include <stdio.h>

int main () {
    int z[5], r;
    int *ip,*p;
    printf("%d\n",sizeof(z));
    ip=&z[0];
    p=&z[4];
    r=ip-p;
    printf("razlika je,%d\n",r);
    getch();
    return 0;
}
