#include <stdio.h>
#include <conio.h>  

main () {
    
    int mat[10];
    
    int *p=&mat[0];
    
    printf("Adresa 1. clana: %p\n", p);
    
    int *r=&mat[1];
    
    printf("Adresa 2. clana: %p\n", r);
    
    getch();
    
}    
