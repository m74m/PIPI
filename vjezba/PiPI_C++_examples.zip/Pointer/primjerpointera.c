#include<stdio.h>

int main() {
    int z[3]={1,2,3};
    printf("z=%p \n",z);
    printf("Adresa elementa z[0]:%p \n", &z[0]);
    getch();
    return 0;
}
