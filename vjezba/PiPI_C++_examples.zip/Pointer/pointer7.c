#include <stdio.h>

int main()
{
    int x = 1;
    int *ip; /*deklariramo pointer na int*/
    ip = &x; /*pointeru ip pridruzujemo adresu varijable x*/
    printf("Vrijednost pointera ip: %p\n",ip);
    printf("Sadrzaj varijable na koju ip pokazuje: %d\n",*ip);
    printf("Sadrzaj varijable x: %d\n",x); 
    getch();
    return 0;
}
