#include <stdio.h>

void func(int *a);

int main()
{
	int a = 1;
	printf("Prije poziva funkcije func: a = %d\n", a);
	func(&a);
	printf("Nakon poziva funkcije func: a = %d\n", a);
	getch();
	return 0;
}

void func(int *a)
{
	*a = *a + 100;
}


