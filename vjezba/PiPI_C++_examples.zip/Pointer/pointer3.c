#include <stdio.h>

int main () {
    int a;
    int *pa;
    pa=&a;
    *pa=10;
    printf("%d\n%d\n",a,pa);
    getch();
    return 0;
}
