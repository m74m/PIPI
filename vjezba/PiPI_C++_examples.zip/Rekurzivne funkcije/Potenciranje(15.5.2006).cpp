/* program potencira zadanu bazu zadanim eksponentom */
/* u funkciji se upisuju baza i eksponent */
/* rekurzivna funkcija racuna potenciju */

#include <stdio.h>
#include <conio.h>

int baza, eksponent;
int potencija;

//funkcija za upis
void upis(){
    printf("Upisi bazu: "); scanf("%d",&baza);
    printf("Upisi eksponent: "); scanf("%d",&eksponent);
}    

//rekurzivna funkcija za potenciranje
int pot(int broj, int n){
    if (n==0) {
        return 1;
    }    
    else {
        return broj*pot(broj,n-1);
    }    
}    

//funkcija za ispis
void ispis(){
    printf("%d potenciran na %d iznosi %d.",baza,eksponent,potencija);
}    

main() {
    upis();
    potencija=pot(baza,eksponent);
    ispis();
    getch();
}    
