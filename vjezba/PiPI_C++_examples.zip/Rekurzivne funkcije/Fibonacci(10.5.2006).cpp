/* Fibonaccijev niz se definira tako da je svaki broj zbroj prethodna dva broja niza. */
/* Vrijedi f(1)=1, f(2)=1, f(n)=f(n-1)+f(n-2) */

#include <stdio.h>
#include <conio.h>

/* rekurzivna funkcija za racunanje Fibonaccijevih brojeva */
/* uociti da ima dva if (n== ) { return } djela */
int Fibonacci(int n) {
    if (n==1) {
        return 1;
    }
    else if (n==2) {
        return 1;
    }        
    else {
        return Fibonacci(n-1)+Fibonacci(n-2);
    }    
}    

main() {
    int i,broj,rez;
    printf("Do kojeg broja zelis racunati Fibonaccijeve brojeve? "); scanf("%d",&broj);
    for (i=1; i<=broj; i++) {
        rez=Fibonacci(i);
        printf("f(%d)=%d\n",i,rez);
    }    
    getch();
}    
