/* Binomni koeficijenti su vrlo bitni u matematici:-) */

#include <stdio.h>
#include <conio.h>

/* funkcija za racunanje faktorijela */
int faktorijeli(int n) {
    if (n==1) {
        return 1;
    }    
    else {
        return n*faktorijeli(n-1);
    }    
} 

/* n povrh m = n!/(m!*(n-m)!) */
/* funkcija racuna trazenu vrijednost upotrebom funkcije faktorijeli */
/* bitno je da je funkcija faktorijeli definirana iznad pozivajuce funkcije */
/* inace ne bi radilo */
int nPovrhm(int n, int m) {
    int rez;
    rez = faktorijeli(n)/(faktorijeli(m)*faktorijeli(n-m));
    return rez;
}    

main() {
    int n,m;
    int rezultat;
    printf("Program racuna n povrh m\n");
    printf("n= "); scanf("%d",&n);
    printf("m= "); scanf("%d",&m);
    rezultat=nPovrhm(n,m);
    printf("%d povrh %d = %d\n",n,m,rezultat);
    getch();
}     
