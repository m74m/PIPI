#include <stdio.h>
#include <conio.h>

void fun(int x) {
     
 printf("\n");
 printf("%d ", x);
 if (x > 1) {
    fun(x - 1);
 }
 printf("\n");
}

int main(){
    
 int a;
    
 fun(1+2);
 fun(2+2);
 fun(3+2);
 fun(3+1);
 
 printf("a="); scanf("%d",&a);
 fun(a);
 
 getch();
 return 0;
}
