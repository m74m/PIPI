/* faktorijel nekog cijelog broja je umnozak svih pozitivni cijelih brojeva do tog broja */
/* oznacava se s n! pri cemu je n neki broj (npr. 3!, 4!,...) */
/* dogovoreno je da je po definiciji 0!=1 */
/* n!=1*2*...*(n-1)*n (npr. 5!=1*2*3*4*5=120) */

#include <stdio.h>
#include <conio.h>

/* funkcija koja rekurzivno poziva samu sebe */
/* rekurzivno rjesenje - logicnije */
/* funkcija mnozi zadni broj s umnoskom svih brojeva prije njega i tako ide do 1 */
int faktorijeli(int n) {
    if (n==1) {
        return 1;
    }    
    else {
        return n*faktorijeli(n-1);
    }    
}    

main() {
    int n;
    int rez=1,i;
    printf("Program racuna n!, upisi n:\n");
    printf("n= ");
    scanf("%d",&n);
    printf("n= %d, n!= %d\n",n,faktorijeli(n));
    printf("%d!=%d\n",n,faktorijeli(n));
    
    /* nerekurzivno rjesenje */
    for (i=2;i<=n;i++) {
        rez=rez*i;
    } 
    printf("%d!=%d\n",n,rez);   
    getch();
}    
