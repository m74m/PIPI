#include<stdio.h>

typedef struct student Student;

struct student{
   char *ime;
   char *prezime;
   int jmbag;
};

int main()
{
   int i;
   Student stud[3];

   stud[0].ime="Ivan"; stud[0].prezime="Ivanovic"; stud[0].jmbag=55;
   stud[1].ime="Pero"; stud[1].prezime="Peric"; stud[1].jmbag=44;
   stud[2].ime="Maja"; stud[2].prezime="Majic"; stud[2].jmbag=22;

   for(i=0; i <=2; i++)
   {
      printf("%d. student se zove %s\n",i+1,stud[i].ime);
      printf("%d. student se preziva %s\n",i+1,stud[i].prezime);
      printf("%d. student ima maticni broj %d\n",i+1,stud[i].jmbag);
   }
   getch();
   return 0;
}
