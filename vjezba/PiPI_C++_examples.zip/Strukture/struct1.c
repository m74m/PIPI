#include<stdio.h>

typedef struct student Student;

struct student{
   char *ime;
   char *prezime;
   int jmbag;
};

int main()
{
   Student stud={"Ivan","Ivanovic",123};

   printf("Student se zove %s\n",stud.ime);
   printf("Student se preziva %s\n",stud.prezime);
   printf("Student ima maticni broj %d\n",stud.jmbag);
   getch();
   return 0;
}
