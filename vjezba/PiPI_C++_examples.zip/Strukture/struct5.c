#include <stdio.h>

typedef struct student Student;

struct student{
   char* ime;
   char* prezime;
   int jmbag;
};

Student uvecaj(Student stud)
{
   Student stud1;
   stud1.ime=stud.ime;
   stud1.prezime=stud.prezime;
   stud1.jmbag=stud.jmbag+1;
   return stud1;
}
int main()
{
   Student stud_stari={"Ivica","Ivanovic",44};
   Student stud_novi=uvecaj(stud_stari);
   printf("Maticni broj starog studenta: %d\n",stud_stari.jmbag);
   printf("Maticni broj novog studenta: %d\n",stud_novi.jmbag);
   getch();
   return 0;
}
