#include <iostream>
#include <vector>

using namespace std;

class Sport
{
protected:
	string ime1, ime2;
	
public:
	Sport( string _ime1, string _ime2 ) { ime1 = _ime1; ime2 = _ime2; }
	virtual string pobjeda() = 0;
};

class Tenis : public Sport
{
private:
	int brzina1, brzina2;
	string turnir;
	
public:
	Tenis( string ime1, string ime2, string _turnir = "Wimbledon" ) : Sport( ime1, ime2 ) 
	{ 
		turnir = _turnir; brzina1 = brzina2 = 0; 
		cout << "Turnir: " << turnir << endl;
	}
	
	string pobjeda()
	{
		if( brzina1 > brzina2 )
		{
			cout << "gem, set i mec " << ime1 << " " << brzina1 << endl;
			return ime1;
		}
		else
		{
			cout << "gem, set i mec " << ime2 << " " << brzina2 << endl;
			return ime2;
		}
	}
	
	void servis( string ime, int brzina )
	{
		if( ime == ime1 && brzina > brzina1 )
		    brzina1 = brzina;
		else if( ime == ime2 && brzina > brzina2 )
		    brzina2 = brzina;
	}
};


class Boks : public Sport
{
private:
	int broj1, broj2;
public:
	Boks( string ime1, string ime2 ) : Sport( ime1, ime2 ) { cout << "Pocela je 1. runda " << endl; broj1 = broj2 = 0; }
	void udarac( string ime ) { if( ime == ime1 ) ++broj1; else ++broj2; }

	string pobjeda()
	{
		if( broj1 > broj2 )
		{
			cout << "nokaut " << ime1 << " " << broj1 << ":" << broj2 << endl;
			return ime1;
		}
		else
		{
			cout << "nokaut " << ime2 << " " << broj1 << ":" << broj2 << endl;
			return ime2;
		}
	}
};

int main( void )
{
	vector<Sport *> polje;
	
	for( int i = 0; i < 50; ++i )
	{
		Boks *b = new Boks( "Mavrovic", "Lewis" );
		b->udarac( "Mavrovic" ); b->udarac( "Mavrovic" ); b->udarac( "Lewis" );
		
	    polje.push_back( b );
	}

	for( int i = 0; i < 50; ++i )
	{
		Tenis *t = new Tenis( "Federer", "Nadal" );
		t->servis( "Federer", 200 ); t->servis( "Federer", 220 ); t->servis( "Nadal", 200 );

	    polje.push_back( t );
	}
	
	for( int i = 0; i < 100; ++i )
	    polje[i]->pobjeda();
	    
	 cout <<"\n" << endl;   
     getchar();
     cout <<"\n" << endl;
     
	return 0;
}
