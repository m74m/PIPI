#include<stdio.h>

typedef struct student Student;

struct student{
   char *ime;
   char *prezime;
   int jmbag;
};

int main()
{
   int i;
   
   Student stud={"Ivan","Ivanovic",123};

   Student *studptr;
   studptr = &stud;

   printf("Studentovo ime: %s\n",stud.ime);
   printf("Studentovo prezime: %s\n",stud.prezime);
   printf("Studentov maticni broj: %d\n",stud.jmbag);

   printf("A sad koristimo pointer...\n");
   printf("Studentovo ime: %s\n",studptr->ime);
   printf("Studentovo prezime: %s\n",studptr->prezime);
   printf("Studentov maticni broj: %d\n",studptr->jmbag);
   getch();
   return 0;
}
