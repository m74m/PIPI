#include <stdio.h>

typedef struct student Student;

struct student{
   char* ime;
   char* prezime;
   int jmbag;
};

void ime(Student stud)
{
   printf("Studentovo ime: %s\n",stud.ime);
   return;
}
int main()
{
   Student stud1={"Ivica","Ivanovic",44};
   ime(stud1);
   getch();
   return 0;
}
