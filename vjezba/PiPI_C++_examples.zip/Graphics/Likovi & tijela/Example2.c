#include<graphics.h>

main() {
	
	initwindow(700, 500);
	setcolor(4);
	setlinestyle(5,1,1);
	line(320,0,320,480);
	line(0,240,640,240);
	setcolor(1);
	rectangle(50,50,280,200);
	setfillstyle(3,2);
	bar(360,280,600,440);
	setcolor(3);
	circle(165,365,100);
	settextstyle(1,0,5);
	outtextxy(340,100, "Dobro dosli!");
	while(!kbhit());     //wait for user to press a key
    closegraph();        //close graphics window
    return 0;
}
