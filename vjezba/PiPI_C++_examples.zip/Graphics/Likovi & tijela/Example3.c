#include <graphics.h>
#include <conio.h>

main() {
	
	int i;
	initwindow(800, 800);
	for(i=1;i<200;i++)
	{
		setcolor(i);
		rectangle(i+40,250-i,i+140,300-i);
	}
	getch();
	for(i=1;i<250;i++)
	{
		setcolor(i);
		circle(i+450,260-(0.7*i),50);
	}
	getch();
	for(i=1;i<200;i++)
	{
		setcolor(i);
		rectangle(i+40,i+450,i+140,i+500);
	}
	getch();
	for(i=1;i<250;i++)
	{
		setcolor(i);
		circle(i+450,460+(0.7*i),50);
	}
	getch();
	closegraph();
	return 0;
}
