  #include <stdio.h>
  #include <conio.h>
  #include <math.h>
  #include <graphics.h>
  
  int x=800, y=600;

  void nacrtajOsi() {
      int i=0;
      line(0,y/2,x,y/2);
      line(x/2,0,x/2,y);
      while ((i+x/2)<x) {
            i+=10;
            line(x/2+i,y/2-3,x/2+i,y/2+3);
            line(x/2-i,y/2-3,x/2-i,y/2+3);
      }      
      i=0;
      while ((i+y/2)<y) {
            i+=10;
            line(x/2-3,y/2-i,x/2+3,y/2-i);
            line(x/2-3,y/2+i,x/2+3,y/2+i);
      }      
  }
  

  
  void iscrtajSinusoidu(float a, float b, float c) {
       int i;
       float xvr, yvr, xvr0, yvr0; //x i y vrijednosti u tocki
       int x1, y1, x0, y0; //x i y kao koordinate tocke na ekranu
       setcolor(4);
       for (i=1; i<(x/2); i++) {
           //pozitivna strana
           xvr0=(float)(i-1)/10;
           yvr0=a*sin(b*xvr0+c); 
           x0=(int)x/2+i-1;
           y0=(int)y/2-yvr0*10;          
           xvr=(float)i/10;
           yvr=a*sin(b*xvr+c); 
           x1=(int)x/2+i;
           y1=(int)y/2-yvr*10;
           line(x0,y0,x1,y1);           

           //negativna strana
           xvr0=(float)-(i-1)/10;
           yvr0=a*sin(b*xvr0+c); 
           x0=(int)x/2-i+1;
           y0=(int)y/2-yvr0*10;          
           xvr=(float)-i/10;
           yvr=a*sin(b*xvr+c); 
           x1=(int)x/2-i;
           y1=(int)y/2-yvr*10;
           line(x0,y0,x1,y1);           
           
       }
  }

  main() 
  { 
      float a, b, c;
      printf("Program iscrtava graf funkcije oblika a*sin(b*x+c)\n");
      printf("a="); scanf("%f",&a);
      printf("b="); scanf("%f",&b);
      printf("c="); scanf("%f",&c);
      initwindow(x,y); //open a 400x300 graphics window
      nacrtajOsi();
      iscrtajSinusoidu(a,b,c);
      while(!kbhit());     //wait for user to press a key
      closegraph();        //close graphics window
      return 0; 
  }
