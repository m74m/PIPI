  #include <stdio.h>
  #include <conio.h>
  #include <string.h>
  #include <graphics.h>
  
  int x=800, y=600;

  void nacrtajOsi() {
      int i=0;
      line(0,y/2,x,y/2);
      line(x/2,0,x/2,y);
      while ((i+x/2)<x) {
            i+=10;
            line(x/2+i,y/2-3,x/2+i,y/2+3);
            line(x/2-i,y/2-3,x/2-i,y/2+3);
      }      
      i=0;
      while ((i+y/2)<y) {
            i+=10;
            line(x/2-3,y/2-i,x/2+3,y/2-i);
            line(x/2-3,y/2+i,x/2+3,y/2+i);
      }      
  }
  
  void iscrtajParabolu(float a, float b, float c) {
       int i;
       float xvr, yvr, xvr0, yvr0; //x i y vrijednosti u tocki
       int x1, y1, x0, y0; //x i y kao koordinate tocke na ekranu
       char ime_f[80]=""; //string za zapis oblika funkcije
       char str[20], strb[20], strc[20], str2[20]; //pomocni stringovi
       
       //kreiranje stringa s imenom funkcije
       strcat(ime_f,"f(x)=");

       sprintf(str2,"%.4g",a);

       strcat(ime_f,str2); //f(x)=a
       strcat(ime_f,"*x*x"); //f(x)=a*x*x
       if (b<0) {
          sprintf(strb,"%.4g",b);
          strcat(ime_f,strb); //f(x)=a*x*x+b
          strcat(ime_f,"*x"); //f(x)=a*x*x+b*x
       } else if (b>0) {
          strcat(ime_f,"+");
          sprintf(strb,"%.4g",b); 
          strcat(ime_f,strb); //f(x)=a*x*x+b
          strcat(ime_f,"*x"); //f(x)=a*x*x+b*x   
       }
       if (c<0) {
          sprintf(strc,"%.4g",c);
          strcat(ime_f,strc);
       } else if (c>0) {
          strcat(ime_f,"+");
          sprintf(strc,"%.4g",c); //f(x)=a              
          strcat(ime_f,strc);
       }
       
       //iscrtavanje funkcije
       setcolor(4);
       for (i=1; i<(x/2); i++) {
           
           //pozitivna strana
           xvr0=(float)(i-1)/10;
           yvr0=a*xvr0*xvr0+b*xvr0+c;
           x0=(int)x/2+i-1;
           y0=(int)y/2-yvr0*10;          
           xvr=(float)i/10;
           yvr=a*xvr*xvr+b*xvr+c;
           x1=(int)x/2+i;
           y1=(int)y/2-yvr*10;
           line(x0,y0,x1,y1);
           
           //ispis jednadzbe funkcije
           if ((a<0) && (y0<y) && (y1>=y)) {
              outtextxy(x0+20,y0-40,ime_f);
           }
                                
           //negativna strana
           xvr0=(float)-(i-1)/10;
           yvr0=a*xvr0*xvr0+b*xvr0+c;
           x0=(int)x/2-i+1;
           y0=(int)y/2-yvr0*10;           
           xvr=(float)-i/10;
           yvr=a*xvr*xvr+b*xvr+c;
           x1=(int)x/2-i;
           y1=(int)y/2-yvr*10;
           line(x0,y0,x1,y1);

           //ispis jednadzbe funkcije
           if ((a>0) && (y0>0) && (y1<=0)) {
              outtextxy(x0+70,y0+40,ime_f);
           }
      }
  }
  

  main() 
  { 
      float a, b, c;
      printf("Program iscrtava graf funkcije oblika a*x^2+b*x+c\n");
      printf("a="); scanf("%f",&a);
      printf("b="); scanf("%f",&b);
      printf("c="); scanf("%f",&c);
      initwindow(x,y); //open a 400x300 graphics window
      nacrtajOsi();
      iscrtajParabolu(a,b,c);
      while(!kbhit());     //wait for user to press a key
      closegraph();        //close graphics window
      return 0; 
  }
