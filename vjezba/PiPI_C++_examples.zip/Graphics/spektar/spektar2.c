#include <graphics.h>
#include <conio.h>

main() {
       
       int i, j;
       long int c=1;
       initwindow(1200, 900);
       
       for(j=0;j<9;j++) {
                           for(i=1;i<1100;i++,c++) {
                                               setcolor(c*5);
                                               line(i+10,j*100+20,i+10,j*100+80);
                                               }
       }
      while(!kbhit());     //wait for user to press a key
      closegraph(); // escape graphic mode
      return 0;
}
