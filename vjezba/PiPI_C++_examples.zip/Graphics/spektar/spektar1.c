#include <graphics.h>
#include <conio.h>

main() {
       
       int i;
       initwindow(50, 250);
       
       for(i=1;i<200;i++) {
                          setcolor(i);
                          line(20,i+10,80,i+10);
       }
      while(!kbhit());     //wait for user to press a key
      closegraph(); // escape graphic mode
      return 0;
}
