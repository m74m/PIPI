#include <graphics.h>
#include <stdlib.h>
 
int main() { 
    
   int i, j;
   
   srand(time(NULL));
   
   initwindow(800,800);
   
   for (i=0;i<15;i++) {
       for (j=0;j<15;j++) {
           setcolor(rand()%14+1);
           circle(40+50*i, 40+50*j, 25);
       }
   }
   while(!kbhit());     //wait for user to press a key
   closegraph();        //close graphics window
   return 0;
}
