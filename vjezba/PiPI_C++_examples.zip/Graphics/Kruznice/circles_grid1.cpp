#include <graphics.h>
 
int main() { 
    
   int i, j;
   
   initwindow(800,800);
   
   for (i=0;i<10;i++) {
       for (j=0;j<10;j++) {
           setcolor(i+j);
           circle(40+60*i, 40+60*j, 30);
       }
   }
   while(!kbhit());     //wait for user to press a key
   closegraph();        //close graphics window
   return 0;
}
