#include<graphics.h>

int gd, gm;
main() {
	gd=DETECT;
	initgraph(&gd, &gm,"");
	setcolor(4);
	setlinestyle(5,1,1);
	circle(250,230,200);
	arc(250,230,90,270,100);
	setfillstyle(1,14);
	pieslice(250,230,270,360,100);
	line(250,230,250,130);
	while(!kbhit());     //wait for user to press a key
    closegraph();        //close graphics window
    return 0;
}
