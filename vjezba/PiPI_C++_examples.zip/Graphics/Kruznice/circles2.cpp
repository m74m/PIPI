#include <graphics.h>

int main()
{
    initwindow(800,800);
    setcolor(5);
    circle(400,400,380);
    delay(100);
    setcolor(4);
    circle(400,400,360);
    delay(100);
    setcolor(3);
    circle(400,400,340);
    delay(100);
    setcolor(2);
    circle(400,400,320);
    delay(100);
    setcolor(1);
    circle(400,400,300);
    delay(100);
    setcolor(14);
    circle(400,400,280);
    delay(100);
    setcolor(13);
    circle(400,400,260);
    delay(100);
    setcolor(12);
    circle(400,400,240);
    delay(100);
    setcolor(11);
    circle(400,400,220);
    delay(100);
    setcolor(10);
    circle(400,400,200);
    delay(100);
    setcolor(9);
    circle(400,400,180);
    delay(100);
    setcolor(8);
    circle(400,400,160);
    delay(100);
    setcolor(7);
    circle(400,400,140);
    delay(100);
    setcolor(6);
    circle(400,400,120);
    delay(100);
    setcolor(5);
    circle(400,400,100);
    delay(100);
    setcolor(4);
    circle(400,400,80);
    delay(100);
    setcolor(3);
    circle(400,400,60);
    delay(100);
    setcolor(2);
    circle(400,400,40);
    delay(100);
    setcolor(1);
    circle(400,400,20);
    while(!kbhit());     //wait for user to press a key
    closegraph();        //close graphics window
    return 0;
}
