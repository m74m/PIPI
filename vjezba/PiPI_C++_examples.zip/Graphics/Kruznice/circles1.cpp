#include <graphics.h>
 
main()
{ 
   int gd = DETECT, gm;
   int x = 320, y = 240, radius;
 
   initgraph(&gd, &gm, "C:\\TC\\BGI");
 
   for ( radius = 25; radius <= 125 ; radius = radius + 20)
      circle(x, y, radius);
 
   while(!kbhit());     //wait for user to press a key
   closegraph();        //close graphics window
   return 0;
}
