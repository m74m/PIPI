#include <graphics.h>

int main( int argc, char** argv ) {
    
    int i, j;
    
    initwindow(800,400);
    for(i=0;i<=20;i++) {
                       for(j=0;j<=20;j++) {
                                          putpixel(100+5*i,100+5*j,10);
                                          putpixel(300+5*i,100+5*j,i);
                                          putpixel(500+5*i,100+5*j,j);
                       }
    }
    while(!kbhit());     //wait for user to press a key
    closegraph();        //close graphics window
    return 0;
    
}
