#include <graphics.h>

main() {
       
       
       initwindow(400, 400);
       
       line(50,300, 350, 300);
       
       while(!kbhit());     //wait for user to press a key
       closegraph(); // escape graphic mode
       return 0;
}
