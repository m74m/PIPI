#include <graphics.h>


main() {

       int gd=DETECT, gm;
       initgraph(&gd,&gm,"");

       int x,y, j=250 ;

       setbkcolor(WHITE);
       setcolor(LIGHTBLUE);

       outtextxy(3,5," >> TOMPEX << "); // output "line" text


       x = getmaxx();
       y = getmaxy();

       x=j; 

       line(j,0,x,y);

       x = getmaxx();
       y = getmaxy();

       y=j; 

       line(0,j,x,y);

       while(!kbhit());     //wait for user to press a key
       closegraph(); // escape graphic mode
       return 0;
}
