#include <graphics.h>

int gd, gm;

main() {
	gd=DETECT;
	initgraph(&gd, &gm,"");
	line(0,0,640,480);
	line(640,0,0,480);
	while(!kbhit());     //wait for user to press a key
    closegraph(); // escape graphic mode
    return 0;
}
