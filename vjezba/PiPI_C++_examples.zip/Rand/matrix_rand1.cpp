#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#define MAXRED 100


main () {
    
    int n, c, i;
    do {
        printf("Red matrica: "); scanf("%d",&n);
    }while (n<0 || n>MAXRED);
    srand((unsigned)time(NULL));
    for(c=0; c<=n; c++) {
        i=rand() % 6 + 1;
        printf("i[%d]=%d\n",c,i);
    }
    getch();
    return 0;
}    

