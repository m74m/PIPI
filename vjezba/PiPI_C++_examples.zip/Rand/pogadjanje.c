// Funkcija rand() vra�a slu�ajan broj izme�u 0 i RAND_MAX. (Obi�no je RAND_MAX jednak 32767).

// Ako �elimo dobiti slu�ajan prirodan broj izme�u m i n (m < n) uklju�uju�i i granice m i n, tada treba napraviti ovo:

/* int x = m + (n - m + 1) * ((float)rand() / (RAND_MAX + 1)); */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main()
{
	int br;
	int pogodak = 0;
	srand(time(NULL));
	int x = fabs(1 + 100 * ((float)rand() / (RAND_MAX + 1)));
	printf("Zamislio sam broj izmedju 1 i 100. Pogodi ga!\n");
	int brpok = 0;

	while(pogodak == 0)
	{
		printf("Unesi broj: ");
		scanf("%d", &br);
		brpok++;
		if(br == x)
		{
			printf("Bravo! Pogodio si u pokusaju br. %d\n", brpok);
			pogodak = 1;
		}
		else
		{
			if (x > br)
				printf("Trazeni broj je veci!\n");
			else
				printf("Trazeni broj je manji!\n!!");
		}
	}
    getch();
	return 0;
}

