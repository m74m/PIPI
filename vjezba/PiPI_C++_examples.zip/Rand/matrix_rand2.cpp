#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#define MAXRED 100

main () {
    
    int c1, c2, n;
    
    do {
        printf("Red matrica: "); scanf("%d",&n);
    }while (n<0 || n>MAXRED);
    
    int M1[n][n];
    
    printf("\n");
    
    srand((unsigned)time(NULL));
    for(c1=0; c1<=n; c1++) {
        for(c2=0; c2<=n; c2++) {
                M1[c1][c2]=rand() % 10;
                printf("M1[%d][%d]= %d\n",c1,c2,M1[c1][c2]);
        }
    }
    printf("\n\n");
    for(c1=0; c1<=n; c1++) printf("M1[%d][%d]= %d\n",c1,c1,M1[c1][c1]);
    
    getch();
    return 0;
    
}

