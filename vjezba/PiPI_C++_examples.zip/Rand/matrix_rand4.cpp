#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#define MAXRED 100

void zamijeniDijagonale ( int n, int *M1, int *M2 ) {
    
    int c, t;
    
    for(c=0; c<n; c++) {
        t=M1[c*(n+1)];
        M1[c*(n+1)]=M2[c*(n+1)];
        M2[c*(n+1)]=t;
    }
}

main () {
    
    int n, c1, c2, i;
    do {
        printf("Red matrica: "); scanf("%d",&n);
    }while (n<0 || n>MAXRED);
    
    printf("\n");
    
    int M1[n][n], M2[n][n];
    
    srand((unsigned)time(NULL));
    for(c1=0; c1<n; c1++) {
        for(c2=0; c2<n; c2++) {
                M1[c1][c2]=rand() % 10;
                M2[c1][c2]=rand() % 101 + 100;
                printf("M1[%d][%d]= %d       ",c1,c2,M1[c1][c2]);
                printf("M2[%d][%d]= %d\n",c1,c2,M2[c1][c2]);
            }
        }
        zamijeniDijagonale(n,M1[0],M2[0]);
        printf("\n\n");
        for(c1=0; c1<n; c1++) {
            for(c2=0; c2<n; c2++) {
                printf("M1[%d][%d]= %d       ",c1,c2,M1[c1][c2]);
                printf("M2[%d][%d]= %d\n",c1,c2,M2[c1][c2]);
            }    
        }    
        getch();
        return 0;
}    

