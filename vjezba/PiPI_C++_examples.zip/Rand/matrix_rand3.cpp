#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#define MAXRED 100


main () {
    
    int n, c1, c2, i;
    do {
        printf("Red matrica: "); scanf("%d",&n);
    }while (n<0 || n>MAXRED);
    
    int M1[MAXRED][MAXRED], M2[MAXRED][MAXRED];
    
    srand((unsigned)time(NULL));
    for(c1=0; c1<=n; c1++) {
        for(c2=0; c2<=n; c2++) {
                M1[c1][c2]=rand() % 10;
                M2[c1][c2]=rand() % 101 + 100;
                printf("M1[%d][%d]= %d       ",c1,c2,M1[c1][c2]);
                printf("M2[%d][%d]= %d\n",c1,c2,M2[c1][c2]);
            }
        }
        
        getch();
        return 0;
}    

