#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <stdlib.h>


main()
{
	int Rezultati[12]={0},i;
	
	srand((unsigned) time(NULL));
	int kocka1=0, kocka2=0, rezultat=0;


	for(i=1; i<=1000;i++)
	{
		
		kocka1=rand()%6 + 1;
		kocka2=rand()%6 + 1;

		rezultat=kocka1+kocka2;
		
		Rezultati[rezultat-1]++;
		
		kocka1=kocka2=rezultat=0;
	
	}

	printf("A sada... broj pojavljivanja slijedi:\n");
	
	for(i=0;i<=11;i++)
	{
		printf("Broj pojavljivanja broja %2d: je jednako= %8d.\n",(i+1), Rezultati[i]);
	}
	
	int neznam=0;
	for(i=0;i<=11;i++)
	{
		neznam+=Rezultati[i];
	}
	printf("\nda %d\n",neznam);
	getch();
}


