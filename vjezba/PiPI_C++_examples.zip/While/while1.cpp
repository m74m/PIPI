/* 01.while.cpp */
/* ucitavaju se brojevi sve dok se ne ucita 0, zatim se ispisuju suma i prosjek*/

#include <stdio.h>
#include <conio.h>

main() {
    int broj, suma=0,i=0;
    float prosjek;
    
    printf("Prva upotreba while petlje:\n\n");
    
    do {
        printf("upisi broj:");
        scanf("%d",&broj);
        suma+=broj;
        i++;
    } while (broj!=0); 
    
    prosjek=(float) suma/i;
    printf("suma= %d\n", suma);
    printf("prosjek= %.3f\n", prosjek);
    getch();
}    


