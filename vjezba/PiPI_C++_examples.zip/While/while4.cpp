#include <stdio.h>
#include <conio.h>
int broj, suma;
main () {
    do{
        printf("Broj=");
        scanf("%d", &broj);
        suma+=broj; //suma=suma+broj //1int=32bits=4bytes
    }while (broj<101);
    printf("suma upisanih brojeva je %d. ", suma);
    getch ();
}    
