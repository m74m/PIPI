/* 04.while.cpp */
/* na pocetku programa se upise volumen,a zatim se dolijeva vode u casu dok se casa ne prelije */
/* ispisuje se kolicina koja je bila u casi prije zadnjeg dijela koji je izazvao preljevanje */

#include <stdio.h>
#include <conio.h>

main() {
    int volumen, dodaj, vol_tren=0, zadnji=0;
    
    //upis volumena case (volumen mora biti pozitivan broj)
    do {
        printf("upisi volumen case: "); 
        scanf("%d",&volumen);
        if (volumen<0) {
            printf("Volumen case ne moze biti manji od 0. Ponovi upis!!!! \n");
        }    
    } while (volumen<=0);   
    
    //dolijevanje u casu
    while (vol_tren<volumen) {
        printf("Koliku kolicinu vode dodajes u casu (u casu stane jos %d)? ",volumen-vol_tren);
        scanf("%d",&dodaj);
        vol_tren+=dodaj;
    } 
    
    //da se dobije zanji volumen odzme se volumen koji je izazvao preliv case
    zadnji=vol_tren-dodaj;
    
    printf("Zadnja kolicina vode koja je stala u casu je iznosila %d.",zadnji);
             
    getch();
}

