#include<stdio.h>
#include<stdlib.h>
#include <conio.h>



void main()
{
	int broj = 0, zbroj = 0, br = 0;
	printf("\nProgram ce unositi brojeve sve dok se ne unese -1!\n");
	while (broj!=-1)
	{
		printf("\nUpisite broj: ");
		scanf("%d",&broj);
		zbroj+= broj;
		br++;
	}
	printf("\nUnjeli ste %d brojeva i njihov zbroj je %d",br-1, zbroj+1);
	
	getch();
}
