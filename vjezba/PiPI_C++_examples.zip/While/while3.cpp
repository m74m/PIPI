/* 06.while.cpp */
/* jednostavna igrica - komp generira slucajni (rand) broj */
/* igrac pogada koji je broj komp "zamislio" */

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

main() {
    int broj, x, br_pok=0;
    int seed;
    char izbor;
    
    do {
    
        printf("Upisi rand seed: "); scanf("%d",&seed);
        printf("\n");
    
        //postavljanje rand_seeda i odabir broja
        srand(seed);
        broj=rand()%100+1; //broj od 1 do 100
    
        //pogadanje
        do {
            br_pok++;
                printf("upisi broj: ");
                scanf("%d",&x);
                if (x<broj) {
                    printf("Upisani broj je manji od trazenog.\n\n");
                }    
                if (x>broj) {
                    printf("Upisani broj je veci od trazenog.\n\n");
                }    
                if (x==broj) {
                    printf("Pogodeno iz %d pokusaja.\n",br_pok);
                }
        } while (x!=broj); //dok se broj ne pogodi  
    
        printf("Zelis li ponovo igrati? ");
        scanf("%c",&izbor);
    
    } while (izbor=='D' || izbor=='d');  
          
    getch();
}  

