/* 05.while.cpp */
/* unose se brojnik i nazivnik razlomka kao dva odvojena broja */
/* upotrebom Euklidovaog algoritma se pronalazi najveca zejednicka mjera ta dva broja */
/* brojnik i nazivnik se podjele s tim brojem i dobije se skracen razlomak */

#include <stdio.h>
#include <conio.h>

main() {
    int brojnik, nazivnik;
    int prvi, drugi;
    int veci,manji,ostatak;
    int brojnik_skracen,nazivnik_skracen;
    
    printf("Upisi brojnik i nazivnik razlomka koji zelis skratiti!\n\n");   
    printf("Upisi brojnik: "); scanf("%d",&brojnik);
    printf("Upisi nazivnik: "); scanf("%d",&nazivnik);
    
    //veci od ta dva broja se spremi u varijablu max
    veci = brojnik;
    manji = nazivnik;
    if (nazivnik>veci) {
        veci=nazivnik;
        manji=brojnik;        
    }    
    
    //racunanje najvece zajednicke mjere ta dva broja
    ostatak=veci%manji;
    while (ostatak!=0) {
        veci=manji;
        manji=ostatak;
        ostatak=veci%manji;
    }
    brojnik_skracen=brojnik/manji;
    nazivnik_skracen=nazivnik/manji;
    
    printf("\nNajveca zajednicka mjera ucitanih brojeva je %d.\n",manji);
    printf("Kad se razlomak %d/%d skrati maksimalno dobije se %d/%d.\n",brojnik,nazivnik,brojnik_skracen,nazivnik_skracen);
    getch();    
}

