#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef __int64 long_long;

struct HDD_INFO
{
	unsigned block_size;
	long_long n_blocks;
};


int get_hdd_info(const char*name,struct HDD_INFO*info);
void*alloc_hdd_buffer(struct HDD_INFO*info,int nsec);
void free_hdd_buffer(void*mem,struct HDD_INFO*info,int nsec);
int  open_hdd(const char*name);
void close_hdd(int handle);
int  read_hdd(int handle,struct HDD_INFO*info,long_long blk,int count,void*buffer);
int  read_hdd_cur(int handle,struct HDD_INFO*info,int count,void*buffer);
int  seek_hdd(int handle,struct HDD_INFO*info,long_long blk);

long_long get_kernel_time();
long_long get_user_time();

//long_long tsc_per_sec;

//long_long rdtsc() { 
//	__asm rdtsc 
//}

int test_hdd(const char*name,unsigned flags);


int test_multisect(int handle,struct HDD_INFO*info,int nreps,int maxsects,int nresults,double*result_speeds)
{
	void*buf;
	int rep_no;
	int cur_res;
	int start_sect=0;
	buf=alloc_hdd_buffer(info,maxsects);
	if (!buf) return -1;
	printf("%15s%15s%15s%15s\n"/*%15s%15s\n"*/,"N Blocks","N Reps","Time,ms","Speed,MB/s"/*,"Kernel","User"*/);
	for (cur_res=0;cur_res<nresults;cur_res++) {
		int n_sects=cur_res*(maxsects-1)/(nresults-1)+1;
		int nb=info->block_size*n_sects;
//		long_long ut1,ut2,kt1,kt2, st1,st2,rt;
		long_long t1, t2, dt;
		double sp;
		seek_hdd(handle,info,start_sect);
//		ut1=get_user_time();
//		kt1=get_kernel_time();
//		st1=rdtsc();
//		t1=st1;
		t1=GetTickCount();
		rep_no=nreps;
		if (rep_no*n_sects>info->n_blocks) rep_no=info->n_blocks/n_sects;
		for (;rep_no;rep_no--)
			read_hdd_cur(handle,info,n_sects,buf);
//		st2=rdtsc();
		t2=GetTickCount();
//		t2=st2;
//		ut2=get_user_time();
//		kt2=get_kernel_time();
//		dt=(t2-t1)*1000/tsc_per_sec;
		dt=t2-t1;
		if (!dt) dt=1;
//		rt=st2-st1;
//		if (!rt) rt=1;
//		printf("<%i>\n",(int)(kt2-kt1));
		sp=(double)nb*nreps/(dt/1e3)/1024.0/1024.0;
		printf("%15i%15i%15i%15f\n"/*%15i%%%15i%%\n"*/,n_sects,nreps,(int)dt,sp/*,(int)((kt2-kt1)*tsc_per_sec/100000/rt),(int)((ut2-ut1)*tsc_per_sec/100000/rt)*/);
		if (dt>10000) nreps>>=1;
		if (dt<500) nreps<<=1;
	}
	free_hdd_buffer(buf,info,maxsects);
	return 0;
}


int test_randomread_range(int handle,struct HDD_INFO*info,int nreps,long_long range)
{
	void*buf;
	int rep_no;
	int t1,t2,dt;
	int nb;
	long_long lblk=-1;
	double sp;
	buf=alloc_hdd_buffer(info,1);
	if (!buf) return -1;
	t1=GetTickCount();
	for (rep_no=nreps;rep_no;rep_no--) {
		long_long blk;
		do blk=rand()*range/RAND_MAX; while (blk==lblk);
		lblk=blk;
		read_hdd(handle,info,blk,1,buf);
	}
	t2=GetTickCount();
	dt=t2-t1;
	nb=nreps*info->block_size;
	sp=nb/(dt/1000.0)/1024.0/1024.0;
	free_hdd_buffer(buf,info,1);
	printf("%15i%15i%15i%15f\n",(int)range,nreps,dt,sp);
	return dt;
}


int test_randomread(int handle,struct HDD_INFO*info,int nreps)
{
	long_long range=info->n_blocks;
	printf("%15s%15s%15s%15s\n","Random range","N reps","Time,ms","Speed,MB/s");
	while (range>1) {
		int t;
		t=test_randomread_range(handle,info,nreps,range);
		range>>=1;
		if (t<4000) nreps<<=1;
	}
	return 0;
}


int test_hdd(const char*name,unsigned flags)
{
	struct HDD_INFO info;
	int handle;
	double result_speeds[20];
	if (get_hdd_info(name,&info)<0) return -1;
	printf("drive %s information: block_size=%i, n_blocks=%i\n",name,info.block_size,(int)info.n_blocks);
	handle=open_hdd(name);
	if (handle<0) {
		puts("can't open drive");
		return -1;
	}
	puts("Multisector read test\n---------------------------");
	test_multisect(handle,&info,1000,200,20,result_speeds);
	puts("Random read test\n---------------------------");
	test_randomread(handle,&info,100);
	close_hdd(handle);
	return 0;
}


int main(int argc,const char*argv[])
{
	setbuf(stdout,NULL);
	puts("Block device benchmark test suite version 0.1. Copyright (c) Nop, 2002\nMail questions to nnop@newmail.ru\n");
	SetPriorityClass(GetCurrentProcess(),REALTIME_PRIORITY_CLASS);
	SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_HIGHEST);
/*	{
		long_long t1=rdtsc(), t2;
		Sleep(1000);
		t2=rdtsc();
		tsc_per_sec=t2-t1;
		printf(">> CPU calibration value: %i Hz\n",tsc_per_sec);
	}*/
	if (argc<2) {
		return test_hdd("C:\\",0);
	} else {
		int i;
		for (i=1;i<argc;i++) {
			test_hdd(argv[i],0);
		}
	}	
	return 0;
}



int get_hdd_info(const char*name,struct HDD_INFO*info)
{
	DWORD spc, bps, nfree, ntot;
	if (!GetDiskFreeSpace(name,&spc,&bps,&nfree,&ntot)) return -1;
	info->block_size=bps;
	info->n_blocks=(long_long)spc*ntot;
	return 0;
}


void*alloc_hdd_buffer(struct HDD_INFO*info,int nsec)
{
	return VirtualAlloc(NULL,nsec*info->block_size,MEM_COMMIT,PAGE_READWRITE);
}


void free_hdd_buffer(void*mem,struct HDD_INFO*info,int nsec)
{
	VirtualFree(mem,nsec*info->block_size,MEM_DECOMMIT);
}

int  open_hdd(const char*name)
{
	char buf[10];
	wsprintf(buf,"\\\\.\\%c:",name[0]);
	return (int)CreateFile(buf,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_NO_BUFFERING,NULL);
}


void close_hdd(int handle)
{
	CloseHandle((HANDLE)handle);
}

int  read_hdd(int handle,struct HDD_INFO*info,long_long blk,int count,void*buffer)
{
	DWORD nb;
	union {
		long_long pos;
		long x[2];
	} r;
	r.pos=(long_long)blk*info->block_size;
	SetFilePointer((HANDLE)handle,r.x[0],r.x+1,FILE_BEGIN);
	if (!ReadFile((HANDLE)handle,buffer,count*info->block_size,&nb,NULL)) return -1;
	return nb/info->block_size;
}

int  read_hdd_cur(int handle,struct HDD_INFO*info,int count,void*buffer)
{
	DWORD nb;
	if (!ReadFile((HANDLE)handle,buffer,count*info->block_size,&nb,NULL)) return -1;
	return nb/info->block_size;
}

int  seek_hdd(int handle,struct HDD_INFO*info,long_long blk)
{
	union {
		long_long pos;
		long x[2];
	} r;
	r.pos=(long_long)blk*info->block_size;
	SetFilePointer((HANDLE)handle,r.x[0],r.x+1,FILE_BEGIN);
	return 0;
}


long_long get_kernel_time()
{
	long_long tc, te, tk, tu;
	if (!GetProcessTimes(GetCurrentProcess(),(FILETIME*)&tc,(FILETIME*)&te,(FILETIME*)&tk,(FILETIME*)&tu)) return -1;
	return tk;
}

long_long get_user_time()
{
	long_long tc, te, tk, tu;
	if (!GetProcessTimes(GetCurrentProcess(),(FILETIME*)&tc,(FILETIME*)&te,(FILETIME*)&tk,(FILETIME*)&tu)) return -1;
	return tu;
}
