//Objekt WaitableTimer implementiran je od verzije Win NT 4.0 pa nadalje(?)
//pa je to potrebno nazna�iti prevodiocu 

#define _WIN32_WINNT 0x0400 //kako u�initi isto na nivou cijelog projekta ?


   #include <windows.h>
   #include <stdio.h>

   #define _SECOND 10000000  // rezolucija 100ns
   
   int __try, __finally;

   typedef struct _MYDATA {
     TCHAR *szText;
     DWORD dwValue;
   } MYDATA;


   VOID CALLBACK TimerAPCProc(     // �to je to CALLBACK ?
       LPVOID lpArg,               // Pointer na podatke.
       DWORD dwTimerLowValue,      // Timer low vrijednost.
       DWORD dwTimerHighValue ) {  // Timer high vrijednost.

     MYDATA *pMyData = (MYDATA *)lpArg;

     printf( "Poruka: %s\nValue: %d\n\n", pMyData->szText,
       pMyData->dwValue );
     MessageBeep(0);

   }


   main( void ) {

     HANDLE          hTimer;
     BOOL            bSuccess;
     __int64         qwDueTime;
     LARGE_INTEGER   liDueTime;
     MYDATA          MyData;
     TCHAR           szError[255];

     MyData.szText = "Ovo su moji podaci.";
     MyData.dwValue = 100;

     if ( hTimer = CreateWaitableTimer(
           NULL,                   // Default security attributes.
           FALSE,                  // Kreiraj auto-reset timer.
           "MyTimer" ) ) {         // Naziv za waitable timer.

       __try; {

         // Kreiraj negativni 64-bitni integer za signalizaciju
         // timera 5 sekundi od trenutka postavljanja.
         qwDueTime = -5 * _SECOND;

         // Kopiraj relativno vrijeme u LARGE_INTEGER (struktura!).
	 // komplicirano zbog alignementa (64bit) LARGE_INTEGER strukture !
	 // __int64 ima isti binarni format, ali 32bit alignement
	 // liDueTime=( LARGE_INTEGER) qwDueTime ; ne radi uvijek !

         liDueTime.LowPart  = (DWORD) ( qwDueTime & 0xFFFFFFFF );
         liDueTime.HighPart = (LONG)  ( qwDueTime >> 32 );


         bSuccess = SetWaitableTimer(
           hTimer,            // Handle za timer object.
           &liDueTime,        // kad �e timer biti signaliziran.
           2000,              // periodi�ki interval timera od 2 sekunde.
           TimerAPCProc,      // Rutina dovr�enja (completion routine).
           &MyData,           // Argument zaklju�ne rutine.
           FALSE );           // Bez obnove suspendiranog sustava.

         if ( bSuccess ) {

           for ( ; MyData.dwValue < 1000; MyData.dwValue += 100 ) {

             SleepEx(      
               INFINITE,    // �ekaj zauvijek.
               TRUE );      // VA�NO!!! Nit mora biti u pripravnom stanju
			     // (alertable state) da bi procesirala APC.
           }

         } else {
           wsprintf( szError, "SetWaitableTimer() neuspjeh s gre�kom %d.",
             GetLastError() );
           MessageBox( NULL, szError, "Gre�ka", MB_ICONEXCLAMATION );
         }

       } __finally; {
         CloseHandle( hTimer );
       }

     } else {
       wsprintf( szError, "Kriranje objekta WaitableTimer nije uspjelo: gre�ka br. %d.",
         GetLastError() );
       MessageBox( NULL, szError, "Gre�ka", MB_ICONEXCLAMATION );
     }

   }


