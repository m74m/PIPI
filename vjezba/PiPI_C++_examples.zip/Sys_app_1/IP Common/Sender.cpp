#include <stdio.h>
#include <windows.h>
#include <conio.h>

char buf[1000]="11111111111111111111\n\
22222222222222222222\n\
33333333333333333333\n\
44444444444444444444\n\
55555555555555555555\n\
66666666666666666666\n\
77777777777777777777\n";

main(){		
	
   unsigned long brite;
   fprintf(stderr, "Sender:Process to generate the numbers\n");
   WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),buf,125,&brite,NULL); //send an extra newline char, if needed	
   getch();
}
