#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>


int main()
{

  char buf[1024];
  int i;
  unsigned long nByteRead;//pro�itano bajtova
  unsigned long avail;

  STARTUPINFO si; // koristimo prilikom pokretanja procesa
  SECURITY_ATTRIBUTES sa;   
  SECURITY_DESCRIPTOR sd; //security information for pipes
  PROCESS_INFORMATION pi;

  HANDLE fromsender_read,togetter_read,fromsender_write,togetter_write;//pipe handles

  // zbog naslje�ivanja handleova potreba za no-default secutity attributes

  InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION);
  SetSecurityDescriptorDacl(&sd, TRUE, NULL, FALSE);

  sa.lpSecurityDescriptor = &sd;  
  sa.nLength = sizeof(SECURITY_ATTRIBUTES);
  sa.bInheritHandle = TRUE; //dozvoli naslje�ivanje handleova


  if (!CreatePipe(&fromsender_read,&fromsender_write,&sa,0))//kreiraj ulaznu cijev
  { 
	printf("Kreiranje cijevi : greska");
	
    return 1;
  }

  if (!CreatePipe(&togetter_read,&togetter_write,&sa,0))//kreiraj izlaznu cijev
  { 
	printf("Kreiranje cijevi : greska");
	getch();
    return 1;
  }

  // sekcija za pokretanje sender.exe procesa

  GetStartupInfo(&si); //postavi startupinfo

  si.dwFlags = STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;  
  si.hStdOutput = fromsender_write;  
  si.hStdError = GetStdHandle(STD_ERROR_HANDLE);  
  si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);

  if (!CreateProcess("sender.exe",NULL,NULL,NULL,TRUE,CREATE_NEW_CONSOLE,
                     NULL,NULL,&si,&pi))
  {
      printf("Kreiranje senderproc : greska");
      getch();
      return 2;
  }

  // sekcija za pokretanje getter.exe procesa

  GetStartupInfo(&si); //postavi startupinfo

  si.dwFlags = STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;  
  si.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  si.hStdError = GetStdHandle(STD_ERROR_HANDLE);  
  si.hStdInput = togetter_read;  

  if (!CreateProcess("getter.exe",NULL,NULL,NULL,TRUE,CREATE_NEW_CONSOLE,
                     NULL,NULL,&si,&pi))
  {
    printf("Kreiranje getterproc : greska");
    getch();
    return 2;
  }

  

	ReadFile(fromsender_read,buf,1023,&nByteRead,NULL);//read the stdout pipe
	printf("Middleware proces je vratio:\n");	

	for(i=0; i<(int)nByteRead; i++)putchar(buf[i]);
	WriteFile(togetter_write,buf,nByteRead,&avail,NULL);

	getch();
	
  
  CloseHandle(pi.hThread);
  CloseHandle(pi.hProcess);  

}
