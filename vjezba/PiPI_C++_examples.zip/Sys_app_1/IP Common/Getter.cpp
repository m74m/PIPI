#include <windows.h>
#include <stdio.h>
#include <conio.h>

int main()
{
  int i;
  char buf[1024];             
  unsigned long bread;   //bytes read  
  ZeroMemory(buf,1024);

	printf("Getter:getting....\n");
	ReadFile(GetStdHandle(STD_INPUT_HANDLE),buf,1023,&bread,NULL);  //read the stdout pipe
	printf("number of chars read in: %d \n",bread);
	printf("done\n");	
    for(i=0;i<(int)bread;i++)putchar(buf[i]);	
    getch();
  
}

