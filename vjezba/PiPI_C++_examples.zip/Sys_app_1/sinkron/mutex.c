#include <string.h>
#include <windows.h>
#include <stdio.h>


HANDLE hMutex;



DWORD WINAPI novaFunkcija (LPVOID parametriNiti)
{
	int j,i;
	for(j=0; j<10; j++){
        // ceka dok mutex objekt ne postane signaliziran (bez vlasnistva)
		while(WaitForSingleObject(hMutex,INFINITE));		
		for(i=0; i<30; i++){
			printf("Nit II : i=%d \n",i+j*1000+1);		
		}
		ReleaseMutex(hMutex);
	    
	}	
	return 0;
}


main()
{
	HANDLE hThread;
	int j,i;

	// mutex objekt - inicijalno bez vlasni�tva
	hMutex=CreateMutex(NULL,FALSE,NULL);

	// kreiraj novu nit
	hThread=CreateThread(NULL,0,novaFunkcija,NULL,0,0);

	for(j=0; j<10; j++){
        // ceka dok mutex objekt ne postane signaliziran (bez vlasnistva)
		while(WaitForSingleObject(hMutex,INFINITE));
		// sad je ova nit vlasnik mutex objekta
		for(i=0; i<30; i++){
			printf("Nit I : i=%d \n",j*1000+i+1);		
		}		
		ReleaseMutex(hMutex); // otpusti vlasnistvo

	}	
	
	CloseHandle(hThread);
	getchar();

}