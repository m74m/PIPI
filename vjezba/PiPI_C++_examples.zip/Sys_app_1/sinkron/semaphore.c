#include <string.h>
#include <windows.h>
#include <stdio.h>


HANDLE hSemafor1;
HANDLE hSemafor2;


DWORD WINAPI novaFunkcija (LPVOID parametriNiti){
	int j,i;
	for(j=0; j<10; j++){

		while(WaitForSingleObject(hSemafor2,INFINITE));	
		// kriti�na sekcija - po�etak
		for(i=0; i<10; i++){
			printf("thread II : i=%d \n",i+j*1000+1);		
		}		
		// kriti�na sekcija - kraj
	    ReleaseSemaphore(hSemafor1,1,NULL);
	}	
	return 0;
}

main()

{
	HANDLE hThread;
	int j,i;
	hSemafor1=CreateSemaphore(NULL,1,1,NULL);
	hSemafor2=CreateSemaphore(NULL,0,1,NULL);

	hThread=CreateThread(NULL,0,novaFunkcija,NULL,0,0);
	for(j=0; j<10; j++){

		while(WaitForSingleObject(hSemafor1,INFINITE));		
		for(i=0; i<10; i++){
			printf("thread I : i=%d \n",j*1000+i+1);		
		}		
		ReleaseSemaphore(hSemafor2,1,NULL);

	}	
	
	CloseHandle(hThread);
	getchar();

}