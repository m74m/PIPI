#include <string.h>
#include <windows.h>
#include <stdio.h>

HANDLE heve1; // globalna varijabla !!!

DWORD WINAPI novaFunkcija1 (LPVOID parametriNiti){
	int i;
	WaitForSingleObject(heve1, INFINITE); // �eka na signal event objekta
	for(i=0; i<50; i++){
		printf("Nit I: i=%d \n",i);		
	}
	return 0;
}

DWORD WINAPI novaFunkcija2 (LPVOID parametriNiti){
	int  i;
	WaitForSingleObject(heve1, INFINITE); // �eka na signal event objekta
	for(i=0; i<50; i++){
		printf("Nit II: i=%d \n",i);		
	}
	return 0;
}

main()
{
	HANDLE hThread[2];
	int i;
	
	//heve1=CreateEvent(NULL,TRUE,FALSE,NULL); // manualni reset
	heve1=CreateEvent(NULL,FALSE,FALSE,NULL); // auto reset

	// kreiraj dvije niti 
	hThread[0]=CreateThread(NULL,0,novaFunkcija1,NULL,0,0);
	hThread[1]=CreateThread(NULL,0,novaFunkcija2,NULL,0,0);

	for(i=0; i<10; i++){
			printf("Kontrolna nit -> step %d \n",i+1);		
		}

	
	SetEvent(heve1); // postavi event u signalizirano stanje

	// �eka na zavr�etak niti (proslije�eni handleovi niti)
	// nitje tako�er sinkronizacijski objekt koji zavr�etkom
	// dolazi u signalizirano stanje
	WaitForMultipleObjects(2,hThread,TRUE,INFINITE);  
	getchar();
}