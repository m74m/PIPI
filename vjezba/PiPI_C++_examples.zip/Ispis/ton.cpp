#include <stdio.h>
#include <conio.h>
main () {
 printf("\a\n");
 getch();
 return 0;
}
