#include <stdio.h>

int main () {
    int n;
    printf("n="); scanf("%d", &n);
    printf("n(dec)=%d\nn(oct)=%o\nn(hex)=%x\nn(0 oct)=%#o\nn(0xhex)=%#x\n",n, n, n, n ,n);
    getch();
}
