#include <stdio.h>

int main() {

    float alpha=2.3e-4, beta=1.03, gama=3.4e5, delta=6.7;

    printf("\n  %f, \n  %g, \n  %e, \n  %E \n", alpha, beta, gama, delta);

    getch();

}



