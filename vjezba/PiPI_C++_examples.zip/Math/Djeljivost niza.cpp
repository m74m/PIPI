
#include <stdio.h>
#include <conio.h>

int main () {
    int i, n;
    printf("Unesite gornju granicu niza: ");
    scanf("%d",&n);
    for (i=1; i<=n; i++) {
        if (i%3) printf("%d*2=%d\n", i, i*2);
        else printf("%d je djeljiv s 3\n", i);
    }
    getch();
    return 0;
}