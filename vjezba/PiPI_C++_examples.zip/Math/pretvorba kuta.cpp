#include <stdio.h>
#include <conio.h>
#include <math.h>

int izbor;
float kut;

float pretvori(float a) {
    return a*M_PI/180;
}    

float sinus(float x) {
    float xp=pretvori(x);
    return sin(xp);
}    

float kosinus(float x) {
    float xp=pretvori(x);
    return cos(xp);
}    

float tangens(float x) {
    float xp=pretvori(x);
    return tan(xp);
}    

void izbornik() {
    printf("\n\n1 - racunanje sinusa kuta\n");
    printf("2 - racunanje kosinusa kuta\n");
    printf("3 - racunanje tangensa kuta\n");
    printf("4 - racunanje kotangensa kuta\n");
    printf("5 - izlaz\n\n");
    printf("Unesi izbor: ");
    if(!scanf("%d",&izbor)) {getchar(); /*Empty buffer*/ return;}
    if (izbor==1) {
        printf("Racunanje sinusa -> Unesi kut u stupnjevima -> ");
        scanf("%f",&kut);
        printf("sin(%.3f)=%.3f\n",kut,sinus(kut));      
    }    
    if (izbor==2) {
        printf("Racunanje kosinusa -> Unesi kut u stupnjevima -> ");
        scanf("%f",&kut);
        printf("cos(%.3f)=%.3f\n",kut,kosinus(kut));      
    } 
    if (izbor==3) {
        printf("Racunanje tangensa -> Unesi kut u stupnjevima -> ");
        scanf("%f",&kut);
        printf("tg(%.3f)=%.3f\n",kut,tangens(kut));   
	}
	if (izbor==4) {
        printf("Racunanje kotangensa -> Unesi kut u stupnjevima -> ");
        scanf("%f",&kut);
        printf("ctg(%.3f)=%.3f\n",kut,1/tangens(kut));   
	}
}    

int main() {
    do {
        izbornik();
    } while (izbor!=5);    
}
