#include <stdio.h>
#include <math.h>

int main()
{
	float a, b, c;
	float D;
	float x1, x2, x1r, x2r, x1i, x2i;

    printf("Ovaj program izracunava rezultat kvadratne jednadzbe ax^2+bx+c=0. \n");
	printf("Unesi a: ");
	scanf("%f", &a);
	printf("Unesi b: ");
	scanf("%f", &b);
	printf("Unesi c: ");
	scanf("%f", &c);

	D = b * b - 4 * a * c;
	if(D >= 0)
	{
		x1 = (-b - sqrt(D)) / (2 * a);
		x2 = (-b + sqrt(D)) / (2 * a);
		printf("x1 = %f\n", x1);
		printf("x2 = %f\n", x2);
	}
	else
	{
		printf("Rjesenja su kompleksni brojevi!\n\n");
		x1r = x2r = (-b/(2*a));
		D=sqrt(fabs(D));
		x1i=x2i=D/(2*a);
		printf("x1 = %f + %fi\n",x1r, x1i);
		printf("X2 = %f - %fi\n",x2r, x2i);
	}

	getch();
	return 0;
}

