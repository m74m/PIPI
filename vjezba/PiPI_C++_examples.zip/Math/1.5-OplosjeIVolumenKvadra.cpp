//program ucitava stranice kvadara i racuna oplosje i volumen

#include <stdio.h>
#include <conio.h>

float a,b,c,O,V;

main() {
    //unos podataka
    printf("Unesi stranice kvadra:\n");
    printf("a= "); scanf("%f",&a);
    printf("b= "); scanf("%f",&b);
    printf("c= "); scanf("%f",&c);
    
    //racunanje
    V=a*b*c;
    O=2*a*b+2*b*c+2*a*c;
    
    //ispis rezultata
    printf("Volumen kvadra iznosi V=%.3f, a oplosje O=%.3f.",V,O);
    getch();
}    

