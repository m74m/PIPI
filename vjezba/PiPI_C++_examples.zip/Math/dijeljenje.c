#include <stdio.h>

int main () {

    int a, b, q, r;

    printf("a="); scanf("%d", &a);
    printf("b="); scanf("%d", &b);

    q=a/b;
    r=a%b;

    printf("Kvocijent dijeljenja a:b=%d, a ostatak iznosi: %d",q,r);
    getch();
}
