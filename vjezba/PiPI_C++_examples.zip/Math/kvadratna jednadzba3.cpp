//Ovaj program izracunava rezultat kvadratne jednadzbe axx+bx+c=0.
# include <stdio.h>
# include <conio.h>
# include <math.h>
float a, b, c, D, x1, x2, Re_x, Im_x;
main () {
    //unos varijabli
    printf("Ovaj program izracunava rezultat kvadratne jednadzbe axx+bx+c=0. \na=");
    scanf("%f", &a);
    printf("b=");
    scanf("%f", &b);
    printf("c=");
    scanf("%f", &c);
    
    //ra�unanje i ispis rezultata
    D=pow(b,2)-4*a*c;
    if(D>0) {
        x1=((-b-sqrt(D))/(2*a));
        x2=((-b+sqrt(D))/(2*a));
        printf("x1= %.3f\n",x1);
        printf("x2= %.3f\n",x2);
    }
    if(D==0) {
        x1=x2=(-b)/(2*a);
        printf("x1=x2= %.3f\n",x1);
    }
    if(D<0) {
        Re_x=(-b)/(2*a);
        Im_x=sqrt(fabs(D))/(2*a);
        printf("x1= %.3f + %.3f * i\n",Re_x,Im_x);
        printf("x2= %.3f - %.3f * i\n",Re_x,Im_x);
    }    
    getch();
}    
