//Ovaj program izracunava oplosje i volumen kvadra.
# include <stdio.h>
# include <conio.h>
# include <math.h>
float a, b, c, d, V, Op;
main () {
    //unos podataka
    printf("Ovaj program izracunava oplosje i volumen kvadra. \n");
    printf("Stranica a=");  scanf("%f", &a);
    printf("Stranica b=");  scanf("%f", &b);
    printf("Stranica c=");  scanf("%f", &c);
    
    //ra�unanje
    d=sqrt(a*a+b*b+c*c);
    Op=2*(a*b+a*c+b*c);
    V=a*b*c;
    
    //ispis rezultata
    printf("Diagonala kvadra iznosi: %.4f.\n", d);
    printf("Oplosje kvadra iznosi: %.4f.\n", Op);
    printf("Volumen kvadra iznosi: %.4f.\n", V);
    getch();
}    
