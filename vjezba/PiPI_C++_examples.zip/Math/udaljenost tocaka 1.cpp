//Ovaj program izracunava udaljenost tocaka u koordinatnom sustavu.
#include <stdio.h>
#include <conio.h>
#include <math.h>
float x_1, x_2, y_1, y_2, d;
main () {
    //unos podataka
    printf("Ovaj program izracunava udaljenost \ntocaka u koordinatnom sustavu u ravnini. \n");
    printf("A(x1, y1) \nB(x2, y2) \n");
    printf("x1=");  scanf("%f", &x_1);
    printf("y1=");  scanf("%f", &y_1);
    printf("x2=");  scanf("%f", &x_2);
    printf("y2=");  scanf("%f", &y_2);
    
    //ra�unanje
    d=sqrt(pow((x_2-x_1),2)+pow((y_2-y_1),2));
    
    //ispis rezultata
    printf("Udaljenost tocaka d(A,B) iznosi: %.4f.\n", d);
    getch ();
}    
