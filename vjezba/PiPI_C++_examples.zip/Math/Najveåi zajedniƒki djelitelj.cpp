#include <stdio.h>
#include <string.h>
#include <conio.h>

int veci (int a, int b) {

    if(a>=b) return a;
    else return b;
}



void ispis_crte() { printf("    +------------+------------+--------+\n"); }

main () {

     int c=2, m, m0, n, n0, D=1;
     printf("m="); scanf("%d",&m);
     printf("n="); scanf("%d",&n);
     m0=m;
     n0=n;
     printf("\n");
     int Z[veci(m,n)];
     memset(Z,0,sizeof(Z));
     ispis_crte();
     while((c<=m)&&(c<=n)) {
              if((m%c==0)&&(n%c==0)) { printf("    |%12d|%12d|%8d|\n",m,n,c); m/=c; n/=c; ispis_crte(); D*=c; c=2; }
              else c++;
     }
     printf("    |%12d|%12d|      //|\n",m,n);
     ispis_crte();
     printf("\n\n");
     printf("Najveci zajednicki djelitelj brojeva m=%d, i n=%d je broj %d\n",m0,n0,D);
     getch ();
     return 0;
}
