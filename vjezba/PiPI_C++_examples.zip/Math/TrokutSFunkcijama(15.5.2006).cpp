/* za trokut se ucitavaju stranice u funkciji */
/* zatim se pomocu funkcija racunaju poluopseg, opseg, povrsina */

#include <stdio.h>
#include <conio.h>
#include <math.h>

float a,b,c;
float s,O,P;

//upis globalnih varijabli
void upis(){
    printf("Upisi stranice trokuta:\n");
    printf("a= "); scanf("%f",&a);
    printf("b= "); scanf("%f",&b);
    printf("c= "); scanf("%f",&c);
}    


//provjerava da li su tri broja stranice trokuta
int provjera(float a, float b, float c) {
    int x=0; //znaci da pretpostavka nije tocna
    if (((a+b)>c) && ((a+c)>b) && ((b+c)>a)) {
        x=1;
    } 
    return x;   
} 

//racuanje opsega trokuta    
float opseg(float a, float b, float c) {
    return (a+b+c);
}   

//racunanje poluopsega trokuta
float poluopseg(float a, float b, float c) {
    return (opseg(a,b,c)/2);
}

//racunanje povrsine trokuta
float povrsina(float a, float b, float c){
    float sp;
    sp=poluopseg(a,b,c);
    return (sqrt(sp*(sp-a)*(sp-b)*(sp-c)));
}    

main() {
    upis();
    if (provjera(a,b,c)==0) {
        printf("Uneseni brojevi nisu stranice trokuta.\n");
    }    
    else {
        O=opseg(a,b,c);  
        s=poluopseg(a,b,c);     
        P=povrsina(a,b,c);
        printf("Poluopseg iznosi %.3f.\n",s);
        printf("Opseg iznosi %.3f.\n",O);
        printf("Povrsina iznosi %.3f.\n",P);         
    }    
    getch();
}    
