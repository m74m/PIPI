
#include <stdio.h>
#include <conio.h>

int c, n;

main () {
     
     printf("n="); scanf("%d",&n);
     printf("\n");
     printf("Broj n=%d djeljiv je s:\n\n",n);
     for(c=1; c<=n; c++) {
              if(n%c==0)  printf("  %d\n",c);
     }
     getch ();
     return 0;
}
