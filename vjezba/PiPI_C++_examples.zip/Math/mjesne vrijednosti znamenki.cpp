#include <stdio.h>
#include <conio.h>

void Ispisi_crtu () {
     printf("+------------------------------------+-+\n");
     }

main () {
     int n, c, z[10];
     printf("n="); scanf("%d",&n);
     if(n<0) return 0;
     for (c=0; c<=10; c++) {
         z[c]=n%10;
         n=((n-n%10)/10);
         }
     Ispisi_crtu ();
     printf("|Znamenka jedinica iznosi:           |%1d|\n",z[0]);
     Ispisi_crtu ();
     printf("|Znamenka desetica iznosi:           |%1d|\n",z[1]);
     Ispisi_crtu ();
     printf("|Znamenka stotica iznosi:            |%1d|\n",z[2]);
     Ispisi_crtu ();
     printf("|Znamenka tisucica iznosi:           |%1d|\n",z[3]);
     Ispisi_crtu ();
     printf("|Znamenka deset_tisucica iznosi:     |%1d|\n",z[4]);
     Ispisi_crtu ();
     printf("|Znamenka sto_tisucica iznosi:       |%1d|\n",z[5]);
     Ispisi_crtu ();
     printf("|Znamenka milijuntica iznosi:        |%1d|\n",z[6]);
     Ispisi_crtu ();
     printf("|Znamenka deset_milijuntica iznosi:  |%1d|\n",z[7]);
     Ispisi_crtu ();
     printf("|Znamenka sto_milijuntica iznosi:    |%1d|\n",z[8]);
     Ispisi_crtu ();
     getch();
}
