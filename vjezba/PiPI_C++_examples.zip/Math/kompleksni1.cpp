//Program ucitava 2 kompleksna broja i vr�i 2 ra�unske operacije
# include <stdio.h>
# include <conio.h>
float x1, y1, x2, y2, z1, z2, r1, r2;
main () {
    printf("Program ucitava 2 kompleksna broja i vrsi 2 racunske operacije.\n");
    //Unos podataka
    printf("Z1=x1+y1i \n");
    printf("Z2=x2+y2i \n\n");
    printf("x1="); scanf("%f", &x1);
    printf("y1="); scanf("%f", &y1);
    printf("x2="); scanf("%f", &x2);
    printf("y2="); scanf("%f", &y2);
    
    //racunanje
    z1=x1+x2;
    z2=y1+y2;
    r1=x1-x2;
    r2=y1-y2;
    
    //ispis rezultata
    printf("Zbroj dva kompleksna broja iznosi: %.3f.", z1);
    if(z2>=0)  printf("+");
    printf(" %.3f.i \n", z2);
    printf("Razlika dva kompleksna broja iznosi: %.3f.", r1);
    if(r2>=0)  printf("+");
    printf(" %.3f.i", r2);
    getch ();
}    
