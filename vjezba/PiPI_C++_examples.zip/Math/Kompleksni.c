#include <stdio.h>
#include <conio.h>
#include <math.h>


struct kompleksni
{
       float re;
       float im;
} z1, z2, zbroj, razlika, produkt, kvocijent;

char SGN(float Broj) {
     if(Broj>=0) return'+';
     else return'-';
}

int main(int argc, char *argv[])
{
  printf("\nUpisite prvi kompleksni broj:\n");
  printf("Re[Z1]=");
  scanf("%f", &z1.re);
  printf("Im[Z1]=");
  scanf("%f", &z1.im);
  printf("\nUpisite drugi kompleksni broj:\n");
  printf("Re[Z2]=");
  scanf("%f", &z2.re);
  printf("Im[Z2]=");
  scanf("%f", &z2.im);
  zbroj.re=z1.re+z2.re;
  zbroj.im=z1.im+z2.im;
  razlika.re=z1.re-z2.re;
  razlika.im=z1.im-z2.im;
  produkt.re=z1.re*z2.re-z1.im*z2.im;
  produkt.im=z1.re*z2.im+z1.im*z2.re;
  kvocijent.re=(z1.re*z2.re*z1.im*z2.im)/(pow(z2.re,2)+pow(z2.im,2));
  kvocijent.im=(z1.im*z2.re-z1.re*z2.im)/(pow(z2.re,2)+pow(z2.im,2));
  printf("\nZbroj je %.2f %c %.2fi",zbroj.re,SGN(zbroj.im),fabs(zbroj.im));
  printf("\nRazlika je %.2f %c %.2fi",razlika.re,SGN(razlika.im),fabs(razlika.im));
  printf("\nProdukt je %.2f %c %.2fi",produkt.re,SGN(produkt.im),fabs(produkt.im));
  printf("\nKvocijent je %.2f %c %.2fi\n\n",kvocijent.re,SGN(kvocijent.im),fabs(kvocijent.im));
  getch();	
  return 0;
}
