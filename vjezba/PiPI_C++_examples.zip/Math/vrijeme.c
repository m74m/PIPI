#include <stdio.h>
int t,/*sekunde*/ t_m=0,/*minute*/ t_h=0,/*sati*/ t_d=0/*dani*/;

void SecDMS() {
     
 while(t>=60) {
  t_m+=1;
  t+=(-60);
  }
  while(t_m>=60) {
  t_h+=1;
  t_m+=(-60);
  }
  while(t_h>=24) {
  t_d+=1;
  t_h+=(-24);
  }
}

int main () {
 printf("Unesite vrijeme u sekundama: "); scanf ("%d", &t);
 SecDMS();
 printf("Vrijeme je:\n%d dana,\n%d sati,\n%d minuta,\n%d sekundi.\n",t_d ,t_h ,t_m ,t);
 getch();
 return 0;
}
