#include <stdio.h>
#include <conio.h>
#include <math.h>

float rad(float a, float b) {
	return sqrt(pow(a,2)+pow(b,2));
}

int main () {
	float Tx, Ty, r;
	printf("Tocka T(x,y)\n");
	printf("x=");
	scanf("%f",&Tx);
	printf("y=");
	scanf("%f",&Ty);
	printf("radius (r)=");
	scanf("%f",&r);
	if(rad(Tx,Ty)<r) printf("Tocka T nalazi se unutar kruga!\n");
	else if(rad(Tx,Ty)==r) printf("Tocka T nalazi se na krznici!\n");
	else printf("Tocka T nalazi se izvan kruga!\n");
	getch();
	return 0;
}
