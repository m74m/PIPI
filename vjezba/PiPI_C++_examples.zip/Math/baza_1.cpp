#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

char input1[4];
char input2[2];
long num;
short baza;
char ispis[14];
short i;
short j;
int count=0;

int powint(int broj,int na)
{
    int temp = broj;
    for(short i=1;i<na;i++)
    {
        temp = temp * broj;
    }
    if(na==0)
    {
        temp=1;
    }
    return temp;
}

void reader1()
{
     printf("Unesi dekadski broj: ");
     for(i=0;i<=3;i++)
     {
         
         input1[i] = getch();
         system("cls");
         if((input1[i]>=48)&&(input1[i]<=57));
         else if(input1[i]==8)
         {
             i=i-2;
         }
         else if(input1[i]==13)
         {
             break;
         }
         else if(input1[i]==27)
         {
             exit(1);
         }
         else
         {
             i=i-1;
         }
         if(i<-1)
         {
             i=0;
         }
         printf("Unesi dekadski broj: ");
         for(short j=0;j<=i;j++)
         {
             printf("%c",input1[j]);
         }
     }
}

void reader2()
{
     system("cls");
     printf("Unesi bazu: ");
     for(j=0;j<=0;j++)
     {
         input2[j] = getch();
         system("cls");
         if((input2[j]>=49)&&(input2[j]<=57));
         else if(input2[j]==8)
         {
             j=j-2;
         }
         else if(input2[j]==13)
         {
             break;
         }
         else if(input2[j]==27)
         {
             exit(1);
         }
         else
         {
             j=j-1;
         }
         if(i<-1)
         {
             i=0;
         }
         printf("Unesi bazu: ");
         for(short f=0;f<=j;f++)
         {
             printf("%c",input2[j]);
         }
     }
     for(j=1;j<=1;j++)
     {
         if(input2[0]=='1')
         {
             input2[j] = getch();
             system("cls");
             if((input2[j]>=48)&&(input2[j]<=54));
             else if(input2[j]==8)
             {
                 j=j-2;
             }
             else if(input2[j]==27)
             {
                 exit(1);
             }
             else
             {
                 j=j-1;
             }
             if(i<-1)
             {
                 i=0;
             }
             printf("Unesi bazu: ");
             for(short f=0;f<=j;f++)
             {
                 printf("%c",input2[f]);
             }
         }
         else
         {
             break;
         }
     }
}

void converter1()
{
    short temp=i-1;
    for(short f=0;f<=i-1;f++)
    {
        num=num + (input1[f]-48)*powint(10,temp);
        temp=temp-1;
    }
}

void converter2()
{
    short temp=j-1;
    for(short f=0;f<j;f++)
    {
        baza=baza +(input2[f]-48)*powint(10,temp);
        temp=temp-1;
    }
}

void calc()
{
    int temp = num;
    int temp2;
    do
    {
        temp2 = temp;
        temp = temp/baza;
        ispis[count]=temp2-(temp*baza);
        count++;
    }while(temp>0);
}

void ispisf()
{
    system("cls");
    printf("Broj %d u bazi 10 je ",num);
    for(short f=count-1;f>=0;f--)
    {
        switch(ispis[f])
        {
            case 0:
            {
                printf("0");
                break;
            }
            case 1:
            {
                printf("1");
                break;
            }
            case 2:
            {
                printf("2");
                break;
            }
            case 3:
            {
                printf("3");
                break;
            }
            case 4:
            {
                printf("4");
                break;
            }
            case 5:
            {
                printf("5");
                break;
            }
            case 6:
            {
                printf("6");
                break;
            }
            case 7:
            {
                printf("7");
                break;
            }
            case 8:
            {
                printf("8");
                break;
            }
            case 9:
            {
                printf("9");
                break;
            }
            case 10:
            {
                printf("A");
                break;
            }
            case 11:
            {
                printf("B");
                break;
            }
            case 12:
            {
                printf("C");
                break;
            }
            case 13:
            {
                printf("D");
                break;
            }
            case 14:
            {
                printf("E");
                break;
            }
            case 15:
            {
                printf("F");
                break;
            }
        }
    }
    printf(" u bazi %d",baza);
}

int main()
{
    reader1();
    converter1();
    reader2();
    converter2();
    calc();
    ispisf();
    getch();
}
