#include <stdio.h>
#include <math.h>

float Heronova_formula_s(float s1, float s2, float s3) {
      float s;
      s=(s1+s2+s3)/2;
      return s;
      }
      
float Heronova_formula_p(float s1, float s2, float s3) {
      float s, p;
      s=(s1+s2+s3)/2;        
      p=sqrt(s*(s-s1)*(s-s2)*(s-s3));
      return p;
      }

int main () {
    
    float a, b, c, s, S, O, P;
 
    printf("a="); scanf("%f",&a);
    printf("b="); scanf("%f",&b);
    printf("c="); scanf("%f",&c);

    if ((a>0)&&(b>0)&&(c>0)&&((a+b)>c)&&((a+c)>b)&&((b+c)>a))  {
                                                               
                                                               printf("Zadani brojevi su stranice trokuta.\n");
                                                               S=Heronova_formula_s(a, b, c);
                                                               P=Heronova_formula_p(a, b, c);
                                                               O=2*S;

                                                               printf("O=%f\n", O);
                                                               printf("P=%f\n", P);
    } else printf("Zadani brojevi nisu stranice trokuta.\n");
    getch();
}
