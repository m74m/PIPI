/* Napisati program koji ima funkciju za racunanje najveceg zajednickog */
/* visekratnika i onda pomocu te funkcije skratiti razlomak zadan u glavnom programu */

#include <stdio.h>
#include <conio.h>

int brojnik, nazivnik;
int vis, brojskr, nazskr;
    
void upis() {
    printf("Upisi brojnik: "); scanf("%d",&brojnik);
    printf("Upisi nazivnik: "); scanf("%d",&nazivnik);
}    

int nzv(int br, int na) {
    int ostatak;
    int veci, manji;
    if (br>na){
        veci=br;
        manji=na;
    }    
    else {
        veci=na;
        manji=br;
    }    
    ostatak=veci%manji;
    while (ostatak!=0) {
        veci=manji;
        manji=ostatak;
        ostatak=veci%manji;
    }  
    return manji;  
} 

void skrati() {
    brojskr=brojnik/vis;
    nazskr=nazivnik/vis;
}       

main() {
    upis();
    vis=nzv(brojnik,nazivnik);
    skrati();
    printf("Skraceni razlomak je %d/%d.",brojskr,nazskr);
    getch();    
}
