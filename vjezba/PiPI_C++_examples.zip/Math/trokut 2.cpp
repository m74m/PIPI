#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

main () {
    system("color 1f");
    system("title Trokut");
    int select;
    float a, b, c, A_rd, B_rd, C_rd, A_dg, B_dg, C_dg, V_a, V_b, V_c, T_a, T_b, T_c, s, O, P, R, r;
    printf("Ovaj program izracunava stranice, kutove, opseg, povrsinu, \npolumjer u trokut upisane i trokutu opisane kruznice, \ntezisnice i visine na stranice trokuta.\n\n");
    printf("Koji su vam parametri trokuta poznati?:\n\n");
    printf("�KSK (kut-stranica-kut): pritisnite 1!          �\n");
    printf("�SKS (stranica-kut-stranica): pritisnite 2!     �\n");
    printf("�SSS (stranica-stranica-stranica): pritisnite 3!�\n");
    printf(">");
    scanf("%d", &select);
    switch(select){
        case 1: {
                //Unos varijabli
                printf("Upisi stranicu trokuta:\n");
                printf("a="); scanf("%f", &a);
                printf("Upisi susjedne kutove stranice (u stupnjevima):\n");
                printf("<ABC, beta="); scanf("%f", &B_dg);
                printf("<BCA, gamma="); scanf("%f", &C_dg);
                
                //racunanje
                if ((B_dg<180)&&(C_dg<180)&&(B_dg>0)&&(C_dg>0)&&((B_dg+C_dg)<180)&&(((B_dg>=90)&&(C_dg<90))||((B_dg<90)&&(C_dg>=90))||((B_dg<90)&&(C_dg<90)))&&(a>0)) {
                   printf("Zadani broj je stranica trokuta.\n");
                   printf("Zadani kutovi su kutovi trokuta.\n");
                   A_dg=180-(B_dg+C_dg);
                   A_rd=A_dg*M_PI/180;
                   B_rd=B_dg*M_PI/180;
                   C_rd=C_dg*M_PI/180;
                   b=(a*sin(B_rd))/sin(A_rd);
                   c=(a*sin(C_rd))/sin(A_rd);
                   if ((a==b)&&(a==c)&&(b==c)) printf("Trokut je jednakostranican!\n");
                   if ((a==b && a!=c)||(a==c && a!=b)||(b==c && b!=a)) printf("Trokut je jednakokracan!\n");
                   O=a+b+c;
                   s=O/2;
                   P=sqrt(s*(s-a)*(s-b)*(s-c));
                   V_a=2*P/a;
                   V_b=2*P/b;
                   V_c=2*P/c;
                   T_a=sqrt(pow(b,2)+pow(c,2)+2*b*c*cos(A_rd))/2;
                   T_b=sqrt(pow(a,2)+pow(c,2)+2*a*c*cos(B_rd))/2;
                   T_c=sqrt(pow(a,2)+pow(b,2)+2*a*b*cos(C_rd))/2;
                   R=(a*b*c)/(4*P);
                   r=P/s;
                   if ((A_dg==90)||(B_dg==90)||(C_dg==90))
                   printf("Trokut je pravokutan!\n"); 
                          
                   //ispis rezultata
                   printf("Stranica a iznosi: %f\n", a);
                   printf("Stranica b iznosi: %f\n", b);
                   printf("Stranica c iznosi: %f\n", c);
                   printf("Opseg trokuta iznosi: %f\n", O);
                   printf("Povrsina trokuta iznosi: %f\n", P);
                   printf("Visina na stranicu a iznosi: %f\n", V_a);
                   printf("Visina na stranicu b iznosi: %f\n", V_b);
                   printf("Visina na stranicu c iznosi: %f\n", V_c);
                   printf("Tezisnica na stranicu a iznosi: %f\n", T_a);
                   printf("Tezisnica na stranicu b iznosi: %f\n", T_b);
                   printf("Tezisnica na stranicu c iznosi: %f\n", T_c);                   
                   printf("Nasuprotni kut stranice a (<CAB, alpha) iznosi: %f�\n", A_dg);
                   printf("Nasuprotni kut stranice b (<ABC, beta) iznosi: %f�\n", B_dg);
                   printf("Nasuprotni kut stranice c (<BCA, gamma) iznosi: %f�\n", C_dg);
                   printf("Polumjer trokutu opisane kruznice iznosi: %f\n", R);
                   printf("Polumjer trokutu upisane kruznice iznosi: %f\n", r);
                   }else{
                         if (!((B_dg<180)&&(C_dg<180)&&(B_dg>0)&&((B_dg+C_dg)<180)&&(C_dg>0)&&(((B_dg>=90)&&(C_dg<90))||((B_dg<90)&&(C_dg>=90))||((B_dg<90)&&(C_dg<90))))) printf("Zadani kutovi nisu kutovi trokuta.\n");
                         if (!(a>0)) printf("Zadani broj nije stranica trokuta.");
                   }
                }
        break;
        case 2: {
                //Unos varijabli
                printf("Upisi stranice trokuta:\n");
                printf("a="); scanf("%f", &a);
                printf("b="); scanf("%f", &b);
                printf("Upisi nasuprotni kut stranice c (<BCA, gamma)(u stupnjevima) : ");
                scanf("%f", &C_dg);
                
                //racunanje
                if ((C_dg<180)&&(C_dg>0)&&(a>0)&&(b>0)) {
                   printf("Zadani brojevi su stranice trokuta.\n");
                   printf("Zadani kut je kut trokuta.\n");
                   C_rd=C_dg*M_PI/180;
                   c=sqrt(pow(a,2)+pow(b,2)-2*a*b*cos(C_rd));
                   if ((a==b)&&(a==c)&&(b==c))
                   printf("Trokut je jednakostranican!\n");
                   if ((a==b && a!=c)||(a==c && a!=b)||(b==c && b!=a))
                   printf("Trokut je jednakokracan!\n");
                   O=a+b+c;
                   s=O/2;
                   P=sqrt(s*(s-a)*(s-b)*(s-c));
                   V_a=2*P/a;
                   V_b=2*P/b;
                   V_c=2*P/c;
                   A_rd=acos((pow(b,2)+pow(c,2)-pow(a,2))/(2*b*c));
                   B_rd=acos((pow(a,2)+pow(c,2)-pow(b,2))/(2*a*c));
                   T_a=sqrt(pow(b,2)+pow(c,2)+2*b*c*cos(A_rd))/2;
                   T_b=sqrt(pow(a,2)+pow(c,2)+2*a*c*cos(B_rd))/2;
                   T_c=sqrt(pow(a,2)+pow(b,2)+2*a*b*cos(C_rd))/2;
                   R=(a*b*c)/(4*P);
                   r=P/s;
                   A_dg=A_rd*180/M_PI;
                   B_dg=B_rd*180/M_PI;
                   if ((A_dg==90)||(B_dg==90)||(C_dg==90)) printf("Trokut je pravokutan!\n");
                       
                       //ispis rezultata                       
                       printf("Stranica a iznosi: %f\n", a);
                       printf("Stranica b iznosi: %f\n", b);
                       printf("Stranica c iznosi: %f\n", c);
                       printf("Opseg trokuta iznosi: %f\n", O);
                       printf("Povrsina trokuta iznosi: %f\n", P);
                       printf("Visina na stranicu a iznosi: %f\n", V_a);
                       printf("Visina na stranicu b iznosi: %f\n", V_b);
                       printf("Visina na stranicu c iznosi: %f\n", V_c);
                       printf("Tezisnica na stranicu a iznosi: %f\n", T_a);
                       printf("Tezisnica na stranicu b iznosi: %f\n", T_b);
                       printf("Tezisnica na stranicu c iznosi: %f\n", T_c);
                       printf("Nasuprotni kut stranice a (<CAB, alpha) iznosi: %f�\n", A_dg);
                       printf("Nasuprotni kut stranice b (<ABC, beta) iznosi: %f�\n", B_dg);
                       printf("Nasuprotni kut stranice c (<BCA, gamma) iznosi: %f�\n", C_dg);;
                       printf("Polumjer trokutu opisane kruznice iznosi: %f\n", R);
                       printf("Polumjer trokutu upisane kruznice iznosi: %f\n", r);
                       }else{
                             if (!((C_dg<180)&&(C_dg>0))) printf("Zadani kut nije kut trokuta.\n");
                             if (!((a>0)&&(b>0))) printf("Zadani brojevi nisu stranice trokuta.");
                       }
                   }
                                                  
        break;
        case 3: {
                //Unos varijabli
                 printf("Upisi stranice trokuta:\n");
                 printf("a="); scanf("%f", &a);
                 printf("b="); scanf("%f", &b);
                 printf("c="); scanf("%f", &c);
                 
                 //racunanje
                 if ((a>0)&&(b>0)&&(c>0)&&((a+b)>c)&&((a+c)>b)&&((b+c)>a)) {                   
                       printf("Zadani brojevi su stranice trokuta.\n");
                       if ((a==b)&&(a==c)&&(b==c)) printf("Trokut je jednakostranican!\n");
                       if ((a==b && a!=c)||(a==c && a!=b)||(b==c && b!=a)) printf("Trokut je jednakokracan!\n");
                       O=a+b+c;
                       s=O/2;
                       P=sqrt(s*(s-a)*(s-b)*(s-c));
                       V_a=2*P/a;
                       V_b=2*P/b;
                       V_c=2*P/c;
                       A_rd=acos((pow(b,2)+pow(c,2)-pow(a,2))/(2*b*c));
                       B_rd=acos((pow(a,2)+pow(c,2)-pow(b,2))/(2*a*c));
                       C_rd=acos((pow(a,2)+pow(b,2)-pow(c,2))/(2*a*b));
                       T_a=sqrt(pow(b,2)+pow(c,2)+2*b*c*cos(A_rd))/2;
                       T_b=sqrt(pow(a,2)+pow(c,2)+2*a*c*cos(B_rd))/2;
                       T_c=sqrt(pow(a,2)+pow(b,2)+2*a*b*cos(C_rd))/2;
                       R=(a*b*c)/(4*P);
                       r=P/s;
                       A_dg=A_rd*180/M_PI;
                       B_dg=B_rd*180/M_PI;
                       C_dg=C_rd*180/M_PI;
                       if ((A_dg==90)||(B_dg==90)||(C_dg==90)) printf("Trokut je pravokutan!\n");
                       
                       
                       //ispis rezultata
                       printf("Stranica a iznosi: %f\n", a);
                       printf("Stranica b iznosi: %f\n", b);
                       printf("Stranica c iznosi: %f\n", c);
                       printf("Opseg trokuta iznosi: %f\n", O);
                       printf("Povrsina trokuta iznosi: %f\n", P);
                       printf("Visina na stranicu a iznosi: %f\n", V_a);
                       printf("Visina na stranicu b iznosi: %f\n", V_b);
                       printf("Visina na stranicu c iznosi: %f\n", V_c);
                       printf("Tezisnica na stranicu a iznosi: %f\n", T_a);
                       printf("Tezisnica na stranicu b iznosi: %f\n", T_b);
                       printf("Tezisnica na stranicu c iznosi: %f\n", T_c);
                       printf("Nasuprotni kut stranice a (<CAB, alpha) iznosi: %f�\n", A_dg);
                       printf("Nasuprotni kut stranice b (<ABC, beta) iznosi: %f�\n", B_dg);
                       printf("Nasuprotni kut stranice c (<BCA, gamma) iznosi: %f�\n", C_dg);
                       printf("Polumjer trokutu opisane kruznice iznosi: %f\n", R);
                       printf("Polumjer trokutu upisane kruznice iznosi: %f\n", r);
                       }else
                       printf("Zadani brojevi nisu stranice trokuta.");
                 }
        
                 break;
                 default: return 0 ;
                 break;
        }       
        getch ();
        return 0;
}        

