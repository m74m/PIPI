//Ovaj program izracunava rezultat kvadratne jednadzbe ax^2+bx+c=0.
# include <stdio.h>
# include <conio.h>
# include <math.h>
float a, b, c, D, x1, x2;
main () {
    //unos varijabli
    printf("Ovaj program izracunava rezultat kvadratne jednadzbe ax^2+bx+c=0. \n");
    printf("a=");
    scanf("%f", &a);
    printf("b=");
    scanf("%f", &b);
    printf("c=");
    scanf("%f", &c);
    
    //ra�unanje i ispis rezultata
    if(a==0) {
             printf("Ova jeznadzba nije kvadratna, vec je linearna!\n");
             x1=x2=-c/b;
             printf("x1=x2= %f\n",x1);
    }
    else {
         D=pow(b,2)-4*a*c;
         printf("Diskriminanta ove jednadzbe iznosi %f\n" ,D);
         if(D>0) {
            x1=((-b-sqrt(D))/(2*a));
            x2=((-b+sqrt(D))/(2*a));
            printf("x1= %f\n",x1);
            printf("x2= %f\n",x2);
            }
            if(D==0) {
            x1=x2=(-b)/(2*a);
            printf("x1=x2= %f\n",x1);
            }
            if(D<0) {
            printf("Jeznadzba nema realnog rjesenja!");
            }    
    }
    getch();
}    
