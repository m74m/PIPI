#include <stdio.h>
#include <conio.h>
int a;
main () {
    printf("Ovaj program provjerava je li broj paran ili ne.\n");
    printf("a=");
    scanf("%d", &a);
    switch(a%2){
        case 0: printf("Broj je paran.");
        break;
        case 1: printf("Broj je neparan.");
        break; 
    }           
    getch ();
}        
