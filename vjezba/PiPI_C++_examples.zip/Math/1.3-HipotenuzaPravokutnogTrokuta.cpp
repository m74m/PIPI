//program ucitava dvije katete pravokutnog trokuta i racuna hipotenuzu

#include <stdio.h>
#include <math.h>
#include <conio.h>

float a,b,c;

main() {
    //unos varijabli
    printf("Upisi duljine kateta pravokutnog trokuta\n");
    printf("a= "); scanf("%f",&a);
    printf("b= "); scanf("%f",&b);
    
    //racunanje
    c=sqrt(a*a+b*b);
    
    //ispis rezultata
    printf("Hipotenuza c pravokutnog trokuta ima duljinu %.3f.\n",c);
    getch();
}    

