//Ovaj program izracunava poloviste duzine u koordinatnom sustavu.
# include <stdio.h>
# include <conio.h>
# include <math.h>
float x_1, x_2, y_1, y_2, Px, Py;
main () {
    //Unos podataka
    printf("Ovaj program izracunava poloviste duzine u koordinatnom sustavu. \n");
    printf("x1=");
    scanf("%f", &x_1);
    printf("x2=");
    scanf("%f", &x_2);
    printf("y1=");
    scanf("%f", &y_1);
    printf("y2=");
    scanf("%f", &y_2);
    
    //Racunanje
    Px=(x_1+x_2)/2;
    Py=(y_1+y_2)/2;
    
    //ispis rezulata
    printf("Poloviste duzine P(A,B) iznosi:\n");
    printf("apscisa : %.4f\n", Px);
    printf("ordinata : %.4f\n", Py);
    getch();
}    
