
#include <stdio.h>


int main(void) {
    long num; // broj koji provjeravamo
    long div; // potencijalni djelitelj
    unsigned flag = 0; // prim broj?
    printf("Unesite cijeli broj ili q za izlaz: ");
    while(scanf("%ld",&num) == 1) {
                            for(div=2; (div*div) <= num; ++div) {
                                       if(num % div == 0) {
                                              if(div * div != num)
                                              printf("%d je djeljiv s %d i %d\n", num, div, num/div);
                                              else
                                              printf("%d je djeljiv s %d.\n", num, div);
                                              flag=1;
                                       }
                            }
                            if(flag == 0) printf("%ld je prom broj.\n",num);
                            printf("Unesite cijeli broj ili q za izlaz: ");
    }
    return 0;
}