#include <stdio.h>
#include <string.h>
#define SIZE 1000

int main()
{
	int polje[SIZE];
	int i,n,x;
	
	
	for (i=1; i<=SIZE; i++)
	{
		polje[i]=1;
	}
		
	for(x=2;x<SIZE;x++)
		for(n=x+1;n<SIZE;n++)
			if(!(n % x))
				polje[n]=0;
	
	for(n=2;n<SIZE;n++)
		if(polje[n])
			printf("%d je prost broj\n",n);
	getch();
	return 0;
}
