#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

main () {
    system("color 1f");
    system("title Paralelogram");
    float a, b, A_rd, B_rd, A_dg, B_dg, F_rd, F_dg, P_rd, P_dg, V_a, V_b, O, P, R, r, e, f;
    printf("Ovaj program izracunava stranice, kutove, opseg, povrsinu, \nkutove u sjecistu diagonala i visine na stranice paralelograma.\n");
    
    //Unos varijabli
    printf("Upisi stranice paralelograma:\n");
    printf("a="); scanf("%f", &a);
    printf("b="); scanf("%f", &b);
    printf("Upisite susjedni kut stranica a i b (u stupnjevima):\n");
    printf("<DAB (alpha)="); scanf("%f", &A_dg);
                
    //racunanje
    if ((a>0)&&(b>0)&&(A_dg>0)&&(A_dg<180)) {
    B_dg=180-A_dg;
    A_rd=A_dg*M_PI/180;
    B_rd=B_dg*M_PI/180;
    O=2*(a+b);
    P=a*b*sin(A_rd);
    V_a=P/a;
    V_b=P/b;
    e=sqrt(pow(a,2)+pow(b,2)-2*a*b*cos(B_rd));
    f=sqrt(pow(a,2)+pow(b,2)-2*a*b*cos(A_rd));
    F_rd=acos((pow((e/2),2)+pow((f/2),2)-pow(a,2))/((e*f)/2));
    P_rd=acos((pow((e/2),2)+pow((f/2),2)-pow(b,2))/((e*f)/2));
    F_dg=F_rd*180/M_PI;
    P_dg=P_rd*180/M_PI;
                
    //ispis rezultata
    printf("Stranica a iznosi: %f\n", a);
    printf("Stranica b iznosi: %f\n", b);
    printf("Opseg paralelograma iznosi: %f\n", O);
    printf("Povrsina paralelograma iznosi: %f\n", P);
    printf("Visina na stranicu a iznosi: %f\n", V_a);
    printf("Visina na stranicu b iznosi: %f\n", V_b);
    printf("Diagonala e (AC) iznosi: %f\n", e);
    printf("Diagonala f (BD) iznosi: %f\n", f);
    printf("Kut alpha (<DAB, BCD) iznosi: %f�\n", A_dg);
    printf("Kut beta (<ABC, CDA) iznosi: %f�\n", B_dg);
    printf("Kut u sjecistu diagonala <BSA, <DSC  iznosi:%f�\n", F_dg);
    printf("Kut u sjecistu diagonala <CSB, <ASD  iznosi:%f�\n", P_dg);
    if (A_dg==90){ printf("Paralelogram je pravokutnik!\n"); if (a==b) printf("Pravokutnik je kvadrat!\n"); }
    }else {
    if (!((a>0)&&(b>0))) printf("Zadani brojevi nisu stranice paralelograma.\n");
    if (!((A_dg>0)&&(A_dg<180))) printf("Zadani kut nije kut paralelograma.\n");
    }
    
    getch ();
    return 0;
}        
