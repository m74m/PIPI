//Ovaj program izracunava kvadratni korijen od broja a.
# include <stdio.h>
# include <conio.h>
# include <math.h>
float a, b;
main(){
    printf("Ovaj program izracunava kvadratni korijen od broja a. \n");
    printf("a=");
    scanf("%f", &a);
    b=sqrt(a);
    printf("Kvadratni korijen od broja a iznosi %.3f.\n", b);
    getch();
}    
