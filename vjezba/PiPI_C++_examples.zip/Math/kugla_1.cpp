//Ovaj program izracunava oplosje i volumen kugle.
# include <stdio.h>
# include <conio.h>
#include <math.h>
float r, Op, V;
main () {
    //unos podataka
    printf("Ovaj program izracunava oplosje i volumen kugle. \n");
    printf("Polumjer r=");  scanf("%f", &r);
    
    //ra�unanje
    Op=4*r*r*3.141;
    V=(4*r*r*r*3.141)/3;
    
    //ispis rezultata
    printf("Oplosje kugle iznosi: %.4f.\n", Op);
    printf("Volumen kugle iznosi: %.4f.\n", V);
    getch();
}    
