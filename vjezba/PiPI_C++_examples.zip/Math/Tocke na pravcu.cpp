#include <stdio.h>
#include <conio.h>
#include <math.h>

int main () {
	float T1x, T1y, T2x, T2y, T3x, T3y, a, b;
	printf("Tocka T[1](x,y)\n");
	printf("x="); scanf("%f",&T1x);
	printf("y="); scanf("%f",&T1y);
	printf("Tocka T[2](x,y)\n");
	printf("x="); scanf("%f",&T2x);
	printf("y="); scanf("%f",&T2y);
	printf("Tocka T[3](x,y)\n");
	printf("x="); scanf("%f",&T3x);
	printf("y="); scanf("%f",&T3y);
	a=(T1y-T2y)/(T1x-T2x);
	b=T1y-a*T1x;
	printf("Jednadzba pravca: y=%f*x+%f\n",a,b);
	if(T3y==a*T3x+b) printf("Sve 3 tocke pripadaju istom pravcu!\n");
	else printf("Ne pripadaju sve tocke istom pravcu!\n");
	getch();
	return 0;
}
