#include<stdio.h>
#include<conio.h>

float funkcija( float r,float *o,float *v){

      *o=4.0*r*r*3.14;
      *v=(4.0/3.0)*(r*r*r)*3.14;
return 0;
}

int main () {

    float radijus, oplosje ,volumen, f;

    printf("upisi radijus kugle:");
    scanf("%f", &radijus);

    f=funkcija( radijus, &oplosje, &volumen );

    printf("Oplosje iznosi: %f\nVolumen iznosi: %f\n", oplosje, volumen);

    getch();

    return 0;

}
