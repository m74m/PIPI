#include <stdio.h>
#include <conio.h>

int main(void) {
    int a,b,i,nbits;
    unsigned mask;
    nbits=8*sizeof(int); /* duljina tipa int */
    mask=0x1 << (nbits-1); /* 1 na najznacajnijem mjestu*/
    printf("\nUnesite cijeli broj: "); scanf("%d",&a);
    for(i=1;i<=nbits;++i) {
                          b=(a & mask) ? 1 : 0;
                          printf("%d",b);
                          if(i % 4 == 0) printf(" ");
                          mask >>= 1;
    }
    printf("\n");
    getch();
    return 0;
}
