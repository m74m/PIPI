//Ovaj program izracunava opseg, povrsinu i visine trokuta.
# include <stdio.h>
# include <conio.h>
# include <math.h>
float a, b, c, s, O, P, Va, Vb, Vc;
main () {
    //Unos varijabli
    printf("Ovaj program izracunava opseg, povrsinu i visine trokuta.\n");
    printf("Upisi stranice trokuta:\n");
    printf("a="); scanf("%f", &a);
    printf("b="); scanf("%f", &b);
    printf("c="); scanf("%f", &c);
    //racunanje
    if ((a>0)&&(b>0)&&(c>0)&&((a+b)>c)&&((a+c)>b)&&((b+c)>a)) {
        printf("Zadani brojevi su stranice trokuta.\n");
        s=(a+b+c)/2;
        P=sqrt(s*(s-a)*(s-b)*(s-c));
        O=a+b+c;
        Va=2*P/a;
        Vb=2*P/b;
        Vc=2*P/c;
        //ispis rezultata
    
        printf("Opseg trokuta iznosi: %.4f.\n", O);
        printf("Povrsina trokuta iznosi: %.4f.\n", P);
        printf("Visina stranice a iznosi: %.4f.\n", Va);
        printf("Visina stranice b iznosi: %.4f.\n", Vb);
        printf("Visina stranice c iznosi: %.4f.\n", Vc);
    }else{
        printf("Zadani brojevi nisu stranice trokuta.");
    }
    getch ();
}        
