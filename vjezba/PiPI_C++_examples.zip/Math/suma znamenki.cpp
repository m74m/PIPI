#include <stdio.h>
#include <conio.h>

main () {
    int s=0, n, p;
    printf("n= "); scanf("%d", &n);
    
    p=n;
    
    while(n>0) {
        s+=n%10;
        n/=10;
    }
    
    printf("Suma znamenaka u %d iznosi: %d\n\a" ,p ,s);
    
    getch();
}
    
    
