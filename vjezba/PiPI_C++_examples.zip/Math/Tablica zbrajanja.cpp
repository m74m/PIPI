#include <stdio.h>
#include <conio.h>
void IspisCrte() {printf("+---+---+---+---+---+---+---+---+---+---+---+\n");}

int main () {
    
    int i, j;
    printf("Tablica zbrajanja:\n\n");
    IspisCrte();
    printf("| + |  1|  2|  3|  4|  5|  6|  7|  8|  9| 10|\n");
    IspisCrte();
    for(i=1; i<=10; i++){
             printf("|");
             printf("%3d",i);
             for(j=1; j<=10; j++){
                      printf("|");
                      if((i+j)<100) {if((i+j)<10) printf("  "); else printf(" "); }
                      printf("%d",i+j);
             }
             printf("|");
             printf("\n");
             IspisCrte();
    }
    getch();
}
