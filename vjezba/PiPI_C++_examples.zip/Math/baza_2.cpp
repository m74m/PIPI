#include <stdio.h>
#include <conio.h>
#include <stdlib.h>


unsigned long int dbroj;
int b1;
int b2;
char temp;
char broj[50];
int i;
int count;

int powint(int broj,int na)
{
    int tmp = broj;
    for(int j=1;j<na;j++)
    {
        tmp = tmp * broj;
    }
    if(na==0)
    {
        tmp=1;
    }
    return tmp;
}

void unesi_bazu_prvog_broja()
{
    putch(85);
    putch(110);
    putch(101);
    putch(115);
    putch(105);
    putch(32);
    putch(98);
    putch(97);
    putch(122);
    putch(117);
    putch(32);
    putch(112);
    putch(114);
    putch(118);
    putch(111);
    putch(103);
    putch(32);
    putch(98);
    putch(114);
    putch(111);
    putch(106);
    putch(97);
    putch(58);
    putch(32);
}

void unesi_broj()
{
    putch(85);
    putch(110);
    putch(101);
    putch(115);
    putch(105);
    putch(32);
    putch(98);
    putch(114);
    putch(111);
    putch(106);
    putch(58);
    putch(32);
}

void unesi_bazu_drugog_broja()
{
    putch(85);
    putch(110);
    putch(101);
    putch(115);
    putch(105);
    putch(32);
    putch(98);
    putch(97);
    putch(122);
    putch(117);
    putch(32);
    putch(100);
    putch(114);
    putch(117);
    putch(103);
    putch(111);
    putch(103);
    putch(32);
    putch(98);
    putch(114);
    putch(111);
    putch(106);
    putch(97);
    putch(58);
    putch(32);
}

void dobiveni_broj_je()
{
    putch(68);
    putch(111);
    putch(98);
    putch(105);
    putch(118);
    putch(101);
    putch(110);
    putch(105);
    putch(32);
    putch(98);
    putch(114);
    putch(111);
    putch(106);
    putch(32);
    putch(106);
    putch(101);
    putch(32);
}

void converter_b1()
{
    short tmp=i-1;
    for(short f=0;f<i;f++)
    {
        b1 = b1 + (broj[f]-48)*powint(10,tmp);
        tmp--;
    }
}

void converter_b2()
{
    short tmp=i-1;
    for(short f=0;f<i;f++)
    {
        b2 = b2 + (broj[f]-48)*powint(10,tmp);
        tmp--;
    }
}

void converter()
{
    int tmp=i-1;
    for(short f=0;f<i;f++)
    {
        if((broj[f]>=48)&&(broj[f]<=57))
        {
            dbroj = dbroj + (broj[f]-48)*powint(b1,tmp);
        }
        else
        {
            dbroj = dbroj + (broj[f]-54)*powint(b1,tmp);
        }
        tmp--;
    }
}

void reader_b1()
{
    unesi_bazu_prvog_broja();
    for(i=0;i<1;i++)
    {
        temp = getch();
        system("cls");
        if((temp>=49)&&(temp<=57))
        {
            broj[i]=temp;
        }
        else if(temp==27)
        {
            exit(1);
        }
        else
        {
            i--;
        }
        unesi_bazu_prvog_broja();
        for(short k=0;k<=i;k++)
        {
            putch(broj[k]);
        }
    }
    for(i=1;i<2;i++)
    {
        if((broj[0]>51)&&(broj[0]<57))
        {
            break;
        }
        temp = getch();
        system("cls");
        if(broj[0]==51)
        {
            if((temp>=48)&&(temp<=54))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else if(temp==13)
            {
                break;
            }
            else
            {
                i--;
            }
            unesi_bazu_prvog_broja();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
        else if(broj[0]==49)
        {
            if((temp>=48)&&(temp<=57))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else
            {
                i--;
            }
            unesi_bazu_prvog_broja();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
        else
        {
            if((temp>=48)&&(temp<=57))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else if(temp==13)
            {
                break;
            }
            else
            {
                i--;
            }
            unesi_bazu_prvog_broja();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
    }
    converter_b1();
}

void reader_b2()
{
    unesi_bazu_drugog_broja();
    for(i=0;i<1;i++)
    {
        temp = getch();
        system("cls");
        if((temp>=49)&&(temp<=57))
        {
            broj[i]=temp;
        }
        else if(temp==27)
        {
            exit(1);
        }
        else
        {
            i--;
        }
        unesi_bazu_drugog_broja();
        for(short k=0;k<=i;k++)
        {
            putch(broj[k]);
        }
    }
    for(i=1;i<2;i++)
    {
        if((broj[0]>51)&&(broj[0]<57))
        {
            break;
        }
        temp = getch();
        system("cls");
        if(broj[0]==51)
        {
            if((temp>=48)&&(temp<=54))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else if(temp==13)
            {
                break;
            }
            else
            {
                i--;
            }
            unesi_bazu_drugog_broja();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
        else if(broj[0]==49)
        {
            if((temp>=48)&&(temp<=57))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else
            {
                i--;
            }
            unesi_bazu_drugog_broja();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
        else
        {
            if((temp>=48)&&(temp<=57))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else if(temp==13)
            {
                break;
            }
            else
            {
                i--;
            }
            unesi_bazu_drugog_broja();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
    }
    converter_b2();
}

void reader()
{
    system("cls");
    unesi_broj();
    for(i=0;i<1;i++)
    {
        temp=getch();
        system("cls");
        if(b1<=10)
        {
            if((temp>=49)&&(temp<=(47+b1)))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else
            {
                i--;
            }
            unesi_broj();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
        else
        {
            if(((temp>=49)&&(temp<=57))||((temp>=65)&&(temp<=(54+b1))))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else
            {
                i--;
            }
            unesi_broj();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
    }
    for(i=1;i<50;i++)
    {
        temp=getch();
        system("cls");
        if(b1<=10)
        {
            if((temp>=48)&&(temp<=(47+b1)))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else if(temp==13)
            {
                break;
            }
            else
            {
                i--;
            }
            unesi_broj();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
        else
        {
            if(((temp>=48)&&(temp<=57))||((temp>=65)&&(temp<=(54+b1))))
            {
                broj[i]=temp;
            }
            else if(temp==27)
            {
                exit(1);
            }
            else if(temp==13)
            {
                break;
            }
            else
            {
                i--;
            }
            unesi_broj();
            for(short k=0;k<=i;k++)
            {
                putch(broj[k]);
            }
        }
    }
    converter();
}

void calc()
{
    int tmp = dbroj;
    int tmp2;
    do
    {
        tmp2 = tmp;
        tmp = tmp/b2;
        broj[count]=tmp2-(tmp*b2);
        count++;
    }while(tmp>0);
}

void ispis()
{
    system("cls");
    dobiveni_broj_je();
    for(int f=count-1;f>=0;f--)
    {
        switch(broj[f])
        {
            case 0:
            {
                putch(48);
                break;
            }
            case 1:
            {
                putch(49);
                break;
            }
            case 2:
            {
                putch(50);
                break;
            }
            case 3:
            {
                putch(51);
                break;
            }
            case 4:
            {
                putch(52);
                break;
            }
            case 5:
            {
                putch(53);
                break;
            }
            case 6:
            {
                putch(54);
                break;
            }
            case 7:
            {
                putch(55);
                break;
            }
            case 8:
            {
                putch(56);
                break;
            }
            case 9:
            {
                putch(57);
                break;
            }
            case 10:
            {
                putch(65);
                break;
            }
            case 11:
            {
                putch(66);
                break;
            }
            case 12:
            {
                putch(67);
                break;
            }
            case 13:
            {
                putch(68);
                break;
            }
            case 14:
            {
                putch(69);
                break;
            }
            case 15:
            {
                putch(70);
                break;
            }
            case 16:
            {
                putch(71);
                break;
            }
            case 17:
            {
                putch(72);
                break;
            }
            case 18:
            {
                putch(73);
                break;
            }
            case 19:
            {
                putch(74);
                break;
            }
            case 20:
            {
                putch(75);
                break;
            }
            case 21:
            {
                putch(76);
                break;
            }
            case 22:
            {
                putch(77);
                break;
            }
            case 23:
            {
                putch(78);
                break;
            }
            case 24:
            {
                putch(79);
                break;
            }
            case 25:
            {
                putch(80);
                break;
            }
            case 26:
            {
                putch(81);
                break;
            }
            case 27:
            {
                putch(82);
                break;
            }
            case 28:
            {
                putch(83);
                break;
            }
            case 29:
            {
                putch(84);
                break;
            }
            case 30:
            {
                putch(85);
                break;
            }
            case 31:
            {
                putch(86);
                break;
            }
            case 32:
            {
                putch(87);
                break;
            }
            case 33:
            {
                putch(88);
                break;
            }
            case 34:
            {
                putch(89);
                break;
            }
            case 35:
            {
                putch(90);
                break;
            }
        }
    }
}

int main()
{
    reader_b1();
    reader();
    reader_b2();
    calc();
    ispis();
    getch();
}
