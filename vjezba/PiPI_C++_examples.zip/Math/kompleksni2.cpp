#include <math.h>
#include <iostream>
using namespace std;

double broj (float x, float y);
double kut (float x, float y);  

int main() {
    
    float a1, a2;
            
    cout << "Upisi realni dio: "; cin >> a1;
    cout << "Upisi imaginarni dio: "; cin >> a2;            
            
// if (a1<0 && a2==0) {jot_1=a1; jot_2=0;} // ako je realni dio manji od 0, tada je rezultat taj realni broj pod kutem 0
// else if (a1==0 && a2>0) {jot_1=a2; jot_2=90;} // ako je realni dio jednak 0, a imagirani ve�i od 0 tada je rezultat imaginarni broj pod kutem 90
// else if (a1==0 && a2<0) {jot_1=a2*-1; jot_2=-90;} // ako je realni dio jednak 0, a imaginarni manji od 0 tada je rezultat imaginarni broj pod kutem -90
// else

   cout << endl << "Rezultat u polarnom obliku: " << broj (a1,a2) << " |_" << kut (a1,a2) << "�" << endl;
   getchar();
   getchar();
   return 0;
}

double broj (float x, float y) {
       float rezultat;
       rezultat=sqrt(x*x+y*y);
       return rezultat;       
}

double kut (float x, float y) {
       float rezultat;
       rezultat=atan(y/x)*180/M_PI;
       return rezultat;       
}
	
