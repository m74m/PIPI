//Ovaj program izracunava oplosje i obujam valjka.
# include <stdio.h>
# include <conio.h>
float r, h, Op, V;
main () {
    //Unos podataka
    printf("Ovaj program izracunava oplosje i obujam valjka.\n");
    printf("Polumjer r="); scanf("%f", &r);
    printf("Visina h="); scanf("%f", &h);
    
    //racunanje
    Op=2*r*3.141*(r+h);
    V=r*r*h*3.141;
    
    //Ispis rezultata
    printf("Oplosje valjka iznosi: %.4f.\n", Op);
    printf("Volumen valjka iznosi: %.4f.\n", V);
    getch();
}    
