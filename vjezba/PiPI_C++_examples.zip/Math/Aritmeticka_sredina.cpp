
#include <stdio.h>
#include <conio.h>

int main()
{
    int n, suma = 0, i;
    double rezultat;

    printf("Unesite broj n: ");
    scanf("%d",&n);

    if(n < 1)
    {
        printf("Unjeli ste krivi broj n!");
        return 1;
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            int broj;
            printf("B[%d]=",i);
            scanf("%d", &broj);
            suma += broj;
        }

        rezultat = (double)suma / n;
    }
    printf("Aritmeticka sredina unesenih brojeva iznosi: %lf\n", rezultat);
    
    getch();
    return 0;
}
