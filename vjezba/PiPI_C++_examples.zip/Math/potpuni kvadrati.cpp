#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define MAX 50000

int main () {
 system("color 1f");
 system("title Potpuni kvadrati");
 int c,/*Varijabla koju koristi for petlja*/ i=0,/*varijabla koju koristi while petlja*/ cnt[10]={0}/*Indikator ako broj sadr�i znamenku*/ ;
 int r;/*Niz koji se kvadrira*/
 char s[20]; /*Kvadrat broja kao string*/
 FILE *f;
 f = fopen("potpuni kvadrati.txt", "w");
 if(f==NULL)
               {
               system("color 4f");
               printf("\aNemogu na�i datoteku:'potpuni kvadrati.txt'\n");
               getch();
               exit(1);
               }
        
 for (c=0; c<=MAX; c++) {
     cnt[0]=0;  cnt[1]=0;  cnt[2]=0;  cnt[3]=0;  cnt[4]=0;  cnt[5]=0;  cnt[6]=0;  cnt[7]=0;  cnt[8]=0;  cnt[9]=0;
     r=c*c;
     if(r<0) {
             getch();
             exit(1);
             }
     sprintf(s, "%d", r); //s[]=r;
     
     while (s[i]!='\0') {
           if(s[i]=='0') cnt[0]++; 
           if(s[i]=='1') cnt[1]++; 
           if(s[i]=='2') cnt[2]++; 
           if(s[i]=='3') cnt[3]++; 
           if(s[i]=='4') cnt[4]++; 
           if(s[i]=='5') cnt[5]++; 
           if(s[i]=='6') cnt[6]++; 
           if(s[i]=='7') cnt[7]++; 
           if(s[i]=='8') cnt[8]++; 
           if(s[i]=='9') cnt[9]++; 
           i++;
           }
     if ((cnt[0]==1)&&(cnt[1]==1)&&(cnt[2]==1)&&(cnt[3]==1)&&(cnt[4]==1)&&(cnt[5]==1)&&(cnt[6]==1)&&(cnt[7]==1)&&(cnt[8]==1)&&(cnt[9]==1)) { printf("[%d]^2=%d\n",c,r);  fprintf(f, "[%d]^2=%d\n",c,r);  }
     
     i=0;
     }
 fclose(f);
 getch();
 return 0;
}
