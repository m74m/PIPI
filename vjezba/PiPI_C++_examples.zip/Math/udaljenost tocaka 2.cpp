#include <stdio.h>
#include <conio.h>
#include <math.h>
float x_1,y_1,x_2,y_2,d1,d2,d3,x_3,y_3;

main () {
      printf("Ovaj program usporedjuje udaljenost \ntocaka u koordinatnom sustavu u ravnini. \n");
      printf("\nA(x1, y1) \nB(x2, y2) \nC(x3, y3)\n\n");
      printf("x1="); scanf("%f",&x_1);
      printf("y1="); scanf("%f",&y_1);
      printf("x2="); scanf("%f",&x_2);
      printf("y2="); scanf("%f",&y_2);
      printf("y3="); scanf("%f",&y_2);
      printf("x3="); scanf("%f",&y_2);
      if (((x_1==x_2) && (y_1==y_2)) || ((x_1==x_3) && (y_1==y_3))|| ((x_2==x_3) && (y_2==y_3))) {
          printf("Unesena je kriva tocka \n");
      }
      d1=sqrt((x_2-x_1)*(x_2-x_1)+(y_2-y_1)*(y_2-y_1));
      d2=sqrt((x_3-x_2)*(x_3-x_2)+(y_3-y_2)*(y_3-y_2));
      d3=sqrt((x_3-x_1)*(x_3-x_1)+(y_3-y_1)*(y_3-y_1));
      if ((d1>d2) && (d1>d3)) {
         printf("najveca udaljenost izmedu tocaka 1 i 2");
      }
      if ((d2>d1) && (d2>d3)) {
         printf("najveca udaljenost izmedu tocaka 2 i 3");
      }
      if ((d3>d2) && (d3>d1)) {
      printf("najveca udaljenost izmedu 3 i 2");
      }        

      getch (); 
}
