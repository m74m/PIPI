#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#define MAXRED 100


int point(int n) { //ispisuje onoliko to�kica koliki je broj na kocki;
    int c;
    for(c=0; c<n; c++) printf("*");
    printf("\n");
}

main () {

    int n/*Broj bacanja kocke*/, c/*Broja� 'for' petlje*/, i/*vrijednost*/;

    do {
        printf("Broj bacanja kocke: "); scanf("%d",&n);
    }while (n<=0 || n>MAXRED);

    float a=0/*Aritmeti�ka sredina*/, D[n], d=0/*Standardna devijacija*/;

    srand((unsigned)time(NULL));
    for(c=0; c<n; c++) {
        i=rand() % 6 + 1;
        printf("kocka[%d]=%d   ",c,i); point(i);
        a+=i;
        D[c]=i;

    }

    a/=n;
    printf("Aritmeticka sredina kocke iznosi: %f\n",a);

    for(c=0; c<n; c++) d+=pow((D[c]-a),2);
    d=sqrt(d/n);

    printf("Standardna devijacija kocke iznosi: %f\n",d);

    getch();
    return 0;
}
