//Ovaj program izracunava oplosje i volumen stozca.
# include <stdio.h>
# include <conio.h>
#include <math.h>
float r, h, s, Op, V;
main () {
    //Unos podataka
    printf("Ovaj program izracunava oplosje i volumen stozca. \n");
    printf("Polumjer r="); scanf("%f", &r);
    printf("Visina h="); scanf("%f", &h);
    
    //Ra�unanje
    s=sqrt(pow(r,2)+pow(h,2));
    Op=r*M_PI*(r+s);
    V=(pow(r,2)*M_PI*h)/3;
    
    //Ispis rezultata
    printf("Oplosje stozca iznosi: %.4f.\n", Op);
    printf("Volumen stozca iznosi: %.4f.\n", V);
    getch();
}    
