#include <iostream>
#include <math.h>
using namespace std;

int sgn(int n) {
     int s;
     if (n!=0) s=n/abs(n);
     else s=0;
     return s;
}

main () {
     int a, p;
     cout << "a=";
     cin >> a;
     p=sgn(a);
     cout <<"\nPredznak broja a="<<a<<" iznosi: ";
     cout << p <<endl;
     cout << "\n";
     getchar();
     getchar();
     return 0;
}
