#include<stdio.h>
#include<conio.h>

main () {
     printf("Unesi broj rezultata mjerenja Xi: ");
     int n;
     scanf("%d",&n);
     float Xi[n];
     int i=0;
     while(i<n) {
                 printf("Xi[%d]=",i+1); scanf("%f",&Xi[i]);
                 i++;
     }
     int c;
     float Xs=0;
     for(c=0; c<n; c++) Xs+=Xi[c];
     float S;
     S=Xs/n;
     printf("Aritmeticka sredina mjerenja iznosi: %f\n",S);
     getch();
     return 0;
}
