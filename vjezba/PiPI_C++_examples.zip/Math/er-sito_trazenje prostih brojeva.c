#include <stdio.h>
#include <string.h>

int main()
{
	int polje[1001];
	int n,x;
	
	memset(polje,1,sizeof(int)*1001);

	for(x=2;x<1000;x++)
		for(n=x+1;n<1000;n++)
			if(!(n % x))
				polje[n]=0;
	
	for(n=2;n<1000;n++)
		if(polje[n])
			printf("%d je prost broj\n",n);
	getch();
	return 0;
}
