#include<stdio.h>
#include<conio.h>
#include<math.h>

main () {
     printf("Unesi broj rezultata mjerenja Xi: ");
     int n;
     scanf("%d",&n);
     float Xi[n], Yi[n];
     int i=0;
     while(i<n) {
                 printf("Xi[%d]=",i+1); scanf("%f",&Xi[i]);
                 printf("Yi[%d]=",i+1); scanf("%f",&Yi[i]);
                 i++;
     }
     int c;
     float Xs=0, Ys=0;
     for(c=0; c<n; c++) {Xs+=Xi[c]; Ys+=Yi[c];}
     float Sx, Sy;
     Sx=Xs/n; Sy=Ys/n;
     
     printf("Aritmeticka sredina mjerenja varijable 'X' iznosi: %f\n",Sx);
     printf("Aritmeticka sredina mjerenja varijable 'Y' iznosi: %f\n",Sy);
     printf("Suma svih 'Xi' iznosi: %f\n", Xs);
     printf("Suma svih 'Yi' iznosi: %f\n", Ys);
     
     float Sumx2, Sumy2, Sumxx=0, Sumyy=0, Sumxy=0;
     
     Sumx2=pow(Xs,2); printf("Kvadrat sume svih 'Xi' iznosi: %f\n", Sumx2);
     Sumy2=pow(Ys,2); printf("Kvadrat sume svih 'Yi' iznosi: %f\n", Sumy2);
     
     for(c=0; c<n; c++) {Sumxx+=pow(Xi[c],2); Sumyy+=pow(Yi[c],2); Sumxy+=Xi[c]*Yi[c];}
     
     printf("Suma svih 'Xi^2' iznosi: %f\n", Sumxx);
     printf("Suma svih 'Yi^2' iznosi: %f\n", Sumyy);
     printf("Suma svih 'Xi*Yi' iznosi: %f\n", Sumxy);
     
     float a,b,Ma,Mb;
     a=(n*Sumxy-Xs*Ys)/(n*Sumxx-Sumx2);
     b=(Sumxx*Ys-Xs*Sumxy)/(n*Sumxx-Sumx2);
     
     Ma=sqrt((1/(n-2))*((n*Sumyy-Sumy2)/(n*Sumxx-Sumx2)-pow(a,2)));
     Mb=Ma*sqrt(Sumxx/n);
     
     printf("Koeficijent smjera iznosi: %f\n", a);
     printf("Odsjecak iznosi: %f\n", b);
     printf("Pogreska koeficijenta smjera iznosi: %f\n", Ma);
     printf("Pogreska odsjecka iznosi: %f\n", Mb);
     
     
     getch();
     return 0;
}
