#include <stdio.h>
#include <conio.h>

void ispis_crte() { printf("    +------------+--------+\n"); }

main () {
     
     int c=2, n;
     printf("n="); scanf("%d",&n);
     printf("\n");
     ispis_crte();
     while(c<=n) {
              if(n%c==0) { printf("    |%12d|%8d|\n",n,c); n/=c; ispis_crte(); }
              else c++; 
     }
     printf("    |%12d|      //|\n",1);
     ispis_crte();
     getch ();
     return 0;
}
