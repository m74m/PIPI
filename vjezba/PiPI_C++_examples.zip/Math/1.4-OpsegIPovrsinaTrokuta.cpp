//program ucitava sve tri stranice trokuta i racuna opseg i povrsinu

#include <stdio.h>
#include <math.h>
#include <conio.h>

float a,b,c,s,O,P;

main() {   
    //unos varijabli
    printf("Unesi stranice trokuta:\n");
    printf("a= "); scanf("%f",&a);
    printf("b= "); scanf("%f",&b);
    printf("c= "); scanf("%f",&c);
    
    //racunanje
    s=(a+b+c)/2;
    O=2*s;
    P=sqrt(s*(s-a)*(s-b)*(s-c));
    
    //ispis rezultata
    printf("Opseg trokuta iznosi %.3f.\n",O);
    printf("Povrsina trokuta iznosi %.3f.\n", P);
    getch();
}    
