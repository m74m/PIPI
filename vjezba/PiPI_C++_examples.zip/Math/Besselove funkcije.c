#include <stdio.h>
#include <math.h>
int main () {
     int N;
     double a, b;
     printf("N="); scanf("%d", &N);
     printf("a="); scanf("%lf", &a);
     printf("b="); scanf("%lf", &b);
     int c;
     double x, y;
     for(c=0; c<N; c++) {
              x=a+((b-a)/N)*c;
              y=jn(2,x)*exp(-0.2*x);
              printf("x=%10lf, y=%10lf\n",x,y);
     }
     getch();
}
