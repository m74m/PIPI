// P01_DynamicArray_C_implementacija.cpp : Defines the entry point for the console application.
//
//#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "DinamickoPolje1-s.h"
#include "DinamickoPolje1-f.h"

int main(int argc, char* argv[])
{
	FILE		*fp;
	int			i, Podatak;
	int			BrojUcitanih = 0;
	
	struct DinamickoPolje		Polje;
	
	Inicijaliziraj(&Polje, 10);

	if( (fp = fopen("Podaci.txt", "r")) == NULL ) {
		printf("\nNeuspje�no otvaranje datoteke!");
		return 1;
	}

	while( fscanf(fp, "%d", &Podatak) != -1 ){
		if( Polje.BrojElem <= BrojUcitanih )
		{
			PostaviNovuVelicinu(&Polje, BrojUcitanih+1);
			// ukoliko �elimo izbje�i �este promjene veli�ine, mo�emo pove�avati za vi�e
			//	PostaviNovuVelicinu(&Polje, BrojUcitanih * 2);
		}

		Polje.Podaci[BrojUcitanih] = Podatak;
		BrojUcitanih++;
	}

	for( i=0; i<Polje.BrojElem; i++ )
		printf("%d\n", Polje.Podaci[i]);
	
	getch();
	return 0;
}

