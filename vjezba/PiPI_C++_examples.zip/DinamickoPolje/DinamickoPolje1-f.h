
int	Inicijaliziraj(struct DinamickoPolje *Polje, int BrojElem)
{
	Polje->Podaci = (int *) malloc(BrojElem * sizeof(int));
	Polje->BrojElem = BrojElem;

	if( Polje->Podaci == NULL )
		return 1;
	else
		return 0;
}
void Izbrisi(struct DinamickoPolje *Polje)
{
	free(Polje->Podaci);
}
int PostaviNovuVelicinu(struct DinamickoPolje *Polje, int NoviBrojElem)
{
	Polje->Podaci = (int *) realloc(Polje->Podaci, NoviBrojElem * sizeof(int));
	Polje->BrojElem = NoviBrojElem;

	if( Polje->Podaci == NULL )
		return 1;
	else
		return 0;
}
