

struct DinamickoPolje
{
	int		*Podaci;
	int		BrojElem;
};

int	 Inicijaliziraj(struct DinamickoPolje *Polje, int BrojElem);
void Izbrisi(struct DinamickoPolje *Polje);
int	 PostaviNovuVelicinu(struct DinamickoPolje *Polje, int NoviBrojElem);
