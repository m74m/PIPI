
int	Inicijaliziraj(struct DinamickoPolje *Polje, int MaxBrojElem)
{
	Polje->Podaci = (int *) malloc(MaxBrojElem * sizeof(int));
	Polje->BrojElem = 0;
	Polje->MaxBrojElemenata = MaxBrojElem;

	if( Polje->Podaci == NULL )
		return 1;
	else
		return 0;
}
void Izbrisi(struct DinamickoPolje *Polje)
{
	free(Polje->Podaci);
}

int PostaviNovuVelicinu(struct DinamickoPolje *Polje, int NoviBrojElem)

{
	Polje->Podaci = (int *) realloc(Polje->Podaci, NoviBrojElem * sizeof(int));
/*
Napomena:
 Drugi argument predstavlja tra�enu novu veli�inu bloka u bajtovima
 Sadr�aj bloka je nepromijenjen, gledano do manje od dvije veli�ine --
 nove i stare veli�ine bloka - iako novi blok mo�e biti na drugoj lokaciji
 Uo�ite da se nigdje ne spominje eksplicitno da �e se stari sadr�aj
 KOPIRATI, ve� samo pi�e da �e sadr�aj nakon realokacije biti isti
*/
	
	if( Polje->BrojElem > NoviBrojElem)			// zna�i da SMANJUJEMO polje
		Polje->BrojElem = NoviBrojElem;

	Polje->MaxBrojElemenata = NoviBrojElem;

	if( Polje->Podaci == NULL )
		return 1;
	else
		return 0;
}

void	PostaviElement(struct DinamickoPolje *Polje, int Indeks, int Vrijednost)
{
	if( 0 <= Indeks && Indeks < Polje->MaxBrojElemenata )
	{
		Polje->Podaci[Indeks] = Vrijednost;
		if( Indeks >= Polje->BrojElem )			
		{
			/* zna�i da smo stavili novi element 
			   izvan dosada�nje "granice" polja
			   ali unutar raspolo�ivog (alociranog) prosotra */
			Polje->BrojElem = Indeks + 1;

			/* dodatni problem : 
			   vrijednosti elemenata polja 
			   izme�u prija�nje granice 
			   i novododanog elementa su NEDEFINIRANE!
		    */
		}
	}
	else
	{

		// A �TO SAD !!!!!????? - Problem 1
	}
}
int		DohvatiElement(struct DinamickoPolje *Polje, int Indeks)
{
	if( 0 <= Indeks && Indeks < Polje->MaxBrojElemenata )
		return Polje->Podaci[Indeks];
	else
	{
		// A �TO SAD !!!!!?????
		return 0;				// ne�to MORAMO vratiti (zbog prototipa funkcije !)
	}
}
int		DodajElementNaKraj(struct DinamickoPolje *Polje, int Vrijednost)
{
	int		ret = 0;
	// treba provjeriti ima li mjesta za novi element
	if( Polje->BrojElem == Polje->MaxBrojElemenata )
	{
		// zna�i da moramo alocirati dodatni prostor
		ret = PostaviNovuVelicinu(Polje, Polje->BrojElem + 1);
		
		if( ret != 0 )			// ako nismo uspjeli povecati polje
			return ret;
	}

	Polje->Podaci[Polje->BrojElem++] = Vrijednost;

	// ili alternativno:
	//	PostaviElement(Polje, Polje->BrojElem, Vrijednost);

	return 0;
}

int		BrojElemenata(struct DinamickoPolje *Polje)
{
	return Polje->BrojElem;
}

