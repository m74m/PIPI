// P01_DynamicArray_C_implementacija.cpp : Defines the entry point for the console application.
//
#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "DinamickoPolje3-s.h"
#include "DinamickoPolje3-f.h"



int main(int argc, char* argv[])
{
	FILE		*fp;
	int			i, Podatak;
	int			BrojUcitanih = 0;
	
	DinamickoPolje		Polje;
	
	Inicijaliziraj(&Polje, 5);

	// testiramo Dohvati i Postavi
	for(i=0; i<10; i++ )
		PostaviElement(&Polje, i, i);
	for( i=0; i<BrojElemenata(&Polje); i++ )
		printf("%d\n", DohvatiElement(&Polje, i));

	Izbrisi(&Polje);

	// testiramo dodavanje novog elemnta na kraj
	Inicijaliziraj(&Polje, 10);
	
	if( (fp = fopen("Podaci.txt", "r")) == NULL ) {
		printf("\nNeuspje�no otvaranje datoteke !!!");
		return 1;
	}

	while( fscanf(fp, "%d", &Podatak) != -1 )
	{
		DodajElementNaKraj(&Polje, Podatak);
	}

	for( i=0; i<BrojElemenata(&Polje); i++ )
		printf("%d\n", DohvatiElement(&Polje, i));
	
	getch();
	return 0;
}

