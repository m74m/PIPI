
int	Inicijaliziraj(struct DinamickoPolje *Polje, int MaxBrojElem)
{
	Polje->Podaci = (int *) malloc(MaxBrojElem * sizeof(int));
	Polje->BrojElem = 0;
	Polje->MaxBrojElemenata = MaxBrojElem;

	if( Polje->Podaci == NULL )
		return 1;
	else
		return 0;
}
void Izbrisi(struct DinamickoPolje *Polje)
{
	free(Polje->Podaci);
}
int PostaviNovuVelicinu(struct DinamickoPolje *Polje, int NoviBrojElem)
{
	Polje->Podaci = (int *) realloc(Polje->Podaci, NoviBrojElem * sizeof(int));
	
	if( Polje->BrojElem > NoviBrojElem)			// zna�i da SMANJUJEMO polje
		Polje->BrojElem = NoviBrojElem;

	Polje->MaxBrojElemenata = NoviBrojElem;

	if( Polje->Podaci == NULL )
		return 1;
	else
		return 0;
}

void	PostaviElement(struct DinamickoPolje *Polje, int Indeks, TipDinamickogPolja Vrijednost)
{
	if( 0 <= Indeks && Indeks < Polje->MaxBrojElemenata )
	{
		Polje->Podaci[Indeks] = Vrijednost;
		if( Indeks >= Polje->BrojElem )			
		{
			// zna�i da smo stavili novi element izvan dosada�nje "granice" polja
			// ali unutar raspolo�ivog (alociranog) prosotra
			Polje->BrojElem = Indeks + 1;

			// dodatni problem : vrijednosti elemenata polja izme�u prija�nje granice i novododanog elementa su nedefinirane !
		}
	}
	else
	{
		// A �TO SAD !!!!!?????
	}
}
TipDinamickogPolja		DohvatiElement(struct DinamickoPolje *Polje, int Indeks)
{
	if( 0 <= Indeks && Indeks < Polje->MaxBrojElemenata )
		return Polje->Podaci[Indeks];
	else
	{
		// A �TO SAD !!!!!?????
		return 0;				// ne�to MORAMO vratiti (zbog prototipa funkcije !)
	}
}
int		DodajElementNaKraj(struct DinamickoPolje *Polje, TipDinamickogPolja Vrijednost)
{
	int		ret = 0;
	// treba provjeriti da li ima mjesta za novi element
	if( Polje->BrojElem == Polje->MaxBrojElemenata )
	{
		// zna�i da moramo alocirati dodatni prostor
		ret = PostaviNovuVelicinu(Polje, Polje->BrojElem + 1);
		
		if( ret != 0 )			// ako nismo uspjeli povecati polje
			return ret;
	}

	Polje->Podaci[Polje->BrojElem++] = Vrijednost;

	// ili alternativno:
	//	PostaviElement(Polje, Polje->BrojElem, Vrijednost);

	return 0;
}

int		BrojElemenata(struct DinamickoPolje *Polje)
{
	return Polje->BrojElem;
}

