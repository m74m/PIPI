

struct DinamickoPolje
{
	int		*Podaci;
	
	int		BrojElem;						// koliko stvarno ima elemenata u polju
	int		MaxBrojElemenata;		// koliki je maksimalni raspolozivi prostor
};

int		Inicijaliziraj(struct DinamickoPolje *Polje, int MaxBrojElem);
void	Izbrisi(struct DinamickoPolje *Polje);
int		PostaviNovuVelicinu(struct DinamickoPolje *Polje, int NoviBrojElem);

void	PostaviElement(struct DinamickoPolje *Polje, int Indeks, int Vrijednost);
int		DohvatiElement(struct DinamickoPolje *Polje, int Indeks);
int		DodajElementNaKraj(struct DinamickoPolje *Polje, int Vrijednost);

int		BrojElemenata(struct DinamickoPolje *Polje);

