#include <iostream>

//the following line is necessary for the
//  GetConsoleWindow() function to work!
//it basically says that you are running this
//  program on Windows 2000 or higher
#define _WIN32_WINNT 0x0500

//it is important that the above line be typed
//  BEFORE <windows.h> is included
#include <windows.h>

using namespace std;

int main (void)
{
  HWND console = GetConsoleWindow();
  RECT r;
  GetWindowRect(console, &r); //stores the console's current dimensions

  //MoveWindow(window_handle, x, y, width, height, redraw_window);
  MoveWindow(console, r.left, r.top, 800, 600, TRUE);
  for (int j = 0; j < 100; ++j)
    {
      for (int i = 0x41; i < 0x5B; ++i)
        cout << (char)i;
    }
  cout << endl;
  Sleep(1000);
  MoveWindow(console, r.left, r.top, r.right - r.left, r.bottom - r.top, TRUE);
}