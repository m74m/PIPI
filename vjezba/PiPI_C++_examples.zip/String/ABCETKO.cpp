#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

short i;
int *p;
FILE *f;
char rijec[50];
struct slova
{
       char a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,space;
} slovo[8][8];

void priprema()
{
     f = fopen("slova.dll","r");
     if(f==NULL)
     {
         printf("Nema datoteke");
         getch();
         exit(1);
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].a);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].b);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].c);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].d);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].e);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].f);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].g);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].h);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].i);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].j);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].k);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].l);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].m);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].n);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].o);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].p);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].q);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].r);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].s);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].t);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].u);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].v);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].w);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].x);
         }
     }
     for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].y);
         }
     }
          for(i=0;i<=7;i++)
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].z);
         }
     }
     {
         for(short j=0;j<=7;j++)
         {
             fscanf(f,"%c",&slovo[i][j].space);
         }
     }

}

void ac()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].a);
     }

}
void bc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].b);
     }

}
void cc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].c);
     }

}
void dc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].d);
     }

}
void ec()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].e);
     }

}
void fc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].f);
     }

}
void gc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].g);
     }

}
void hc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].h);
     }

}
void ic()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].i);
     }

}
void jc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].j);
     }

}
void kc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].k);
     }

}
void lc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].l);
     }

}
void mc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].m);
     }

}
void nc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].n);
     }

}
void oc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].o);
     }

}
void pc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].p);
     }

}
void qc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].q);
     }

}
void rc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].r);
     }

}
void sc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].s);
     }

}
void tc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].t);
     }

}
void uc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].u);
     }

}
void vc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].v);
     }

}
void wc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].w);
     }

}
void xc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].x);
     }

}
void yc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].y);
     }

}
void zc()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].z);
     }

}
void af()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].a);
     }

}
void bf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].b);
     }

}
void cf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].c);
     }

}
void df()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].d);
     }

}
void ef()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].e);
     }

}
void ff()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].f);
     }

}
void gf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].g);
     }

}
void hf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].h);
     }

}
void iff()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].i);
     }

}
void jf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].j);
     }

}
void kf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].k);
     }

}
void lf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].l);
     }

}
void mf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].m);
     }

}
void nf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].n);
     }

}
void of()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].o);
     }

}
void pf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].p);
     }

}
void qf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].q);
     }

}
void rf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].r);
     }

}
void sf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].s);
     }

}
void tf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].t);
     }

}
void uf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].u);
     }

}
void vf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].v);
     }

}
void wf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].w);
     }

}
void xf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].x);
     }

}
void yf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].y);
     }

}
void zf()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].z);
     }

}
void spacec()
{
     for(short j=0;j<=7;j++)
     {
        printf("%c",slovo[i][j].space);
     }

}
void spacef()
{
     for(short j=0;j<=7;j++)
     {
        fprintf(f,"%c",slovo[i][j].space);
     }

}

void ispisc()
{
     for(i=0;i<=7;i++)
     {
         for(short u=0;u<=49;u++)
         {
             if(rijec[u]=='a')
             {
                 ac();
             }
             else if(rijec[u]=='b')
             {
                 bc();
             }
             else if(rijec[u]=='c')
             {
                 cc();
             }
             else if(rijec[u]=='d')
             {
                 dc();
             }
             else if(rijec[u]=='e')
             {
                 ec();
             }
             else if(rijec[u]=='f')
             {
                 fc();
             }
             else if(rijec[u]=='g')
             {
                 gc();
             }
             else if(rijec[u]=='h')
             {
                 hc();
             }
             else if(rijec[u]=='i')
             {
                 ic();
             }
             else if(rijec[u]=='j')
             {
                 jc();
             }
             else if(rijec[u]=='k')
             {
                 kc();
             }
             else if(rijec[u]=='l')
             {
                 lc();
             }
             else if(rijec[u]=='m')
             {
                 mc();
             }
             else if(rijec[u]=='n')
             {
                 nc();
             }
             else if(rijec[u]=='o')
             {
                 oc();
             }
             else if(rijec[u]=='p')
             {
                 pc();
             }
             else if(rijec[u]=='q')
             {
                 qc();
             }
             else if(rijec[u]=='r')
             {
                 rc();
             }
             else if(rijec[u]=='s')
             {
                 sc();
             }
             else if(rijec[u]=='t')
             {
                 tc();
             }
             else if(rijec[u]=='u')
             {
                 uc();
             }
             else if(rijec[u]=='v')
             {
                 vc();
             }
             else if(rijec[u]=='w')
             {
                 wc();
             }
             else if(rijec[u]=='x')
             {
                 xc();
             }
             else if(rijec[u]=='y')
             {
                 yc();
             }
             else if(rijec[u]=='z')
             {
                 zc();
             }
             else if(rijec[u]=='_')
             {
                 spacec();
             }
             
         }
         printf("\n");
     }
}
void ispisf()
{
     f = fopen("ispis_slova.txt","w");
     for(i=0;i<=7;i++)
     {
         for(short u=0;u<=49;u++)
         {
             if(rijec[u]=='a')
             {
                 af();
             }
             else if(rijec[u]=='b')
             {
                 bf();
             }
             else if(rijec[u]=='c')
             {
                 cf();
             }
             else if(rijec[u]=='d')
             {
                 df();
             }
             else if(rijec[u]=='e')
             {
                 ef();
             }
             else if(rijec[u]=='f')
             {
                 ff();
             }
             else if(rijec[u]=='g')
             {
                 gf();
             }
             else if(rijec[u]=='h')
             {
                 hf();
             }
             else if(rijec[u]=='i')
             {
                 iff();
             }
             else if(rijec[u]=='j')
             {
                 jf();
             }
             else if(rijec[u]=='k')
             {
                 kf();
             }
             else if(rijec[u]=='l')
             {
                 lf();
             }
             else if(rijec[u]=='m')
             {
                 mf();
             }
             else if(rijec[u]=='n')
             {
                 nf();
             }
             else if(rijec[u]=='o')
             {
                 of();
             }
             else if(rijec[u]=='p')
             {
                 pf();
             }
             else if(rijec[u]=='q')
             {
                 qf();
             }
             else if(rijec[u]=='r')
             {
                 rf();
             }
             else if(rijec[u]=='s')
             {
                 sf();
             }
             else if(rijec[u]=='t')
             {
                 tf();
             }
             else if(rijec[u]=='u')
             {
                 uf();
             }
             else if(rijec[u]=='v')
             {
                 vf();
             }
             else if(rijec[u]=='w')
             {
                 wf();
             }
             else if(rijec[u]=='x')
             {
                 xf();
             }
             else if(rijec[u]=='y')
             {
                 yf();
             }
             else if(rijec[u]=='z')
             {
                 zf();
             }
             else if(rijec[u]=='_')
             {
                 spacef();
             }
             
         }
         fprintf(f,"\n");
     }
}

int main()
{
    printf("Upisi string, koristeci \"_\" umjesto razmaka: ");
    scanf("%s",&rijec);
    priprema();
    system("cls");
    ispisc();
    ispisf();
    getch();
    return 0;
}
