#include <stdio.h>
#include <stdlib.h>
#define L 50


int main () {

    char c;
    int cnt[2]={0}; //Counter

    FILE *f;
    f=fopen("Broj_znakova.c", "r");
    if(f==NULL) {
             printf("Ne mogu naci datoteku!!!\a\n");
             getch();
             exit(1);
    }

    while((c=fgetc(f))!=EOF) {
                             if(c=='{') cnt[0]++;
                             if(c=='}') cnt[1]++;
    }

    printf("Datoteka 'Broj_znakova.c' sadrzi %d znakova '{' i %d znakova '}'! \n",cnt[0],cnt[1]);
    getch();
}
