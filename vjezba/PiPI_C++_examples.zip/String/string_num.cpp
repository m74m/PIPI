#include <stdio.h>
#include <conio.h>
#include <string.h>
#define MAX 128

void inv(char []);

int main(void) {
    
    char niz_znakova[MAX],c;
    int i,brojac=0;
    printf("String=");
    scanf("%s", niz_znakova);
    i=0;
    while((c=niz_znakova[i]) !='\0') {
                             if(c>='0' && c<='9') ++brojac;
                             i++;
    }
    printf("Broj ucitanih numerickih znakova = %d\n",brojac);
    inv(niz_znakova);
    printf("%s\n",niz_znakova);
    getch();
    return 0;
}

void inv(char s[]) {
     
     int c,i,j;
     for(i=0,j=strlen(s)-1; i<j; i++,j--) {
                            c=s[i]; s[i]=s[j]; s[j]=c;
     }
}