#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

char slova[100];
short i=0;
short count=0;

void reader()
{
     for(i=0;i<=99;i++)
     {
         slova[i] = getch();
         system("cls");
         if(slova[i]==8)
         {
             i=i-2;
         }
         else if(slova[i]==13)
         {
             break;
         }
         if(i<-1)
         {
             i=0;
         }
         for(short j=0;j<=i;j++)
         {
             printf("%c",slova[j]);
         }
     }
}

void counter()
{
    for(short j=0;j<=i;j++)
    {
        if(slova[0]==13)
        {
            printf("Molim upisi string prije nego pritisnes return");
            getch();
            exit(1);
        }
        else if(slova[0]==32)
        {
            printf("Molim ne stavljati razmak na prvo mijesto");
            getch();
            exit(1);
        }
        else if(slova[j]==32)
        {
            if((slova[j+1]!=32)&&(slova[j+1]!=13))
            {
                count++;
            }
        }
    }
}

void reverser()
{
     for(short j=i;j>=0;j--)
     {
         printf("%c",slova[j]);
     }
}

int main()
{
    reader();
    counter();
    printf("%d rijec(i)\n\n",count+1);
    printf("Unazad napisan string izgleda ovako:\n\n");
    reverser();
    getch();
}
