#include <stdio.h>
#include <ctype.h>
int main () {
    int i;
    char c1[100], c2[100], c3[100];
    printf("String_1="); scanf("%s",c1);
    printf("String_2="); scanf("%s",c2);
    printf("String_3=");
    for (i=0; i<=100; i++) {
        if (c1[i]==c2[i]) c3[i]=c1[i];
        else c3[i]=' ';
    }
    printf("%s",c3);
    printf("\n");
    getch ();
    return 0;
}
