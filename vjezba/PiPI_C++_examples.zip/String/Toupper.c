#include <stdio.h>
#include <ctype.h>

int main () {
    int l=0;
    char c[100];
    printf("string="); scanf("%s",c);
    printf("\nToupper(string)=");
    while (c[l] != 0) {
          printf("%c", toupper(c[l]));
          l++;
    }
    printf("\n");
    getch();
}

