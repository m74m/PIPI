#include <stdio.h>
#include <conio.h>
#define MAX 100

char cezar(char c) {
     
	 if(c>=65 && c<=88 || c>=97 && c<=120) c+=3;
	 if(c==89 || c==90 || c==121 && c==122) c-=23;
	 return c;
}
  
char arccezar(char c) {
     
	 if(c>=67 && c<=90 || c>=99 && c<=122) c-=3;
	 if(c==65 || c==66 || c==97 && c==98) c+=23;
	 return c;
}

main() {
       
       int i=0, s;
       char c[MAX];
       printf("Unesi znakovni niz c: "); scanf("%s",c);
       printf("cezar (c)= ");
       while (c[i] != '\0') {
             printf("%c", cezar(c[i]));
             i++;
       }
       printf("\n");
       i=0;
       printf("arccezar (c)= ");
       while (c[i] != '\0') {
             printf("%c", arccezar(c[i]));
             i++;
             
       }
       printf("\n");
       getch();
       return 0;
}
