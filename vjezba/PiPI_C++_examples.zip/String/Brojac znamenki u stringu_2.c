#include<stdio.h>
#include<string.h>

int main() {
    
    char s[100];
    int i=0, br=0;
    printf("Upisite  string:  ");
    scanf("%99[^\n]", s);
    while (s[i]!='\0') {
          if(s[i]=='0') br++;
          if(s[i]=='1') br++;
          if(s[i]=='2') br++;
          if(s[i]=='3') br++;
          if(s[i]=='4') br++;
          if(s[i]=='5') br++;
          if(s[i]=='6') br++;
          if(s[i]=='7') br++;
          if(s[i]=='8') br++;
          if(s[i]=='9') br++;
          i++;
    }
    printf("U zadanom stringu nalazi se %d znamenki\n", br);
    getch();
}

