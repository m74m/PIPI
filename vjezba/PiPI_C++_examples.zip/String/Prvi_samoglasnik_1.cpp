#include <stdio.h>
#include <conio.h>

int trazi(char linija[], int n, char *psamoglasnik) {
    int i;
    char c;
    for(i=0; i<n; i++){
             c=linija[i];
             if(c == 'a' || c == 'e' || c == 'i'|| c == 'o' || c == 'u'){
                  *psamoglasnik=c;
                  return i;
             }
    }
    return -1;
}


int main(void) {
    
    char string[]={'P','r','o','g','r','a','m','s','k','i',' ','j','e','z','i','k',' ','C','.'};
    char znak;
    int no;
    no=trazi(string,19,&znak);
    if(no != -1){
          printf("Prvi samoglasnik = %c\n",znak);
          printf("Nalazi se na mjestu %d\n",no);
    }
    else printf("Nema samoglasnika.\n");
    getch();
    return 0;
}
