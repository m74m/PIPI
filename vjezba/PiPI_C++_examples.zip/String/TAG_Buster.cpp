float verzija=0.5;
/**********************************************************************
Naziv programa:			TAG Buster
Autor:					Tomislav Santek
Datum prve izmjene:		01,05,2004
Datum zadnje izmjene:	10,05,2004

Rijeseni problemi u odnosu na staru verziju:

  v0.2:
*	program se vise ne rusi kada ne uspije naci trazeni string!!!
*	dodane upute za koristenje u slucaju krivog unosa parametara.

  v0.3:
*	otkriven i uklonjen bug pri brisanju suvisnog html koda:
		brise previse znakova
		ako ne nadje string, ne prazni privremeni string, vec ga dalje puni...
*	potpuno funkcionalan program za trazenje i brisanje danih stringova...
	... ali to nije dovoljno da ucini program posebnim...

  v0.4
*	dodana mogucnost trazenja opcenitih tagova.
*	uocen problem kod nove opcije...(napredno trazenje i brisanje)
*	uocen problem pri trazenju stringova koji se ponavljaju u izvorniku.

  v0.5:
*	uklonjeni problemi iz prethodnih verzija

***********************************************************************/
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char* argv[])
{
	cout<<"\nTAG buster, ver. "<<verzija<<endl;
	
	if (argc!=4){
	
	if (argv[1]=="?")
	{
		cout<<"\nProgram ucitava izvornu htm datoteku u memoriju, trazi i izbacuje\n";
		cout<<"stringove navedene u datoteci izbaci.txt. Rezultat zapisuje u novu\n";
		cout<<"datoteku. Datoteku izbaci.txt pisati u skladu sa slijedecim pravilima:\n";
		cout<<"1. Stringovi za trazenje moraju biti odvojeni novim retkom (ENTER)\n";
		cout<<"2. Stvaranje opcenitog pravila za brisanje stringa se radi tako da se\n";
		cout<<"		iza trazenog stringa dodaju dvije zvijezdice (**). Tada ce program\n";
		cout<<"		brisati sav sadrzaj taga, dok ne dode do slijedeceg znaka >\n";
		cout<<"\nSintaksa programa je:\n";
		cout<<"tag Ime.html Izbaci.txt Novi.html\n";
		getchar();	
		return 3;
	}
	else{
		cerr<<"Greska: krivi broj argumenata!\n";
		cout<<"Sintaksa programa je:\n";
		cout<<"tag Ime.html Izbaci.txt Novi.html\n";
		getchar();	
		return 0;}
	}

	cout<<"\nZadani argumenti su: "<<argv[1]<<" "<<argv[2]<<" "<<argv[3]<<endl;
	cout<<"Obrada je u tijeku...\n";

	ifstream izvornik(argv[1]);
	if (!izvornik){
		cerr<<"\nGreska: Nemoguce otvoriti izvornu html datoteku!\n";
		getchar();	
		return 0;
	}
	ifstream izbaci(argv[2]);
	if (!izbaci){
		cerr<<"\nGreska: Nemoguce otvoriti datoteku s definicijama!\n";
		getchar();	
		return 0;
	}
	
	char zn, zn2;
	string rijec, izvor;
	int lokacija=0, lokacija2=-1,provjera;
	int i=0, erased=0;

	while(izvornik.get(zn2))
	{
	izvor+=zn2;
	}
	cout<<"Zacrseno ucitavanje izvorne datoteke.\n";
	cout<<"Izlistavam sadrzaj datoteke:\n\n";
	cout<<izvor;

	while(izbaci.get(zn))
	{
		if(zn!='\n')
		{
			rijec+=zn;
		}
		else
		{
			provjera=rijec.rfind("**");
			
do{
			if(provjera>1)
			{
				if (erased==0) rijec.erase(rijec.size()-2,2);
				erased++;
				lokacija=izvor.find(rijec,0);
				lokacija2=izvor.find('>',lokacija);

				if(lokacija!=-1)
				{
					cout<<"Trazeni string pronadjen na lokaciji: "<<lokacija<<endl;
					izvor.erase(lokacija,lokacija2-lokacija+1);
					i++;
				}
			}
			
			else
			{
				lokacija=izvor.find(rijec,0);
				if (lokacija!=-1)
				{
				izvor.erase(lokacija,rijec.size());
				i++;
				}
				
				
			}
lokacija=izvor.find(rijec,0);				
}while(lokacija!=-1);
			rijec="";
			erased=0;
		}
	}

	if (i!=0)
	{
	cout<<"\nPronadjene su zadane stavke. Slijedi ispis novog koda\n";
	cout<<izvor;
	ofstream izlaznik(argv[3]);
	if (!izlaznik){
		cerr<<"\nGreska: Nemoguce otvoriti izlaznu html datoteku!\n";
		getchar();	
		return 0;
	}
	izlaznik<<izvor;
	cout<<"TAG buster zavrsava s radom, ucinjeno je "<<i<<" promjena\n";
	cout<<"Promjene su spremljene u "<<argv[3]<<endl;
	getchar();	
	}
	else
	{
		cout<<"\n\nNije pronadjena niti jedna kljucna rijec\n";
		cout<<"TAG buster zavrsava s radom, nova datoteka nije kreirana.\n";
		cout<<"br.pr: "<<i;
		getchar();	
		return 0;
	}
getchar();	
return 1;
}

