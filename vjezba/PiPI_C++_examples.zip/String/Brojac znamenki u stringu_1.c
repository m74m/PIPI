#include<stdio.h>

int main()
{
  char *cptr;
  char buffer[100];
  int i=0, brojac=0;

  printf("upisite string: ");
  cptr=fgets(buffer, 100, stdin);
  while(cptr[i] != '\0') {
                
      if((cptr[i]=='0')||(cptr[i]=='1')||(cptr[i]=='2')||(cptr[i]=='3')||(cptr[i]=='4')||(cptr[i]=='5')||(cptr[i]=='6')||(cptr[i]=='7')||(cptr[i]=='8')||(cptr[i]=='9'))
      brojac++;
      i++;
  }
      
  printf("U zadanom stringu nalazi se %d znamenki.\n", brojac);
  getch();
}
