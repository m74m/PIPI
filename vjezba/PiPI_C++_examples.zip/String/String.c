#include <stdio.h>

int main () {
    char c, niz[1000];;
    int j=0;
    printf("Unesite string (ili '0' kao zavrsetak): ");
    while((c=getchar())!='0') {
                              niz[j]=c;
                              j++;
    }
    niz[j]='\0';
    printf("Upisani string je:\n%s", niz);
    getch();
}
