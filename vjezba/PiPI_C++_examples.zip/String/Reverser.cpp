#include <conio.h>
#include <stdlib.h>

/* Zadatak6, Zubic Tomislav */
/*Ovaj program mijenja redosljed slova upisane rije�i*/

char text[100];
char text_t[100];
char temp;
int kurs;
int end;

void writer()
{
    system("cls");
    for(int i=0;i<=end;i++)
    {
        if(kurs==i)
        {
            putch(95);
        }
        putch(text[i]);
    }
}

void shift_left()
{
    for(int i=kurs;i<=end;i++)
    {
        text[i]=text[i+1];
    }
    end--;
    if(end<0)
    {
        end=0;
    }
}

void shift_right()
{
    for(int i=end;i>=kurs;i--)
    {
        text[i]=text[i-1];
    }
}

void dodatno()
{
    temp = getch();
    if(temp==75)
    {
        kurs--;
        if(kurs<0)
        {
            kurs=0;
        }
    }
    else if(temp==77)
    {
        kurs++;
        if(kurs>end)
        {
            kurs=end;
        }
    }
    else if(temp==83)
    {
        shift_left();
    }
}

void reverser()
{
    system("cls");
    for(int i=end-1;i>=0;i--)
    {
        text_t[end-1-i]=text[i];
    }
    for(int i=0;i<end;i++)
    {
        text[i]=text_t[i];
    }
}

void reader()
{
    system("title Reverser v.0.9.8b");
    kurs = 0;
    end = 0;
    do
    {
        temp = getch();
        if((temp>=32)&&(temp<=255))
        {
            shift_right();
            text[kurs]=temp;
            kurs++;
            end++;
        }
        else if((temp == 8)&&(kurs>0))
        {
            kurs--;
            shift_left();
        }
        else if(temp == 27)
        {
            exit(1);
        }
        else if(temp == 13)
        {
            reverser();
        }
        else if((temp == -32)||(temp == 0))
        {
            dodatno();
        }
        writer();
    }while(end!=100);
}

int main()
{
    reader();
}
        
        
        
        
