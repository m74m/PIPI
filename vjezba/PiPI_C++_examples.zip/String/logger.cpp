#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

char slovo;
int main(int argc, char *argv[])
{
    system("title T3h keylogger");
    printf("Upisi neko slovo");
    while(1)
    {
            slovo = getch();
            system("cls");
            printf("Pritisnuo si %s, gz!",&slovo);
    }
return 0;
}
