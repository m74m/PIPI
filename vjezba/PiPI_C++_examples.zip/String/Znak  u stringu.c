#include <stdio.h>
#include <ctype.h>

int main()
{
	char string[100];
	char znak;
	int i=0,c=0;

	printf("Upisite string: ");
	scanf("%99[^\n]",string);

	printf("Upiste znak: ");
	scanf(" %c",&znak);

	while(string[i]!=0)
	{
		if(toupper(string[i])==toupper(znak)) c++;
		i++;
	}

	printf("Znak %c nalazi se u stringu %i puta.\n",znak,c);
	
    getch();
	return 0;
}
