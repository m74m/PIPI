#include <stdio.h>
#include <ctype.h>

int main () {
    int l=0;
    char c[100];
    printf("string="); scanf("%s",c);
    printf("\nTolower(string)=");
    while (c[l] != 0) {
          printf("%c", tolower(c[l]));
          l++;
    }
    printf("\n");
    getch();
}
