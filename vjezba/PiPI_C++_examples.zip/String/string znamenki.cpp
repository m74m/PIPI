#include <stdio.h>
#include <conio.h>


int main () {
 int i=0,/*varijabla while petlje*/ cnt[10]={0}/*ako broj sadr�i znamenku*/ ;
 char s[20]; /*String sa znamenkama*/
 

 printf("s="); scanf("%s", &s);
 
     while (s[i]!='\0') {
           if(s[i]=='0') cnt[0]=1; 
           if(s[i]=='1') cnt[1]=1; 
           if(s[i]=='2') cnt[2]=1; 
           if(s[i]=='3') cnt[3]=1;
           if(s[i]=='4') cnt[4]=1; 
           if(s[i]=='5') cnt[5]=1; 
           if(s[i]=='6') cnt[6]=1; 
           if(s[i]=='7') cnt[7]=1; 
           if(s[i]=='8') cnt[8]=1; 
           if(s[i]=='9') cnt[9]=1; 
           i++;
           printf("/");
           }
     if ((cnt[0]==1)&&(cnt[1]==1)&&(cnt[2]==1)&&(cnt[3]==1)&&(cnt[4]==1)&&(cnt[5]==1)&&(cnt[6]==1)&&(cnt[7]==1)&&(cnt[8]==1)&&(cnt[9]==1)) { printf("\nOvaj string sadrzi sve znamenke 0-9!\a\n"); getch(); }
     else printf("\n");
    
     
 getch();
}
