#include <stdio.h>

int main () {
    int j, l=1;
    char c[100];
    sprintf(c, "%d", l);
    printf("\nDakle, ako se granica stringa ne definira na pravilan nacin,\n");
    printf("program moze dalje ispisivati sadrzaj RAM memorije, kao npr ovaj!\n");
    printf("Neki od tih znakova mogu posluziti kao naredbe za ton, a moze doci i do greske,\n");
    printf("moze se program i srusiti!\n\n");
    printf("Pritisnite '0' zelite li vidjeti sadrzaj memorije, \nu suprotnom bilo koji drugi broj!\n\n");
    scanf("%d", &j);
    if(j==0) {
             while (c[l] != "\0") {
                   printf("%c", c[l]);
                   l++;
             }
    } else return 0;
}
