
#include <stdio.h>
#include <conio.h>

void f(int x) {
     x+=1;
     printf("\nUnutar funkcije x=%d",x);
     return;
}

int main(void) {
    int x=5;
    printf("\nIzvan funkcije x=%d",x);
    f(x);
    printf("\nNakon poziva funkcije x=%d",x);
    getch();
    return 0;
}