#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int main() {
    int h, H;
    FILE *f;
    f=fopen("brojevi.txt", "r");
    if(f==NULL) {
                printf("\aNema datoteke...\n");
                exit(1);
    }
    while(fscanf(f, "%d\n" ,&h) != EOF) {
                    
                    H=pow(h,2);
                    printf("%d\n", H);
    }
    getch();
}
