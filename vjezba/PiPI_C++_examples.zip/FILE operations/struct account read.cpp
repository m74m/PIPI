#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

struct account{
       int count;
       int total;
       char name[64];
};

int main(void) {
    struct account lista;
    FILE *fp;
    
    if((fp=fopen("accounts.txt","r"))==NULL){ system("color 04");
                                       printf("Error: nije moguce otvoriti datoteku accounts.txt.\n\a");
                                       exit(-1);
    }
    
    printf("Ispis clanova liste:\n\n");
    do {
                                      
                                      fread(&lista,sizeof(lista), 1, fp);
                                      printf("lista[%d].total= %d\n",lista.count,lista.total);
                                      printf("lista[%d].name= %s\n",lista.count,lista.name);
                                      printf("\n");
    }while(! feof(fp));
    fclose(fp);
    getch();
    system("cls");
    system("color 02");
    printf("EXIT_SUCCESS\n");
    getch();
    return EXIT_SUCCESS;
}
