#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

struct account{
       int count;
       int total;
       char name[64];
};

int main(void) {
    FILE *fp;
    int i, n;
    printf("Unesi broj clanova liste: "); scanf("%d", &n);
    struct account lista[n];
    for(i=0;i<n;i++){
                        lista[i].count=i;
                        printf("lista[%d].total= ",i);
                        scanf("%d",&lista[i].total);
                        printf("lista[%d].name= ",i);
                        scanf("%s",lista[i].name);
    }
    if((fp=fopen("accounts.txt","w"))==NULL){ system("color 04");
                                       printf("Error: nije moguce otvoriti datoteku accounts.txt.\n\a");
                                       exit(-1);
    }
    for(i=0;i<n;++i){
                        if(fwrite(&lista[i],sizeof(lista[i]), 1, fp) != 1){
                                                              system("color 04");
                                                              printf("Greska pri upisu u 1.txt\n\a");
                                                              exit(1);
                        }
    }
    fclose(fp);
    system("cls");
    system("color 02");
    printf("EXIT_SUCCESS\n");
    getch();
    return EXIT_SUCCESS;
}
