#include <stdio.h>
#include <math.h>

V2(double x[], double y[], int n) {
          int i;
          for (i=0; i<=n; i++) {
              y[i]=pow(x[i],2);
          }
          return; 
}

int main () {
    int c;
    double a[8], b[8];
    for (c=1; c<=8; c++) {
        printf("a[%d]=",c); scanf("%lf", &a[c]);
    }
    V2(a, b, 8);
    printf("Ispis kvadrata clanova niza :\n");
    for (c=1; c<=8; c++) printf("a[%d]^2=%lf\n",c,b[c]);
    getch ();
    return 0;
}
