#include <stdio.h>

void Vsum(double x[],int n)
{
	int i=1;
	double t;

	t=x[0];

	for(i;i<n;i++)
	{
		t+=x[i];
		x[i]=t;
	}

	return;
}

int main()
{
	double x[10];
	int i=0;

	printf("Upisite 10 brojeva:\n");

	for(i;i<10;i++)
	{
		scanf("%lf",&x[i]);
	}

	i=0;

	Vsum(x,10);

	printf("Niz parcijalnih suma:\n");

	for(i;i<10;i++)
	{
		printf("%lf\n",x[i]);
	}
    getch();
	return 0;
}
