#include <stdio.h>


void VR (float x[],float y[], int n)
{	
	int i;
	for(i=0;i<6;i++)
		y[i]=x[5-i];
}

int main()

{

float x[6],y[6];
int i,n=6;

printf ("upisite 6 brojeva: \n");

for (i=0;i<6;i++)
	{
	scanf("%f",&x[i]);
	}

VR (x,y,n);

printf("okrenuti niz:\n");
for (i=0;i<6;i++)
	{
	printf("%f\n",y[i]);
	}

getch();
return 0;
}



