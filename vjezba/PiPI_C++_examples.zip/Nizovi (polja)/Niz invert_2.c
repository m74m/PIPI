#include <stdio.h>

void okreni (float x[], float y [], int n)
{
	int i=0;
	for (i=0; i<n; i++)
	{
		y[i]=x[n-1-i];
	}

}
	


int main ()
{	
	int i;
	float a[6];
	float b[6];
	int n=6;
	
	printf ("\nUpisite 6 brojeva:\n");
	
	for(i=0;i<=5;i=i+1)
		scanf("%f", &a[i]);
		
	okreni (a,b,n);
	
	printf ("\nOkrenuti niz:\n");
	
	for(i=0;i<=5;i=i+1)
		printf ("%f\n", b[i]);
	printf("\n");
	getch();
    return 0;
}
