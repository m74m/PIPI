#include <stdio.h>
#include <conio.h>
float niz[20];
int i, n;
float zp, zn;
void upis(float niz[20]){
  for(i=0; i<n; i++){
    printf("niz[%d]=", i);
    scanf("%f", &niz[i]);
  }
}
float zbrojParnih(float niz[20]){
  float zbroj=0;
  for(i=0; i<n; i++){
    if((i%2)==0){
      zbroj+=niz[i];
    }
  }
  return zbroj;
}
float zbrojNeparnih(float niz[20]){
  float zbroj=0;
  for(i=0; i<n; i++){
    if((i%2)==1){
      zbroj+=niz[i];
    }
  }
  return zbroj;
}
main(){
  printf("Broj clanova niza = ");
  scanf("%d", &n);
  upis(niz);
  zp=zbrojParnih(niz);
  printf("Zbroj parnih clanova je %.3f\n", zp);
  zn=zbrojNeparnih(niz);
  printf("Zbroj neparnih clanova je %.3f\n", zn);
  getch();
}
