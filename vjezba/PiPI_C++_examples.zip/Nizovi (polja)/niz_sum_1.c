#include <stdio.h>

int main () {
    int n, ls;
    printf("Ovaj program zbraja uneseni clan niza s ukupnim brojem clanova niza.\n");
    printf("n="); scanf("%d", &n);
    int c[n];
    for (ls=1; ls<=n; ls++) {
        printf("c[%d]=",ls); scanf("%d", &c[n]); printf("c[%d]+n=%d\n",ls,c[n]+n);
    }
    getch();
}
