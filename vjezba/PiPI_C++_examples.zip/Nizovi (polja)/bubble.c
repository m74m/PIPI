#include <stdio.h>

void bubble_sort(int a[], int n);

main()
{
	printf("Unesi 10 brojeva za sortiranje>\n");
	int a[10],i,n;
	n=10;
	
	for (i=0;i<n;i++)
	{
        printf("broj[%d]=",i+1);
		scanf("%d",&a[i]);
	}

	bubble_sort(a, n);
 	
	printf("\nA sada slijedi sortirana verzija:\n");
	
	for (i=0;i<n;i++)
	{
		printf("%d\n",a[i]);
	};
    getch();
}	
	
void bubble_sort(int a[], int n)
{
	int imali_smo_bar_jednu_zamjenu;
	int i,pomocni;

        do
	{
		imali_smo_bar_jednu_zamjenu = 0;
		
                for(i = 0; i < n - 1; i++)
		{
			if (a[i] > a[i + 1])
			{
				int pomocni = a[i];  /* zamijeni dva */
				a[i] = a[i + 1];	   /* susjedna */	
				a[i + 1] = pomocni;  /* elementa */

				imali_smo_bar_jednu_zamjenu = 1;
			}
		}
		n--;  /* skrati polje za jedan element */
	}
	while (imali_smo_bar_jednu_zamjenu != 0);
}
