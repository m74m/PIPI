#include <stdio.h>
#include <conio.h>

main () {
     
     int i, j, n, b;
     bool N=1;
     printf("Unesite velicinu polja (max 50): ");
     scanf("%d",&n);
     if(n>50) return 0;
     unsigned int P[n];
     for(i=0; i<n; i++) {
              printf("P[%d]=",i);
              scanf("%d",&P[i]);
     }
     printf("\n");
     
     for(;;) {
             printf("Unesite trazeni broj (za izlaz <0 ): ");
             scanf("%d",&b);
             if(b<0) break;
             printf("\n");
             for(j=0, N=1; j<n; j++) {
                      if(b==P[j]){
                                  N=0;
                                  printf("Broj %d nalazi se u nizu na %d. mjestu!\n",b,j);
                      }
             }
             if(N) printf("Broj %d ne nalazi se u nizu!\n\a",b);
             printf("\n");
     }
     return 0;
}
