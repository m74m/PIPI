#include <stdio.h>

int main()
{
	int max;
	int a[10], i;

	for(i = 0; i < 10; i++)
	{
		printf("Unesi %d. broj: ", i + 1);
		scanf("%d", &a[i]);
	}

	printf("\n");

	max = a[0];

	for(i = 1; i < 10; i++)
		if (a[i] > max)
			max = a[i];

	printf("Najveci uneseni broj je %d\n", max);
    getch();
	return 0;
}

