#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
int select;
main () {
     system("color 1f");
     printf("Programeri su ovisni o kavi.\n\nSmatrate li da to nije zdravo i \nne preporucujete toliko puno kave, pritisnite 1.\nali ako ne smatrate da to nije zdravo pritisnite 2.: ");
     scanf("%d",&select);
     system("cls");
     switch(select){
                    case 1: printf("\n +---+\n |   |\n |   |\n |   O_\n |  /|   \n |   ^\n |\n |\n |\n-+------\n");
                    break;
                    case 2: printf("\n :-)\n");
                    break;
                    default: exit(1);
                    break;
     }
     getch();
}
     
