#include <iostream>
#include <list>

using namespace std;

struct MyStruct
{
	static int brojZivihStruktura;
	static list<MyStruct *> popis;
	string ime;
	
	MyStruct(string x)
	{
		brojZivihStruktura++;
		ime = x;
		popis.push_back(this);
	}

	~MyStruct()
	{
		brojZivihStruktura--;
		
		list<MyStruct *>::iterator li;
		for (li = popis.begin(); li != popis.end(); li++)
		    if (*li == this)
		    {
				popis.erase(li);
				break;
			}
	}
};

int MyStruct::brojZivihStruktura = 0;
list<MyStruct *> MyStruct::popis;

int main()
{
	MyStruct c("c");
	{
		MyStruct a("a"), b("b");

		cout << "--- unutar bloka ---" << endl << MyStruct::brojZivihStruktura << endl;
		list<MyStruct *>::iterator li;
		for (li = MyStruct::popis.begin(); li != MyStruct::popis.end(); li++)
	    	cout << (*li)->ime << endl;
	}

	cout << endl << "--- van bloka ---" << endl << MyStruct::brojZivihStruktura << endl;
	
	list<MyStruct *>::iterator li;
	for (li = MyStruct::popis.begin(); li != MyStruct::popis.end(); li++)
	    cout << (*li)->ime << endl;
	getchar();
	return 0;
}
