#include <stdio.h>
#include <conio.h>

int main(void) {
    int x=30;
    printf("x u vanjskom bloku = %d\n",x);
    while(x++ < 33) {
              int x =100;
              ++x;
              printf("x u unutarnjem bloku = %d\n",x);
    }
    printf("x u vanjskom bloku = %d\n",x);
    getch();
    return 0;
}
