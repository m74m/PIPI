#include <stdio.h>
#include <conio.h>
#include <stdarg.h>

double suma(int, ...);

int main(void) {
    double s,t;
    s=suma(3,1.0,2.0,3.0);
    t=suma(5,1.0,2.0,3.0,4.0,5.0);
    printf("%g %g\n",s,t);
    getch();
    return 0;
}

double suma(int n,...) {
       va_list ap;
       double total=0.0;
       int i;
       va_start(ap,n);
       for(i=0; i<n; ++i) total += va_arg(ap,double);
       va_end(ap);
       return total;
}
