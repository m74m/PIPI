#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ULAZ "izlaz.bin"

void riseError(char *greska);

int main()
{

	FILE *ulaz;

	struct {
		long int matBr;
		char prezime[15 + 1];
	} osoba;

	if ((ulaz = fopen(ULAZ, "rb")) == NULL)
		riseError("Nije moguce otvoriti datoteku.");

	while (fread(&osoba, sizeof osoba, 1, ulaz) != 0) {
		if (strchr(osoba.prezime, 'a') != NULL)
			printf("%d\n", osoba.matBr);
	}

	fclose(ulaz);

	return 0;

}

void riseError(char *greska)
{
	puts(greska);
	exit(1);
}
