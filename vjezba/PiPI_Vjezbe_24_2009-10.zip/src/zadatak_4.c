#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define ULAZ "slucajni.bin"

void riseError(char *greska);

int main()
{

	FILE *ulaz;

	int broj, brURedu, i, j;

	if ((ulaz = fopen(ULAZ, "rb")) == NULL)
		riseError("Nije moguce otvoriti datoteku.");

	for (i = 0; i < 20; i++) {

		if (fread(&brURedu, sizeof brURedu, 1, ulaz) < 1)
			riseError("Citanje nije uspjelo.");

		printf("%d ", brURedu);

		for (j = 0; j < brURedu; j++) {
			if (fread(&broj, sizeof broj, 1, ulaz) < 1)
				riseError("Citanje nije uspjelo.");

			printf("%d ", broj);
		}

		printf("\n");
	}

	fclose(ulaz);

	return 0;
}

void riseError(char *greska)
{
	puts(greska);
	exit(1);
}
