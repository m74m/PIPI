#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define RANDOM(from, to) (rand() % ((to) - (from) + 1) + (from))

#define IZLAZ "slucajni.bin"

void riseError(char *greska);

int main()
{

	FILE *izlaz;

	int broj, brURedu, i, j;

	if ((izlaz = fopen(IZLAZ, "wb")) == NULL)
		riseError("Nije moguce otvoriti datoteku.");

	srand(time(NULL));

	for (i = 0; i < 20; i++) {
		brURedu = RANDOM(2, 8);

		fwrite(&brURedu, sizeof brURedu, 1, izlaz);

		for (j = 0; j < brURedu; j++) {
			broj = RANDOM(150, 160);
			if (fwrite(&broj, sizeof broj, 1, izlaz) < 1)
				riseError("Zapisivanje nije uspjelo.");
		}
	}

	fclose(izlaz);

	return 0;
}

void riseError(char *greska)
{
	puts(greska);
	exit(1);
}
