#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ULAZ "ulaz.txt"
#define IZLAZ "izlaz.bin"

void riseError(char *greska);

int main()
{

	FILE *ulaz, *izlaz;

	struct {
		long int matBr;
		char prezime[15 + 1];
	} osoba;

	if ((ulaz = fopen(ULAZ, "r")) == NULL)
		riseError("Nije moguce otvoriti datoteku.");

	if ((izlaz = fopen(IZLAZ, "wb")) == NULL)
		riseError("Nije moguce napraviti/otvoriti datoteku.");

	while (fscanf(ulaz, "%ld%s", &osoba.matBr, osoba.prezime) == 2) {
		if ((fwrite(&osoba, sizeof osoba, 1, izlaz)) < 1)
			riseError("Greska kod upisivanja.");
	}

	fclose(ulaz);
	fclose(izlaz);


	return 0;
}

void riseError(char *greska)
{
	puts(greska);
	exit(1);
}
