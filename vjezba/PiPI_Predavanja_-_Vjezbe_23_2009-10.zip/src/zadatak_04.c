﻿#include <stdio.h>
#include <stdlib.h>

int main(){

	int n, i, j;
	char *datoteka = "datoteka.txt";
	char *mode = "w";
	FILE *tok;
	
	tok = fopen(datoteka, mode);
	
	printf("Unesite dimenziju tablice mnozenja.");
	scanf("%d", &n);
	
	fprintf(tok, "Tablica mnozenja %d x %d\n     ", n, n);
	
	for(i = 1; i <= n; i++)
		fprintf(tok, "%4d", i);
		
	fprintf(tok, "\n");
	fprintf(tok, "----+");
	
	for(i = 1; i <= n; i++)
		fprintf(tok, "----");
	
	fprintf(tok, "\n");
	
	for(i = 1; i <= n; i++){
	
		fprintf(tok, "%4d|", i);
		
		for(j = 1; j <= n; j++)
			fprintf(tok, "%4d", i*j);
	
		fprintf(tok, "\n");
	}
	
	fprintf(tok, "----+");
	for(i = 1; i <= n; i++)
		fprintf(tok, "----");
	
	fclose(tok);
	
	system("PAUSE");
	
	return 0;
}