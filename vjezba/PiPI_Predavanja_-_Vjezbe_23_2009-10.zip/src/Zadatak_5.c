#include <stdio.h>

#define DATOTEKA "Zadatak_5.txt"
#define MODE	 "r"

int main()
{
	FILE *file;
	float broj, suma = 0;
	int i = 0;

	file = fopen(DATOTEKA, MODE);

	if (file == NULL) {
		printf("Datoteka %s se ne moze otvoriti. Budite sigurni da ona postoji.", DATOTEKA);
		return 0;
	}

	while (fscanf(file, "%f", &broj) == 1) {
		i++;
		suma += broj;
	}

	if (i < 1 || fgetc(file) != EOF)
		puts("Nije procitan niti jedan broj.");
	else
		printf("%f", suma / i);

	fclose(file);

	return 0;
}
