#include <stdio.h>

#define DATOTEKA "Zadatak_3.txt"
#define MODE	 "r"

int broji(FILE *file);

int main()
{
	FILE *file;
	char znak;

	file = fopen(DATOTEKA, MODE);

	if (file == NULL) {
		printf("Datoteka %s se ne moze otvoriti. Budite sigurni da ona postoji.", DATOTEKA);
		return 0;
	}

	printf("%d", broji(file));

	fclose(file);

	return 0;
}

int broji(FILE *file)
{
	int broj = 0;
	char znak;

	while ((znak = fgetc(file)) != EOF) {
		znak = toupper(znak);

		if (znak == 'A' || znak == 'E' || znak == 'I' || znak == 'O' || znak == 'U')
			broj++;
	}

	return broj;
}
