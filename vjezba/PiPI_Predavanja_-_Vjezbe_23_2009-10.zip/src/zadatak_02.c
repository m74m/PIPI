﻿#include <stdio.h>
#include <ctype.h>

int broji(char *nazivDat){
	
	FILE *tok;
	int brojac = 0;
	char c;
	
	tok = fopen(nazivDat, "r");
	
	if(tok != NULL){
		
		while((c = fgetc(tok)) != EOF){
		
			c = tolower(c);
		
			if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
				brojac++;
		
		}
		
		fclose(tok);
		return brojac;
	}
	
	else
		return -1;

}

int main(){

	int brojSamoglasnika;
	char *datoteka = "datoteka.txt";
	
	brojSamoglasnika = broji(datoteka);
	
	if(brojSamoglasnika == -1)
		printf("Nije pronadena trazena datoteka.");
		
	else
		printf("Funkcija je pronasla %d samoglasnik/a", brojSamoglasnika);

	return 0;
}