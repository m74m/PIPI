﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 20

int main(){

	char *datoteka = "osobe.txt";
	char mode = "r";
	FILE *tok;
	
	int mBroj, dan, mjesec, godina;
	char ime[MAX] = {0}, prezime[MAX] = {0}, c;
	char *uzorak = "na";
	char *p;
	
	tok = fopen(datoteka, mode);

	while(fscanf(tok, "%d%20s%20s%2d%c%2d%c%4d", &mBroj, ime, prezime, 
		&dan, &c, &mjesec, &c, &godina) == 8){
	
		if((*p = strstr(ime, uzorak)) != NULL)
			printf("%d %s %s %2d.%2d.%4d", mBroj, ime, 
				prezime, dan, mjesec, godina);
	
	}
	
	fclose(tok);
	
	return 0;
}