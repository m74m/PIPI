#include <stdio.h>

#define DATOTEKA "Zadatak_7.txt"
#define MODE	 "r"

int main()
{
	FILE *file;
	float broj, vrijeme, temp, ukupnaTemp;
	int i, brDana, brMjerenja;
	char c;

	file = fopen(DATOTEKA, MODE);

	if (file == NULL) {
		printf("Datoteka %s se ne moze otvoriti. Budite sigurni da ona postoji.", DATOTEKA);
		return 0;
	}

	while (fscanf(file, "%c%d%c%d%c", &c, &brDana, &c, &brMjerenja, &c) == 5) {
		ukupnaTemp = .0f;
			
		for (i = 0; i < brMjerenja; i++) {
			if(fscanf(file, "%d%c%f%c", &vrijeme, &c, &temp, &c) == 4)
				ukupnaTemp += temp;
		}

		fscanf(file, "%c", &c);
		
		if (brMjerenja > 0)
			printf("%d -> %f\n", brDana, ukupnaTemp / brMjerenja);
	}

	fclose(file);

	return 0;
}
