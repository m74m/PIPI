#include <stdio.h>
#include <ctype.h>

#define DATOTEKA "Zadatak_1.txt"
#define MODE	 "r"

int main()
{
	FILE * file;
	char znak;

	file = fopen(DATOTEKA, MODE);

	if (file == NULL) {
		printf("Datoteka %s se ne moze otvoriti. Budite sigurni da ona postoji.", DATOTEKA);
		return 0;
	}

	while ((znak = fgetc(file)) != EOF)
		printf("%c", toupper(znak));

	fclose(file);

	return 0;
}
