int brojneslova(char str[]);
void caesarEncrypt (char *nizUlaz, char *nizIzlaz, int kljucKriptiranja);