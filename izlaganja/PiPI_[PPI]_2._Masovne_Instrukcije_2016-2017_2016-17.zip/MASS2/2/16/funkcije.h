void minmax(int *min, int *max, int *ary, int x, int y, int xmax, int ymax);
int dobreDimenzije(int x, int y, int xmax, int ymax);