# [PPI] Mass2

Solutions to 2nd lab exercises for MASS2 (2016/17)

## Part 1
```
01 - Darko
02 - Darko
04 - Darko
05 - Darko
06 - Darko
08 - Darko
10 - Darko
14 - Darko
15 - Darko
17 - Darko
20 - Darko
22 - Filip
26 - Filip
28 - Filip
30 - Filip
```

## Part 2

* need to choose tasks and solve them
